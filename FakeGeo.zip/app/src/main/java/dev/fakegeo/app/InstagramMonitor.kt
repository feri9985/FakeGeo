package dev.fakegeo.app

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

/**
 * Privacy-conscious diagnostics for Instagram foreground sessions.
 * Android does not expose whether another app called Location.isMock/isFromMockProvider,
 * so this records only observable facts (foreground transition, app location permission,
 * and the mock flag on FakeGeo's own last-known GPS fix).
 */
object InstagramMonitor {
    const val INSTAGRAM_PACKAGE = "com.instagram.android"
    private const val PREFS = "fakegeo"
    private const val LOG_KEY = "instagram_monitor_log"
    private const val MAX_LOGS = 100

    fun hasUsageAccess(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        return appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            context.packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    fun usageAccessSettingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("instagram_monitor_enabled", false)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean("instagram_monitor_enabled", enabled).apply()
    }

    @Synchronized
    fun addLog(context: Context, message: String) {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = try { JSONArray(p.getString(LOG_KEY, "[]")) } catch (_: Exception) { JSONArray() }
        val next = JSONArray()
        next.put(JSONObject().put("time", System.currentTimeMillis()).put("message", message))
        for (i in 0 until old.length().coerceAtMost(MAX_LOGS - 1)) next.put(old.getJSONObject(i))
        p.edit().putString(LOG_KEY, next.toString()).apply()
        MockState.log("Monitor: $message")
    }

    fun logs(context: Context): List<String> {
        val a = try {
            JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(LOG_KEY, "[]"))
        } catch (_: Exception) { JSONArray() }
        val out = ArrayList<String>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val time = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
                .format(java.util.Date(o.optLong("time")))
            out.add("$time  ${o.optString("message")}")
        }
        return out
    }

    fun clearLogs(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(LOG_KEY).apply()
    }

    fun instagramLocationPermission(context: Context): String {
        val pm = context.packageManager
        val installed = try { pm.getPackageInfo(INSTAGRAM_PACKAGE, 0); true } catch (_: Exception) { false }
        if (!installed) return "Instagram not installed"
        val fine = pm.checkPermission(android.Manifest.permission.ACCESS_FINE_LOCATION, INSTAGRAM_PACKAGE) == PackageManager.PERMISSION_GRANTED
        val coarse = pm.checkPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION, INSTAGRAM_PACKAGE) == PackageManager.PERMISSION_GRANTED
        return when {
            fine -> "Precise location permission: granted"
            coarse -> "Approximate location permission: granted"
            else -> "Location permission: not granted"
        }
    }

    fun fakeGeoMockFlag(context: Context): String {
        return try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            @Suppress("DEPRECATION")
            val l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (l == null) "FakeGeo GPS fix: unavailable" else {
                val mock = if (Build.VERSION.SDK_INT >= 31) l.isMock else l.isFromMockProvider
                "FakeGeo GPS fix mock flag: $mock"
            }
        } catch (e: SecurityException) {
            "FakeGeo GPS fix: location permission unavailable"
        } catch (e: Exception) {
            "FakeGeo GPS fix: unavailable (${e.javaClass.simpleName})"
        }
    }

    /** Returns true when Instagram was observed entering foreground during this poll. */
    fun poll(context: Context, since: Long): Pair<Long, Boolean> {
        if (!hasUsageAccess(context)) return Pair(System.currentTimeMillis(), false)
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val start = since.coerceAtLeast(end - 60_000L)
        val events = usm.queryEvents(start, end)
        val event = UsageEvents.Event()
        var found = false
        var newest = since
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.timeStamp > newest) newest = event.timeStamp
            val foreground = if (Build.VERSION.SDK_INT >= 29) {
                event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
            } else {
                @Suppress("DEPRECATION")
                event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            }
            if (foreground && event.packageName == INSTAGRAM_PACKAGE) found = true
        }
        return Pair(maxOf(newest, end - 2_000L), found)
    }
}
