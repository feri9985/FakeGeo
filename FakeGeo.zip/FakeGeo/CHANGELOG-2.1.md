# FakeGeo 2.1 – UI spacing and power-lifecycle maintenance

## Changes in this maintenance build
- Added consistent vertical spacing between Start, Stop, Developer options, and Battery optimization actions.
- Distinguished the Stop action with a restrained red treatment and rendered system/settings actions as secondary buttons.
- Updated the diagnostic copy to avoid implying that disabling battery optimization guarantees uninterrupted execution.
- Changed the manually acquired partial WakeLock to use a 10-minute system timeout.
- Added one idempotent `releaseWakeLock()` cleanup path and invoke it on explicit stop, startup exceptions, and service destruction.
- Clear the persisted `active` flag on startup failure so Android does not attempt to restart a failed session.

## Important Android location limitation
A normal application cannot guarantee that another application will never receive the device's real location if a mock-location session stops or is rejected. Android controls location access per application and by system settings. A fail-closed warning/stop state can make FakeGeo report its own failure honestly, but it cannot act as a system-wide location firewall. Users who need to prevent an app from accessing real location must manage that app's Android location permission or turn off device location themselves.

## Validation
The source was reviewed and packaged. A Gradle build was not run in this environment because no Gradle executable/wrapper is available here. Please build and test on the target Android SDK/device before release.
