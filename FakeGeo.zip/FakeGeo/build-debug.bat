@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle is not installed. Open this project in Android Studio or install Gradle 8.7.
  exit /b 1
)
gradle :app:assembleDebug --no-daemon
if errorlevel 1 exit /b %errorlevel%
echo APK output: app\build\outputs\apk\debug\app-debug.apk
