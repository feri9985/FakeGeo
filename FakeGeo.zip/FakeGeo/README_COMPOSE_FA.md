# FakeGeo — Dark Premium Compose integration

این نسخه رابط اصلی FakeGeo را به یک پوسته Jetpack Compose منتقل می‌کند و منطق موجود پروژه را نگه می‌دارد.

## چه چیزهایی ادغام شده‌اند؟

- صفحه GPS تمام‌صفحه با نقشه واقعی MapLibre
- پنل شناور مختصات، نام مکان، وضعیت سرویس و دکمه شروع/توقف
- جستجوی مکان متصل به منطق جستجوی قبلی Photon/Nominatim
- انتخاب لایه‌های نقشه و رفتن به نقطه انتخاب‌شده
- گزینه‌های Realistic Mode و Watchdog
- دسترسی به تاریخچه پین‌ها و انتخاب مجدد مکان ذخیره‌شده
- نوار ناوبری پایین Compose برای GPS، IP، SIM و Protect
- پوسته تیره برای صفحات IP، SIM و Protect؛ منطق و کنترل‌های اصلی این صفحات حفظ شده‌اند
- تشخیص زبان سیستم برای رابط GPS و نوار ناوبری: فارسی و انگلیسی

## ساخت APK در Android Studio

1. پوشه `FakeGeo` را در Android Studio باز کنید.
2. از نصب Android SDK 34 و JDK 17 مطمئن شوید.
3. Gradle Sync را اجرا کنید.
4. از پنجره Build گزینه `Build APK(s)` را انتخاب کنید یا دستور زیر را اجرا کنید:

```bash
gradle assembleDebug --no-daemon
```

فایل خروجی در مسیر زیر قرار می‌گیرد:

`app/build/outputs/apk/debug/app-debug.apk`

## ساخت از طریق GitHub Actions

Workflow موجود در `.github/workflows/build.yml` با اجرای دستی یا push روی شاخه main/master، نسخه Debug را می‌سازد و به‌صورت Artifact با نام `FakeGeo-apk` بارگذاری می‌کند.

## نکته تست

این محیط فعلی Android SDK و Gradle نصب‌شده ندارد؛ بنابراین APK در اینجا Build یا روی دستگاه اجرا نشده است. سورس ادغام‌شده در این بسته قرار دارد، اما پیش از نصب روزمره باید در Android Studio یا GitHub Actions ساخته و روی گوشی آزمایش شود.
