package dev.fakegeo.app

import android.os.SystemClock
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

private fun le32(b: ByteArray, o: Int): Long =
    (b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or
        ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24)

private fun le64(b: ByteArray, o: Int): Long = le32(b, o) or (le32(b, o + 4) shl 32)

private fun hx(b: ByteArray, max: Int = 64): String {
    val n = minOf(b.size, max)
    val sb = StringBuilder()
    for (i in 0 until n) sb.append("%02x".format(b[i]))
    if (b.size > max) sb.append("…")
    return sb.toString()
}

/**
 * Stage 3b-C: RemoteServiceDiscovery (RSD). The iPhone speaks HTTP/2 on the RSD port and carries XPC messages in
 * the DATA frames. The first message from the iPhone is a dictionary that lists every service and its port.
 * Written from the public description of the protocol (pymobiledevice3 / go-ios); not yet verified on a real iPhone,
 * so every step is logged.
 */
object Rsd {

    private const val PREFACE = "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n"

    private const val XPC_WRAPPER_MAGIC = 0x29b00b92L
    private const val XPC_PAYLOAD_MAGIC = 0x42133742L

    private const val F_ALWAYS_SET = 0x00000001
    private const val F_DATA = 0x00000100
    private const val F_INIT_HANDSHAKE = 0x00400000

    class XpcMsg(val stream: Int, val flags: Int, val msgId: Long, val bodyLen: Long, val value: Any?)

    // ------------------------------------------------------------------ XPC encode / decode

    private fun xpcWrap(flags: Int, msgId: Long, body: ByteArray?): ByteArray {
        val n = body?.size ?: 0
        val bb = ByteBuffer.allocate(24 + n).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(XPC_WRAPPER_MAGIC.toInt())
        bb.putInt(flags)
        bb.putLong(n.toLong())
        bb.putLong(msgId)
        if (body != null) bb.put(body)
        return bb.array()
    }

    /** magic + version 5 + an empty dictionary. */
    private fun emptyDictPayload(): ByteArray {
        val bb = ByteBuffer.allocate(20).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(XPC_PAYLOAD_MAGIC.toInt())
        bb.putInt(5)
        bb.putInt(0xf000)
        bb.putInt(4)
        bb.putInt(0)
        return bb.array()
    }

    private class Rd(val b: ByteArray, var p: Int) {
        fun u32(): Long { if (p + 4 > b.size) throw IOException("XPC: truncated"); val v = le32(b, p); p += 4; return v }
        fun align() { p = (p + 3) and 3.inv() }

        fun cstr(): String {
            val s = p
            while (p < b.size && b[p].toInt() != 0) p++
            if (p >= b.size) throw IOException("XPC: unterminated string")
            val r = String(b, s, p - s, Charsets.UTF_8)
            p++
            align()
            return r
        }

        fun obj(depth: Int = 0): Any? {
            if (depth > 16) throw IOException("XPC: nested too deep")
            val t = u32().toInt()
            when (t) {
                0x1000 -> return null
                0x2000 -> { val v = b[p].toInt() != 0; p += 4; return v }
                0x3000, 0x4000, 0x7000 -> { if (p + 8 > b.size) throw IOException("XPC: truncated"); val v = le64(b, p); p += 8; return v }
                0x5000 -> { if (p + 8 > b.size) throw IOException("XPC: truncated"); val v = java.lang.Double.longBitsToDouble(le64(b, p)); p += 8; return v }
                0x8000 -> {
                    val n = u32().toInt()
                    if (n < 0 || p + n > b.size) throw IOException("XPC: bad data length")
                    val d = b.copyOfRange(p, p + n); p += n; align(); return d
                }
                0x9000 -> {
                    val n = u32().toInt()
                    if (n < 1 || p + n > b.size) throw IOException("XPC: bad string length")
                    val s = String(b, p, n - 1, Charsets.UTF_8); p += n; align(); return s
                }
                0xa000 -> { if (p + 16 > b.size) throw IOException("XPC: truncated"); val d = b.copyOfRange(p, p + 16); p += 16; return hx(d, 16) }
                0xe000 -> {
                    u32()                                   // byte length
                    val count = u32().toInt()
                    val l = ArrayList<Any?>()
                    for (i in 0 until count) l.add(obj(depth + 1))
                    return l
                }
                0xf000 -> {
                    u32()                                   // byte length
                    val count = u32().toInt()
                    val m = LinkedHashMap<String, Any?>()
                    for (i in 0 until count) { val k = cstr(); m[k] = obj(depth + 1) }
                    return m
                }
                else -> throw IOException("XPC: unknown type 0x%x".format(t))
            }
        }
    }

    // ------------------------------------------------------------------ minimal HTTP/2

    private class H2(val c: UsbMux.Stream, val log: (String) -> Unit) {
        private val bufs = HashMap<Int, ByteArrayOutputStream>()
        val inbox = ArrayList<XpcMsg>()
        var goaway = false

        fun now() = SystemClock.elapsedRealtime()

        fun frame(type: Int, flags: Int, stream: Int, payload: ByteArray = ByteArray(0)) {
            val bb = ByteBuffer.allocate(9 + payload.size).order(ByteOrder.BIG_ENDIAN)
            bb.put((payload.size ushr 16).toByte()); bb.put((payload.size ushr 8).toByte()); bb.put(payload.size.toByte())
            bb.put(type.toByte()); bb.put(flags.toByte()); bb.putInt(stream)
            bb.put(payload)
            c.write(bb.array())
        }

        fun start() {
            val settings = ByteBuffer.allocate(12).order(ByteOrder.BIG_ENDIAN)
            settings.putShort(3); settings.putInt(100)          // MAX_CONCURRENT_STREAMS = 100
            settings.putShort(4); settings.putInt(1048576)      // INITIAL_WINDOW_SIZE = 1 MB
            c.write(PREFACE.toByteArray(Charsets.US_ASCII))
            frame(4, 0, 0, settings.array())
            frame(8, 0, 0, ByteBuffer.allocate(4).putInt(983041).array())   // connection window -> 1 MB
        }

        fun openChannel(stream: Int) = frame(1, 0x4, stream)     // HEADERS, END_HEADERS, empty header block

        fun sendXpc(stream: Int, flags: Int, body: ByteArray?) {
            val m = xpcWrap(flags, 0, body)
            var off = 0
            while (off < m.size) {
                val n = minOf(16384, m.size - off)
                frame(0, 0, stream, m.copyOfRange(off, off + n))
                off += n
            }
        }

        /** Handles one HTTP/2 frame if one arrives within [waitMs]. */
        fun pump(waitMs: Int): Boolean {
            val h = try {
                c.read(9, waitMs.coerceAtLeast(1))
            } catch (e: IOException) {
                if (e.message?.contains("timeout") == true) return false else throw e
            }
            val len = ((h[0].toInt() and 0xFF) shl 16) or ((h[1].toInt() and 0xFF) shl 8) or (h[2].toInt() and 0xFF)
            val type = h[3].toInt() and 0xFF
            val flags = h[4].toInt() and 0xFF
            val stream = ByteBuffer.wrap(h, 5, 4).order(ByteOrder.BIG_ENDIAN).int and 0x7FFFFFFF
            val payload = if (len > 0) c.read(len, 5000) else ByteArray(0)
            when (type) {
                0 -> onData(stream, payload)
                1 -> log("  h2: HEADERS from the iPhone on stream $stream (${payload.size} B)")
                3 -> log("  h2: RST_STREAM on stream $stream: ${hx(payload)}")
                4 -> {
                    if (flags and 1 == 0) { log("  h2: SETTINGS from the iPhone (${payload.size} B), acknowledging"); frame(4, 1, 0) }
                    else log("  h2: the iPhone acknowledged our SETTINGS")
                }
                6 -> if (flags and 1 == 0) frame(6, 1, 0, payload)
                7 -> { goaway = true; log("  h2: GOAWAY: ${hx(payload)}") }
                8 -> {}
                else -> log("  h2: frame type $type on stream $stream (${payload.size} B)")
            }
            return true
        }

        private fun onData(stream: Int, data: ByteArray) {
            val buf = bufs.getOrPut(stream) { ByteArrayOutputStream() }
            buf.write(data)
            while (true) {
                val all = buf.toByteArray()
                if (all.size < 24) return
                if (le32(all, 0) != XPC_WRAPPER_MAGIC) {
                    log("  XPC: bad wrapper magic on stream $stream: ${hx(all, 24)}")
                    buf.reset(); return
                }
                val flags = le32(all, 4).toInt()
                val bodyLen = le64(all, 8)
                val msgId = le64(all, 16)
                if (bodyLen < 0 || bodyLen > 8_000_000) { log("  XPC: absurd body length $bodyLen"); buf.reset(); return }
                if (all.size < 24 + bodyLen) return
                val body = all.copyOfRange(24, 24 + bodyLen.toInt())
                val rest = all.copyOfRange(24 + bodyLen.toInt(), all.size)
                buf.reset(); buf.write(rest)

                var value: Any? = null
                if (body.size >= 8 && le32(body, 0) == XPC_PAYLOAD_MAGIC) {
                    try { value = Rd(body, 8).obj() } catch (e: Exception) { log("  XPC: could not decode the body: ${e.message}") }
                }
                log("  XPC message: stream $stream flags 0x%x id $msgId body $bodyLen B".format(flags))
                inbox.add(XpcMsg(stream, flags, msgId, bodyLen, value))
            }
        }

        fun pumpFor(ms: Int) {
            val end = now() + ms
            while (now() < end) pump((end - now()).toInt().coerceIn(1, 300))
        }

        /** Pumps until a message carrying a "Services" dictionary arrived, or [ms] passed. */
        fun waitForServices(ms: Int): Map<String, Any?>? {
            val end = now() + ms
            while (true) {
                for (m in inbox) {
                    @Suppress("UNCHECKED_CAST")
                    val v = m.value as? Map<String, Any?>
                    if (v != null && v["Services"] is Map<*, *>) return v
                }
                val left = end - now()
                if (left <= 0 || goaway) return null
                pump(left.toInt().coerceIn(1, 300))
            }
        }
    }

    // ------------------------------------------------------------------ the handshake

    /** Runs the RSD handshake on an open TCP stream to the RSD port. Returns the iPhone's description or null. */
    @Suppress("UNCHECKED_CAST")
    fun handshake(c: UsbMux.Stream, log: (String) -> Unit): Map<String, Any?>? {
        val h2 = H2(c, log)
        h2.start()
        h2.pumpFor(600)

        log("RSD step 1: open channel 1 and send an empty XPC dictionary")
        h2.openChannel(1)
        h2.sendXpc(1, F_ALWAYS_SET or F_DATA, emptyDictPayload())
        var r = h2.waitForServices(1500)

        if (r == null) {
            log("RSD step 2: empty XPC message on channel 1")
            h2.sendXpc(1, F_ALWAYS_SET, null)
            r = h2.waitForServices(1500)
        }
        if (r == null) {
            log("RSD step 3: open channel 3 and send INIT_HANDSHAKE")
            h2.openChannel(3)
            h2.sendXpc(3, F_INIT_HANDSHAKE or F_ALWAYS_SET, null)
            r = h2.waitForServices(3000)
        }
        if (r == null) {
            log("The iPhone did not send a service list. Messages received so far: ${h2.inbox.size}")
            for (m in h2.inbox) log("  stream ${m.stream} flags 0x%x value ${m.value}".format(m.flags))
            return null
        }

        for ((k, v) in r) {
            if (k == "Services") continue
            log("  $k = ${v.toString().take(160)}")
        }
        val services = r["Services"] as Map<String, Any?>
        log("Services offered by the iPhone: ${services.size}")
        val interesting = listOf("instruments", "simulate", "location", "dt.", "remote")
        for ((name, v) in services.toSortedMap()) {
            if (interesting.any { name.contains(it, true) }) {
                val port = (v as? Map<String, Any?>)?.get("Port")
                log("  $name -> port $port")
            }
        }
        return r
    }
}
