package dev.fakegeo.app

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import kotlin.concurrent.thread

/**
 * Lets the FakeGeo desktop app (Mac/Windows) move this phone.
 * One JSON object per line, answered by one JSON line:
 *   {"cmd":"hello","pin":"123456"}   (not needed over USB/adb: loopback connections are trusted)
 *   {"cmd":"set","lat":25.2,"lon":55.27}   start or teleport
 *   {"cmd":"stop"}
 */
object RemoteControl {
    const val PORT = 47321
    @Volatile private var server: ServerSocket? = null

    fun start(ctx: Context) {
        if (server != null) return
        val app = ctx.applicationContext
        val thePin: String = pin(app)
        thread(isDaemon = true, name = "fakegeo-remote") {
            try {
                val ss = ServerSocket(PORT, 5)
                server = ss
                val msg = "IP: ${ip() ?: "no Wi-Fi"}\nPIN: $thePin"
                MockState.log(msg)
                Handler(Looper.getMainLooper()).post { Toast.makeText(app, msg, Toast.LENGTH_LONG).show() }
                while (true) {
                    val c = ss.accept()
                    thread(isDaemon = true) { handle(app, c, thePin) }
                }
            } catch (e: Exception) {
                server = null
                MockState.log("Remote control stopped: ${e.message}")
            }
        }
    }

    /** The PIN the computer must type (created once, kept on the phone). */
    fun pin(ctx: Context): String {
        val prefs = ctx.applicationContext.getSharedPreferences("fakegeo", Context.MODE_PRIVATE)
        var pin = prefs.getString("remote_pin", null)
        if (pin == null) {
            pin = (100000 + SecureRandom().nextInt(900000)).toString()
            prefs.edit().putString("remote_pin", pin).apply()
        }
        return pin
    }

    /** The phone's Wi-Fi IP (Wi-Fi interface first). Null when there is no Wi-Fi. */
    fun ip(): String? = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .sortedBy { if (it.name.startsWith("wlan")) 0 else 1 }
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { it is Inet4Address && !it.isLoopbackAddress && it.isSiteLocalAddress }?.hostAddress
    } catch (_: Exception) { null }

    private fun handle(app: Context, c: Socket, pin: String) {
        var authed = c.inetAddress.isLoopbackAddress   // adb forward arrives as loopback
        try {
            c.soTimeout = 0
            val rd = BufferedReader(InputStreamReader(c.getInputStream()))
            val out = c.getOutputStream()
            fun reply(o: JSONObject) { out.write((o.toString() + "\n").toByteArray()); out.flush() }
            fun ok() = JSONObject().put("ok", true)
            fun err(m: String) = JSONObject().put("ok", false).put("error", m)
            while (true) {
                val line = rd.readLine() ?: break
                val req = try { JSONObject(line) } catch (_: Exception) { reply(err("bad json")); continue }
                when (req.optString("cmd")) {
                    "hello" -> if (authed || req.optString("pin") == pin) { authed = true; reply(ok()) } else reply(err("Wrong PIN"))
                    "set" -> if (!authed) reply(err("Not authorised")) else {
                        val la = req.optDouble("lat", Double.NaN)
                        val lo = req.optDouble("lon", Double.NaN)
                        if (la.isNaN() || lo.isNaN() || la !in -90.0..90.0 || lo !in -180.0..180.0) reply(err("bad coordinates"))
                        else reply(setLocation(app, la, lo)?.let { err(it) } ?: ok())
                    }
                    "stop" -> if (!authed) reply(err("Not authorised")) else { stopMock(app); reply(ok()) }
                    else -> reply(err("unknown command"))
                }
            }
        } catch (_: Exception) {
        } finally { try { c.close() } catch (_: Exception) {} }
    }

    /** null = ok, otherwise a message for the desktop app. */
    private fun setLocation(app: Context, lat: Double, lon: Double): String? {
        val prefs = app.getSharedPreferences("fakegeo", Context.MODE_PRIVATE)
        prefs.edit().putString("pin_lat", lat.toString()).putString("pin_lon", lon.toString()).putBoolean("active", true).apply()
        if (MockState.running) {            // already running: jump there
            Motion.teleportLat = lat
            Motion.teleportLon = lon
            return null
        }
        return try {
            MockState.error = null
            app.startForegroundService(Intent(app, MockLocationService::class.java).setAction(MockLocationService.ACTION_START))
            null
        } catch (e: Exception) {
            "Android refused to start in the background. Open the FakeGeo app on the phone once, then try again. (${e.message})"
        }
    }

    private fun stopMock(app: Context) {
        app.getSharedPreferences("fakegeo", Context.MODE_PRIVATE).edit().putBoolean("active", false).apply()
        app.stopService(Intent(app, MockLocationService::class.java))
        MockState.running = false
    }
}
