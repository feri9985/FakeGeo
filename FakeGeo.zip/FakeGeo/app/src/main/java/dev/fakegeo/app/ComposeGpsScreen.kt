package dev.fakegeo.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.maplibre.android.maps.MapView
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import java.util.Locale

private val FakeGeoBg = Color(0xFF0B1020)
private val FakeGeoCard = Color(0xFF151D30)
private val FakeGeoMuted = Color(0xFF91A0B8)
private val FakeGeoGreen = Color(0xFF35D6A0)

/**
 * Dark Premium GPS screen for FakeGeo.
 * Pass the existing MapLibre MapView and wire callbacks to the existing MainActivity methods.
 * The MapView lifecycle remains owned by the Activity (onCreate/onStart/onResume/.../onDestroy).
 */
@Composable
fun FakeGeoGpsScreen(
    mapView: MapView,
    latitude: Double?,
    longitude: Double?,
    placeName: String?,
    isRunning: Boolean,
    statusText: String,
    onSearch: (String) -> Unit,
    onLocate: () -> Unit,
    onChooseMapLayer: () -> Unit,
    onStartStop: () -> Unit,
    realismEnabled: Boolean,
    watchdogEnabled: Boolean,
    onRealismChanged: (Boolean) -> Unit,
    onWatchdogChanged: (Boolean) -> Unit,
    onOpenHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isPersian = LocalConfiguration.current.locales[0]?.language == "fa"
    val rtl = if (isPersian) androidx.compose.ui.unit.LayoutDirection.Rtl else androidx.compose.ui.unit.LayoutDirection.Ltr
    var query by remember { mutableStateOf("") }
    var advancedExpanded by remember { mutableStateOf(false) }
    val latText = latitude?.let { String.format(Locale.US, "%.6f", it) } ?: "—"
    val lonText = longitude?.let { String.format(Locale.US, "%.6f", it) } ?: "—"
    val title = if (isPersian) "موقعیت مکانی" else "GPS LOCATION"
    val subtitle = if (isPersian) "مکان را روی نقشه انتخاب کن" else "Choose a point on the map"
    val searchHint = if (isPersian) "جستجوی مکان یا آدرس" else "Search a place or address"
    val selected = if (isPersian) "موقعیت انتخاب‌شده" else "SELECTED LOCATION"
    val noPin = if (isPersian) "برای انتخاب، روی نقشه ضربه بزن" else "Tap anywhere on the map to drop a pin"
    val ready = if (isPersian) "آماده" else "READY"
    val active = if (isPersian) "فعال" else "ACTIVE"
    val start = if (isPersian) "شروع موقعیت جعلی" else "START LOCATION"
    val stop = if (isPersian) "توقف سرویس" else "STOP SERVICE"
    val map = if (isPersian) "لایه نقشه" else "MAP LAYERS"
    val myLocation = if (isPersian) "موقعیت من" else "MY LOCATION"

    MaterialTheme {
        CompositionLocalProviderLayoutDirection(rtl) {
            Box(modifier.fillMaxSize().background(FakeGeoBg)) {
                AndroidView(
                    factory = { mapView },
                    modifier = Modifier.fillMaxSize()
                )

                // Subtle top scrim keeps the header readable over bright map tiles.
                Column(
                    Modifier.fillMaxWidth().align(Alignment.TopCenter)
                        .background(Color(0xCC0B1020)).padding(horizontal = 18.dp, vertical = 14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("FakeGeo", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Text(title, color = FakeGeoMuted, fontSize = 11.sp, letterSpacing = 1.2.sp)
                        }
                        Surface(color = if (isRunning) Color(0x332ED6A0) else Color(0x33FFFFFF), shape = RoundedCornerShape(50)) {
                            Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(7.dp).background(if (isRunning) FakeGeoGreen else FakeGeoMuted, CircleShape))
                                Spacer(Modifier.width(7.dp))
                                Text(if (isRunning) active else ready, color = if (isRunning) FakeGeoGreen else Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text(searchHint, color = FakeGeoMuted, fontSize = 14.sp) },
                        trailingIcon = {
                            TextButton(onClick = { if (query.isNotBlank()) onSearch(query.trim()) }) {
                                Text(if (isPersian) "جستجو" else "SEARCH", color = FakeGeoGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { if (query.isNotBlank()) onSearch(query.trim()) }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = FakeGeoGreen, unfocusedBorderColor = Color(0xFF354158),
                            cursorColor = FakeGeoGreen, focusedContainerColor = FakeGeoCard,
                            unfocusedContainerColor = FakeGeoCard
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )
                }

                Column(
                    Modifier.align(Alignment.CenterEnd).padding(end = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    FloatingMapControl(label = "◈", description = map, onClick = onChooseMapLayer)
                    FloatingMapControl(label = "◎", description = myLocation, onClick = onLocate)
                }

                Card(
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 10.dp),
                    shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp, bottomStart = 22.dp, bottomEnd = 22.dp),
                    colors = CardDefaults.cardColors(containerColor = FakeGeoCard),
                    elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
                ) {
                    Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(selected, color = FakeGeoMuted, fontSize = 10.sp, letterSpacing = 1.15.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(5.dp))
                                Text(placeName?.takeIf { it.isNotBlank() } ?: noPin, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Surface(color = Color(0x2235D6A0), shape = RoundedCornerShape(10.dp)) {
                                Text(if (isRunning) active else ready, color = FakeGeoGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            CoordinateTile(label = if (isPersian) "عرض جغرافیایی" else "LATITUDE", value = latText, modifier = Modifier.weight(1f))
                            CoordinateTile(label = if (isPersian) "طول جغرافیایی" else "LONGITUDE", value = lonText, modifier = Modifier.weight(1f))
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { advancedExpanded = !advancedExpanded }) {
                                Text(if (advancedExpanded) (if (isPersian) "بستن تنظیمات" else "HIDE OPTIONS") else (if (isPersian) "تنظیمات پیشرفته" else "ADVANCED"), color = FakeGeoGreen, fontSize = 10.sp)
                            }
                            TextButton(onClick = onOpenHistory) {
                                Text(if (isPersian) "تاریخچه مکان‌ها" else "PIN HISTORY", color = FakeGeoGreen, fontSize = 10.sp)
                            }
                        }
                        if (advancedExpanded) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Column(Modifier.weight(1f)) {
                                    Text(if (isPersian) "حالت واقع‌گرایانه" else "REALISTIC MODE", color = FakeGeoMuted, fontSize = 9.sp)
                                    Switch(checked = realismEnabled, onCheckedChange = onRealismChanged)
                                }
                                Column(Modifier.weight(1f)) {
                                    Text(if (isPersian) "پایش خودکار" else "WATCHDOG", color = FakeGeoMuted, fontSize = 9.sp)
                                    Switch(checked = watchdogEnabled, onCheckedChange = onWatchdogChanged)
                                }
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(statusText, color = FakeGeoMuted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(13.dp))
                        Button(
                            onClick = onStartStop,
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isRunning) Color(0xFF3A2630) else FakeGeoGreen,
                                contentColor = if (isRunning) Color(0xFFFF8796) else Color(0xFF071B16)
                            )
                        ) {
                            Text(if (isRunning) stop else start, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.3.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FloatingMapControl(label: String, description: String, onClick: () -> Unit) {
    Surface(onClick = onClick, color = Color(0xEE151D30), shape = RoundedCornerShape(15.dp), shadowElevation = 8.dp) {
        Column(Modifier.size(width = 58.dp, height = 58.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(label, color = FakeGeoGreen, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(description, color = FakeGeoMuted, fontSize = 8.sp, maxLines = 1)
        }
    }
}

@Composable
private fun CoordinateTile(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Color(0xFF0E1627), shape = RoundedCornerShape(13.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Text(label, color = FakeGeoMuted, fontSize = 9.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun CompositionLocalProviderLayoutDirection(
    direction: androidx.compose.ui.unit.LayoutDirection,
    content: @Composable () -> Unit
) {
    androidx.compose.runtime.CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides direction, content = content)
}


/** Main Compose shell: premium bottom navigation with the real legacy feature views retained. */
@Composable
fun FakeGeoAppShell(
    mapView: MapView,
    latitude: Double?,
    longitude: Double?,
    placeName: String?,
    isRunning: Boolean,
    statusText: String,
    selectedTab: Int,
    realismEnabled: Boolean,
    watchdogEnabled: Boolean,
    ipContent: View,
    simContent: View,
    protectContent: View,
    onTabSelected: (Int) -> Unit,
    onSearch: (String) -> Unit,
    onLocate: () -> Unit,
    onChooseMapLayer: () -> Unit,
    onStartStop: () -> Unit,
    onRealismChanged: (Boolean) -> Unit,
    onWatchdogChanged: (Boolean) -> Unit,
    onOpenHistory: () -> Unit
) {
    val context = LocalContext.current
    val isPersian = LocalConfiguration.current.locales[0]?.language == "fa"
    val names = if (isPersian) listOf("GPS", "آی‌پی", "سیم‌کارت", "محافظت") else listOf("GPS", "IP", "SIM", "Protect")
    val symbols = listOf("⌖", "◎", "▤", "⬡")

    MaterialTheme {
        Scaffold(
            containerColor = FakeGeoBg,
            bottomBar = {
                NavigationBar(containerColor = FakeGeoCard, contentColor = FakeGeoGreen) {
                    names.forEachIndexed { index, name ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { onTabSelected(index) },
                            icon = { Text(symbols[index], fontSize = 20.sp, color = if (selectedTab == index) FakeGeoGreen else FakeGeoMuted) },
                            label = { Text(name, fontSize = 10.sp, maxLines = 1) },
                            alwaysShowLabel = true
                        )
                    }
                }
            }
        ) { insets ->
            Box(Modifier.fillMaxSize().padding(insets).background(FakeGeoBg)) {
                when (selectedTab) {
                    0 -> FakeGeoGpsScreen(
                        mapView = mapView,
                        latitude = latitude,
                        longitude = longitude,
                        placeName = placeName,
                        isRunning = isRunning,
                        statusText = statusText,
                        onSearch = onSearch,
                        onLocate = onLocate,
                        onChooseMapLayer = onChooseMapLayer,
                        onStartStop = onStartStop,
                        realismEnabled = realismEnabled,
                        watchdogEnabled = watchdogEnabled,
                        onRealismChanged = onRealismChanged,
                        onWatchdogChanged = onWatchdogChanged,
                        onOpenHistory = onOpenHistory,
                        modifier = Modifier.fillMaxSize()
                    )
                    1 -> LegacyFeaturePage(
                        title = if (isPersian) "اطلاعات شبکه" else "NETWORK & IP",
                        content = ipContent,
                        context = context
                    )
                    2 -> LegacyFeaturePage(
                        title = if (isPersian) "مدیریت سیم‌کارت" else "SIM MANAGER",
                        content = simContent,
                        context = context
                    )
                    else -> LegacyFeaturePage(
                        title = if (isPersian) "مرکز محافظت" else "PROTECT CENTER",
                        content = protectContent,
                        context = context
                    )
                }
            }
        }
    }
}

@Composable
private fun LegacyFeaturePage(title: String, content: View, context: android.content.Context) {
    Column(Modifier.fillMaxSize().background(FakeGeoBg)) {
        Column(
            Modifier.fillMaxWidth().background(FakeGeoCard).padding(horizontal = 20.dp, vertical = 15.dp)
        ) {
            Text("FakeGeo", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text(title, color = FakeGeoMuted, fontSize = 10.sp, letterSpacing = 1.2.sp)
        }
        AndroidView(
            factory = {
                ScrollView(context).apply {
                    isFillViewport = true
                    (content.parent as? ViewGroup)?.removeView(content)
                    addView(content)
                }
            },
            modifier = Modifier.fillMaxSize()
        )
    }
}
