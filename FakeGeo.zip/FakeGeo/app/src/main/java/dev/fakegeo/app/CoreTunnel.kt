package dev.fakegeo.app

import android.os.SystemClock
import org.json.JSONObject
import java.io.IOException
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.SecureRandom

private const val T_FIN = 0x01
private const val T_SYN = 0x02
private const val T_RST = 0x04
private const val T_PSH = 0x08
private const val T_ACK = 0x10

private fun u16(b: ByteArray, o: Int): Int = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
private fun u32(b: ByteArray, o: Int): Long = (u16(b, o).toLong() shl 16) or u16(b, o + 2).toLong()

private fun hexOf(b: ByteArray, max: Int = 96): String {
    val n = minOf(b.size, max)
    val sb = StringBuilder()
    for (i in 0 until n) sb.append("%02x".format(b[i]))
    if (b.size > max) sb.append("…")
    return sb.toString()
}

/** Internet checksum over the IPv6 pseudo-header + a TCP segment. */
private fun tcpChecksum(src: ByteArray, dst: ByteArray, seg: ByteArray): Int {
    var sum = 0L
    fun add(b: ByteArray) {
        var i = 0
        while (i + 1 < b.size) { sum += (((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)).toLong(); i += 2 }
        if (b.size % 2 == 1) sum += ((b[b.size - 1].toInt() and 0xFF) shl 8).toLong()
    }
    add(src); add(dst)
    sum += ((seg.size ushr 16) and 0xFFFF).toLong()
    sum += (seg.size and 0xFFFF).toLong()
    sum += 6L                       // next header = TCP
    add(seg)
    while ((sum ushr 16) != 0L) sum = (sum and 0xFFFFL) + (sum ushr 16)
    return (sum.inv().toInt()) and 0xFFFF
}

/** Small growable byte queue. */
private class Buf {
    private var a = ByteArray(4096)
    private var s = 0
    private var e = 0
    val size: Int get() = e - s
    fun append(b: ByteArray) {
        if (e + b.size > a.size) {
            val cur = e - s
            val n = ByteArray(maxOf(a.size * 2, cur + b.size))
            System.arraycopy(a, s, n, 0, cur)
            a = n; s = 0; e = cur
        }
        System.arraycopy(b, 0, a, e, b.size)
        e += b.size
    }
    fun take(n: Int): ByteArray {
        val r = a.copyOfRange(s, s + n)
        s += n
        if (s == e) { s = 0; e = 0 }
        return r
    }
    fun takeAll(): ByteArray = take(size)
}

/**
 * Stage 3b-A/B of "iOS over USB-OTG" (iOS 17+):
 *   lockdown service com.apple.internal.devicecompute.CoreDeviceProxy  ->  "CDTunnel" handshake  ->
 *   raw IPv6 packets in both directions  ->  our own tiny TCP stack on top.
 * Written from the public description of the protocol in pymobiledevice3; not yet verified on a real iPhone.
 */
object CoreTunnel {

    class Handshake(val clientAddr: String, val serverAddr: String, val mtu: Int, val rsdPort: Int, val raw: String)

    /** Sends the clientHandshakeRequest and reads the server's answer. */
    fun handshake(s: UsbMux.Stream, nulAfterMagic: Boolean): Handshake {
        val body = "{\"type\":\"clientHandshakeRequest\",\"mtu\":16000}".toByteArray(Charsets.UTF_8)
        val bb = ByteBuffer.allocate(8 + (if (nulAfterMagic) 1 else 0) + 2 + body.size).order(ByteOrder.BIG_ENDIAN)
        bb.put("CDTunnel".toByteArray(Charsets.US_ASCII))
        if (nulAfterMagic) bb.put(0.toByte())
        bb.putShort(body.size.toShort())
        bb.put(body)
        s.write(bb.array())

        val magic = s.read(8, 10000)
        if (String(magic, Charsets.US_ASCII) != "CDTunnel") throw IOException("unexpected tunnel reply: ${hexOf(magic)}")
        val l1 = s.read(2, 5000)
        var len = u16(l1, 0)
        if (len == 0) {   // the reply has a NUL byte before the 2-byte length
            val l2 = s.read(1, 5000)
            len = ((l1[1].toInt() and 0xFF) shl 8) or (l2[0].toInt() and 0xFF)
        }
        if (len <= 0 || len > 4096) throw IOException("bad tunnel reply length $len")
        val text = String(s.read(len, 5000), Charsets.UTF_8)
        val o = JSONObject(text)
        val cp = o.getJSONObject("clientParameters")
        return Handshake(cp.getString("address"), o.getString("serverAddress"), cp.optInt("mtu", 16000), o.getInt("serverRPort"), text)
    }

    private fun addr(s: String): ByteArray {
        val a = InetAddress.getByName(s.substringBefore('%')).address
        if (a.size != 16) throw IOException("not an IPv6 address: $s")
        return a
    }

    /** Tunnel up -> open a TCP connection to the RSD port and see what the iPhone says. */
    fun probe(s: UsbMux.Stream, hs: Handshake, log: (String) -> Unit) {
        val t = Tunnel(s, addr(hs.clientAddr), addr(hs.serverAddr), hs.mtu, log)
        log("Connecting through the tunnel to [${hs.serverAddr}]:${hs.rsdPort} (RSD)…")
        val c = t.connect(hs.rsdPort) ?: return
        log("✅ TCP through the tunnel works (our own IPv6/TCP stack)")
        try {
            try {
                val first = c.readSome(2000)
                log("RSD server spoke first (${first.size} B): ${hexOf(first)}")
            } catch (e: IOException) {
                log("RSD server sent nothing first (normal, it waits for the client)")
            }
            val preface = "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n".toByteArray(Charsets.US_ASCII)
            val settings = byteArrayOf(0, 0, 0, 4, 0, 0, 0, 0, 0)   // empty HTTP/2 SETTINGS frame
            c.write(preface + settings)
            log("Sent the HTTP/2 preface + SETTINGS")
            try {
                val r = c.readSome(4000)
                log("RSD reply (${r.size} B): ${hexOf(r)}")
            } catch (e: IOException) {
                log("No reply to the HTTP/2 preface: ${e.message}")
            }
        } finally {
            c.close()
        }
    }

    /** IPv6 packets in/out of the tunnel stream + a minimal TCP (enough for a few connections). */
    class Tunnel(
        private val s: UsbMux.Stream,
        private val local: ByteArray,
        private val remote: ByteArray,
        private val mtu: Int,
        private val log: (String) -> Unit
    ) {
        private val conns = HashMap<Int, Conn>()
        private var portCounter = 49200 + SecureRandom().nextInt(10000)
        private var others = 0

        private fun now() = SystemClock.elapsedRealtime()

        private fun sendIp(payload: ByteArray) {
            val bb = ByteBuffer.allocate(40 + payload.size).order(ByteOrder.BIG_ENDIAN)
            bb.putInt(0x60000000)                       // version 6, no traffic class / flow label
            bb.putShort(payload.size.toShort())
            bb.put(6.toByte())                          // next header: TCP
            bb.put(64.toByte())                         // hop limit
            bb.put(local); bb.put(remote); bb.put(payload)
            s.write(bb.array())
        }

        /** Reads one IPv6 packet (if one arrives within [waitMs]) and hands it to its connection. */
        fun readOne(waitMs: Int): Boolean {
            val h = try {
                s.read(40, waitMs.coerceAtLeast(1))
            } catch (e: IOException) {
                if (e.message?.contains("timeout") == true) return false else throw e
            }
            if (((h[0].toInt() shr 4) and 0xF) != 6) throw IOException("tunnel sent a non-IPv6 packet: ${hexOf(h, 16)}")
            val plen = u16(h, 4)
            val next = h[6].toInt() and 0xFF
            val payload = if (plen > 0) s.read(plen, 10000) else ByteArray(0)
            if (next == 6 && payload.size >= 20) {
                conns[u16(payload, 2)]?.onSegment(payload)
            } else if (++others <= 5) {
                log("(tunnel: ignoring a packet, next header $next, ${payload.size} B)")
            }
            return true
        }

        fun connect(port: Int): Conn? {
            portCounter = if (portCounter >= 65000) 49200 else portCounter + 1
            val c = Conn(portCounter, port)
            conns[portCounter] = c
            c.seq = SecureRandom().nextInt(1 shl 20).toLong() + 1
            val mss = mtu - 60
            c.sendSeg(T_SYN, ByteArray(0), byteArrayOf(2, 4, (mss shr 8).toByte(), mss.toByte()))
            c.seq += 1
            c.acked = c.seq
            val end = now() + 6000
            while (!c.established && !c.closed && now() < end) readOne(300)
            if (!c.established) {
                conns.remove(c.lport)
                log("No SYN-ACK from port $port through the tunnel (reset=${c.reset}, closed=${c.closed})")
                return null
            }
            return c
        }

        inner class Conn(val lport: Int, val rport: Int) : UsbMux.Stream {
            var seq = 0L
            var ack = 0L
            var acked = 0L
            var established = false
            var closed = false
            var reset = false
            private var peerMss = 1220
            private var peerWin = 65535L
            private var peerWs = 0
            private val rbuf = Buf()

            fun sendSeg(flags: Int, data: ByteArray, opts: ByteArray = ByteArray(0)) {
                val tcp = ByteBuffer.allocate(20 + opts.size + data.size).order(ByteOrder.BIG_ENDIAN)
                tcp.putShort(lport.toShort()); tcp.putShort(rport.toShort())
                tcp.putInt((seq and 0xFFFFFFFFL).toInt()); tcp.putInt((ack and 0xFFFFFFFFL).toInt())
                tcp.put((((20 + opts.size) / 4) shl 4).toByte())
                tcp.put(flags.toByte())
                tcp.putShort(0xFFFF.toShort())          // our window (no scaling)
                tcp.putShort(0); tcp.putShort(0)        // checksum (filled below), urgent
                tcp.put(opts); tcp.put(data)
                val seg = tcp.array()
                val c = tcpChecksum(local, remote, seg)
                seg[16] = (c shr 8).toByte(); seg[17] = c.toByte()
                sendIp(seg)
            }

            private fun sendAck() = sendSeg(T_ACK, ByteArray(0))

            fun onSegment(p: ByteArray) {
                val flags = p[13].toInt() and 0xFF
                val hl = ((p[12].toInt() shr 4) and 0xF) * 4
                if (hl < 20 || hl > p.size) return
                val seqN = u32(p, 4)
                if (flags and T_RST != 0) { closed = true; reset = true; return }

                if (flags and T_SYN != 0 && flags and T_ACK != 0) {
                    if (established) return
                    ack = seqN + 1
                    var i = 20
                    while (i < hl) {
                        val k = p[i].toInt() and 0xFF
                        if (k == 0) break
                        if (k == 1) { i++; continue }
                        if (i + 1 >= hl) break
                        val l = p[i + 1].toInt() and 0xFF
                        if (l < 2) break
                        if (k == 2 && l == 4 && i + 3 < hl) peerMss = u16(p, i + 2)
                        if (k == 3 && l == 3 && i + 2 < hl) peerWs = p[i + 2].toInt() and 0xFF
                        i += l
                    }
                    peerWin = u16(p, 14).toLong()
                    established = true
                    sendAck()
                    return
                }

                val ackN = u32(p, 8)
                if (flags and T_ACK != 0 && ackN > acked) acked = ackN
                peerWin = u16(p, 14).toLong() shl peerWs

                val dataLen = p.size - hl
                if (dataLen > 0) {
                    if (seqN == (ack and 0xFFFFFFFFL)) {
                        rbuf.append(p.copyOfRange(hl, p.size))
                        ack += dataLen
                    }
                    sendAck()                           // also re-acks duplicates
                }
                if (flags and T_FIN != 0 && seqN + dataLen == (ack and 0xFFFFFFFFL)) {
                    ack += 1
                    closed = true
                    sendAck()
                }
            }

            private fun fail(): Nothing =
                throw IOException(if (reset) "connection reset by the iPhone" else "connection closed by the iPhone")

            override fun write(data: ByteArray) {
                if (closed) fail()
                val mss = minOf(peerMss, mtu - 60).coerceAtLeast(536)
                var off = 0
                var lastProgress = now()
                var lastAcked = acked
                while (off < data.size) {
                    val n = minOf(mss, data.size - off)
                    while (seq - acked + n > peerWin) {
                        readOne(200)
                        if (closed) fail()
                        if (acked > lastAcked) { lastAcked = acked; lastProgress = now() }
                        else if (now() - lastProgress > 15000) throw IOException("the iPhone stopped acknowledging data")
                    }
                    sendSeg(T_ACK or T_PSH, data.copyOfRange(off, off + n))
                    seq += n
                    off += n
                }
            }

            override fun read(n: Int, timeoutMs: Int): ByteArray {
                val end = now() + timeoutMs
                while (rbuf.size < n) {
                    if (closed) fail()
                    val left = end - now()
                    if (left <= 0) throw IOException("timeout waiting for the iPhone")
                    readOne(left.toInt().coerceAtMost(500))
                }
                return rbuf.take(n)
            }

            override fun readSome(timeoutMs: Int): ByteArray {
                val end = now() + timeoutMs
                while (rbuf.size == 0) {
                    if (closed) fail()
                    val left = end - now()
                    if (left <= 0) throw IOException("timeout waiting for the iPhone")
                    readOne(left.toInt().coerceAtMost(500))
                }
                return rbuf.takeAll()
            }

            override fun close() {
                try { sendSeg(T_RST or T_ACK, ByteArray(0)) } catch (_: Exception) {}
                conns.remove(lport)
            }
        }
    }
}
