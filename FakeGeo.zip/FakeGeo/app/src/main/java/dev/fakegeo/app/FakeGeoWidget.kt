package dev.fakegeo.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews

/** Home-screen widget: tap to switch the fake GPS on/off using the last saved pin. */
class FakeGeoWidget : AppWidgetProvider() {

    companion object {
        const val ACTION_TOGGLE = "dev.fakegeo.WIDGET_TOGGLE"

        fun refresh(c: Context) {
            val mgr = AppWidgetManager.getInstance(c)
            val ids = mgr.getAppWidgetIds(ComponentName(c, FakeGeoWidget::class.java))
            if (ids.isEmpty()) return
            for (id in ids) mgr.updateAppWidget(id, views(c))
        }

        private fun views(c: Context): RemoteViews {
            val on = c.getSharedPreferences("fakegeo", Context.MODE_PRIVATE).getBoolean("active", false)
            val v = RemoteViews(c.packageName, R.layout.widget_toggle)
            v.setTextViewText(R.id.widget_state, if (on) "ON" else "OFF")
            v.setTextColor(R.id.widget_state, Color.parseColor(if (on) "#22C55E" else "#94A3B8"))
            val pi = PendingIntent.getBroadcast(
                c, 0, Intent(c, FakeGeoWidget::class.java).setAction(ACTION_TOGGLE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.widget_root, pi)
            return v
        }
    }

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, views(c))
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action != ACTION_TOGGLE) return
        val p = c.getSharedPreferences("fakegeo", Context.MODE_PRIVATE)
        if (p.getBoolean("active", false)) {
            p.edit().putBoolean("active", false).apply()
            c.stopService(Intent(c, MockLocationService::class.java))
            MockState.running = false
        } else if (p.getString("pin_lat", null) != null) {
            p.edit().putBoolean("active", true).apply()
            c.startForegroundService(
                Intent(c, MockLocationService::class.java).setAction(MockLocationService.ACTION_START)
            )
        } else {
            c.startActivity(Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        refresh(c)
    }
}
