package dev.fakegeo.app

import android.os.SystemClock
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale

private fun dle32(b: ByteArray, o: Int): Long =
    (b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or
        ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24)

private fun dle16(b: ByteArray, o: Int): Int = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)

/**
 * Stage 3b-D: the Instruments "DTX" protocol on com.apple.instruments.dtservicehub, used only for
 * the LocationSimulation channel (simulateLocationWithLatitude:longitude:).
 * Written from the public description of the protocol (pymobiledevice3); not yet verified on a real iPhone,
 * so every message is logged.
 */
object Dtx {

    private const val MAGIC = 0x1F3D5B79

    class Msg(
        val id: Long, val conv: Long, val channel: Int, val expectsReply: Boolean,
        val flags: Long, val aux: ByteArray, val payload: ByteArray
    )

    // ------------------------------------------------------------------ NSKeyedArchiver (XML or binary plist)

    class Uid(val n: Int)

    private fun esc(x: String) = x.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun xml(o: Any?, sb: StringBuilder) {
        when (o) {
            is Uid -> sb.append("<dict><key>CF\$UID</key><integer>${o.n}</integer></dict>")
            is Map<*, *> -> { sb.append("<dict>"); for ((k, v) in o) { sb.append("<key>${esc(k.toString())}</key>"); xml(v, sb) }; sb.append("</dict>") }
            is List<*> -> { sb.append("<array>"); for (v in o) xml(v, sb); sb.append("</array>") }
            is String -> sb.append("<string>${esc(o)}</string>")
            is Double -> sb.append("<real>${String.format(Locale.US, "%.9f", o)}</real>")
            is Number -> sb.append("<integer>${o.toLong()}</integer>")
            is Boolean -> sb.append(if (o) "<true/>" else "<false/>")
            else -> throw IOException("plist: unsupported type")
        }
    }

    private fun xmlDoc(root: Any): ByteArray {
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n")
        sb.append("<plist version=\"1.0\">")
        xml(root, sb)
        sb.append("</plist>")
        return sb.toString().toByteArray(Charsets.UTF_8)
    }

    /** Minimal binary plist ("bplist00") writer: dict, array, string, integer, real, bool, UID. */
    private fun bplist(root: Any): ByteArray {
        class Node(val leaf: Any?, val isDict: Boolean, val isArray: Boolean, val kids: IntArray)
        val nodes = ArrayList<Node?>()
        fun flat(o: Any?): Int {
            val i = nodes.size
            nodes.add(null)
            when (o) {
                is Map<*, *> -> {
                    val ks = o.keys.map { flat(it.toString()) }
                    val vs = o.values.map { flat(it) }
                    nodes[i] = Node(null, true, false, (ks + vs).toIntArray())
                }
                is List<*> -> nodes[i] = Node(null, false, true, o.map { flat(it) }.toIntArray())
                else -> nodes[i] = Node(o, false, false, IntArray(0))
            }
            return i
        }
        flat(root)
        val rs = if (nodes.size < 256) 1 else 2
        val out = ByteArrayOutputStream()
        out.write("bplist00".toByteArray(Charsets.US_ASCII))
        val offsets = IntArray(nodes.size)

        fun be(v: Long, n: Int) { for (k in n - 1 downTo 0) out.write(((v shr (8 * k)) and 0xFF).toInt()) }
        fun intObj(v: Long) {
            when {
                v in 0..0xFF -> { out.write(0x10); be(v, 1) }
                v in 0..0xFFFF -> { out.write(0x11); be(v, 2) }
                v in 0..0xFFFFFFFFL -> { out.write(0x12); be(v, 4) }
                else -> { out.write(0x13); be(v, 8) }
            }
        }
        fun marker(base: Int, n: Int) { if (n < 15) out.write(base or n) else { out.write(base or 0xF); intObj(n.toLong()) } }

        for ((idx, nd) in nodes.withIndex()) {
            offsets[idx] = out.size()
            nd!!
            if (nd.isDict) {
                marker(0xD0, nd.kids.size / 2)
                for (r in nd.kids) be(r.toLong(), rs)
            } else if (nd.isArray) {
                marker(0xA0, nd.kids.size)
                for (r in nd.kids) be(r.toLong(), rs)
            } else when (val o = nd.leaf) {
                is Uid -> { out.write(0x80); be(o.n.toLong(), 1) }
                is String -> {
                    if (o.all { it.code < 128 }) { marker(0x50, o.length); out.write(o.toByteArray(Charsets.US_ASCII)) }
                    else { marker(0x60, o.length); out.write(o.toByteArray(Charsets.UTF_16BE)) }
                }
                is Double -> { out.write(0x23); be(java.lang.Double.doubleToLongBits(o), 8) }
                is Boolean -> out.write(if (o) 0x09 else 0x08)
                is Number -> intObj(o.toLong())
                else -> throw IOException("bplist: unsupported type")
            }
        }
        val tableOff = out.size()
        val offSize = if (tableOff < 256) 1 else if (tableOff < 65536) 2 else 4
        for (o in offsets) be(o.toLong(), offSize)
        for (k in 0 until 6) out.write(0)
        out.write(offSize); out.write(rs)
        be(nodes.size.toLong(), 8); be(0L, 8); be(tableOff.toLong(), 8)
        return out.toByteArray()
    }

    /** Wraps [objects] (everything after "$null"; the first one is the root) in an NSKeyedArchiver document. */
    private fun archive(bin: Boolean, objects: List<Any?>): ByteArray {
        val doc = linkedMapOf<String, Any?>(
            "\$archiver" to "NSKeyedArchiver",
            "\$objects" to listOf<Any?>("\$null") + objects,
            "\$top" to linkedMapOf<String, Any?>("root" to Uid(1)),
            "\$version" to 100000L
        )
        return if (bin) bplist(doc) else xmlDoc(doc)
    }

    private fun archiveString(bin: Boolean, x: String) = archive(bin, listOf(x))

    private fun archiveDouble(bin: Boolean, d: Double) = archive(bin, listOf(d))

    /** NSDictionary<String, Long> */
    private fun archiveDict(bin: Boolean, m: Map<String, Long>): ByteArray {
        val keys = ArrayList<Any?>(); val vals = ArrayList<Any?>(); val items = ArrayList<Any?>()
        var idx = 3
        for ((k, v) in m) {
            keys.add(Uid(idx)); items.add(k); idx++
            vals.add(Uid(idx)); items.add(v); idx++
        }
        val dict = linkedMapOf<String, Any?>("NS.keys" to keys, "NS.objects" to vals, "\$class" to Uid(2))
        val cls = linkedMapOf<String, Any?>("\$classname" to "NSDictionary", "\$classes" to listOf("NSDictionary", "NSObject"))
        return archive(bin, listOf<Any?>(dict, cls) + items)
    }

    // ------------------------------------------------------------------ DTX framing

    private fun buildAux(args: List<Any>, bin: Boolean): ByteArray {
        if (args.isEmpty()) return ByteArray(0)
        val body = ByteArrayOutputStream()
        fun i32(v: Int) { body.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array()) }
        fun i64(v: Long) { body.write(ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(v).array()) }
        fun obj(b: ByteArray) { i32(2); i32(b.size); body.write(b) }
        for (a in args) {
            i32(0x0a)                       // empty key
            when (a) {
                is Int -> { i32(3); i32(a) }
                is Long -> { i32(4); i64(a) }
                is Double -> obj(archiveDouble(bin, a))
                is String -> obj(archiveString(bin, a))
                is Map<*, *> -> {
                    val m = LinkedHashMap<String, Long>()
                    for ((k, v) in a) m[k.toString()] = (v as Number).toLong()
                    obj(archiveDict(bin, m))
                }
                else -> throw IOException("DTX: unsupported argument type ${a.javaClass.simpleName}")
            }
        }
        val b = body.toByteArray()
        val bb = ByteBuffer.allocate(16 + b.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.putLong(0x1f0L)
        bb.putLong(b.size.toLong())
        bb.put(b)
        return bb.array()
    }

    private fun printable(b: ByteArray, minRun: Int = 5, max: Int = 240): String {
        val out = StringBuilder()
        val cur = StringBuilder()
        fun flush() {
            if (cur.length >= minRun) { if (out.isNotEmpty()) out.append(" | "); out.append(cur) }
            cur.setLength(0)
        }
        for (x in b) {
            val c = x.toInt() and 0xFF
            if (c in 0x20..0x7e) cur.append(c.toChar()) else flush()
        }
        flush()
        return if (out.length > max) out.substring(0, max) + "…" else out.toString()
    }

    class Conn(private val s: UsbMux.Stream, private val log: (String) -> Unit, private val bin: Boolean) {
        private var nextId = 1

        fun send(channel: Int, selector: String?, args: List<Any>, expectsReply: Boolean): Int {
            val aux = buildAux(args, bin)
            val sel = if (selector != null) archiveString(bin, selector) else ByteArray(0)
            val id = nextId++
            val total = aux.size + sel.size
            val bb = ByteBuffer.allocate(32 + 16 + total).order(ByteOrder.LITTLE_ENDIAN)
            bb.putInt(MAGIC)
            bb.putInt(32)                           // header length
            bb.putShort(0); bb.putShort(1)          // fragment 0 of 1
            bb.putInt(16 + total)
            bb.putInt(id)
            bb.putInt(0)                            // conversation index
            bb.putInt(channel)
            bb.putInt(if (expectsReply) 1 else 0)
            bb.putInt(2)                            // payload type 2 = method invocation (reply or not)
            bb.putInt(aux.size)
            bb.putLong(total.toLong())
            bb.put(aux); bb.put(sel)
            s.write(bb.array())
            return id
        }

        fun recv(timeoutMs: Int): Msg {
            var h = s.read(32, timeoutMs)
            val acc = ByteArrayOutputStream()
            var id = 0L; var conv = 0L; var channel = 0; var expects = false
            var first = true
            while (true) {
                if (dle32(h, 0).toInt() != MAGIC) throw IOException("DTX: bad magic ${h.copyOf(8).joinToString("") { "%02x".format(it) }}")
                val cb = dle32(h, 4).toInt()
                if (cb > 32) s.read(cb - 32, 5000)
                val fid = dle16(h, 8)
                val fcount = dle16(h, 10)
                val len = dle32(h, 12).toInt()
                if (first) {
                    id = dle32(h, 16); conv = dle32(h, 20); channel = dle32(h, 24).toInt(); expects = dle32(h, 28) != 0L
                    first = false
                }
                if (len < 0 || len > 16_000_000) throw IOException("DTX: absurd length $len")
                if (fcount <= 1) { acc.write(s.read(len, 10000)); break }
                if (fid != 0) acc.write(s.read(len, 10000))      // the first fragment carries no data
                if (fid == fcount - 1) break
                h = s.read(32, 10000)
            }
            val d = acc.toByteArray()
            val msg: Msg
            if (d.size < 16) {
                msg = Msg(id, conv, channel, expects, 0, ByteArray(0), ByteArray(0))
            } else {
                val flags = dle32(d, 0)
                val auxLen = dle32(d, 4).toInt()
                val total = (dle32(d, 8) or (dle32(d, 12) shl 32)).toInt()
                val auxEnd = (16 + auxLen).coerceAtMost(d.size)
                val payEnd = (16 + total).coerceIn(auxEnd, d.size)
                msg = Msg(id, conv, channel, expects, flags, d.copyOfRange(16, auxEnd), d.copyOfRange(auxEnd, payEnd))
            }
            // A method invocation that expects a reply must be acknowledged.
            if (msg.expectsReply && (msg.flags and 0xFF) == 2L) {
                try { sendAck(msg) } catch (e: IOException) { log("  DTX: could not acknowledge message ${msg.id}: ${e.message}") }
            }
            return msg
        }

        private fun sendAck(m: Msg) {
            val bb = ByteBuffer.allocate(48).order(ByteOrder.LITTLE_ENDIAN)
            bb.putInt(MAGIC); bb.putInt(32)
            bb.putShort(0); bb.putShort(1)
            bb.putInt(16)
            bb.putInt(m.id.toInt()); bb.putInt((m.conv + 1).toInt()); bb.putInt(m.channel); bb.putInt(0)
            bb.putInt(0); bb.putInt(0); bb.putLong(0)       // payload type 0 = Ack, no aux, no payload
            s.write(bb.array())
            log("  DTX -> ack for message ${m.id}")
        }

        fun describe(m: Msg): String =
            "  DTX <- id ${m.id} conv ${m.conv} channel ${m.channel} flags 0x%x expectsReply ${m.expectsReply} aux ${m.aux.size} B payload ${m.payload.size} B  [%s]  aux[%s]"
                .format(m.flags, printable(m.payload), printable(m.aux, 4, 120))

        /** Reads messages until [accept] says yes or [maxMsgs] were read. */
        fun waitFor(maxMsgs: Int, timeoutMs: Int, accept: (Msg) -> Boolean): Msg? {
            for (i in 0 until maxMsgs) {
                val m = recv(timeoutMs)
                log(describe(m))
                if (accept(m)) return m
            }
            return null
        }
    }

    // ------------------------------------------------------------------ LocationSimulation

    const val R_FAIL = 0      // could not even set up the channel
    const val R_REJECTED = 1  // the iPhone dropped the connection right after the location message
    const val R_OK = 2        // the connection stayed open for the whole time

    /**
     * Opens the LocationSimulation channel, sets the location, keeps the connection alive for [holdSec] seconds
     * (the simulation stops when the connection closes) and then clears it.
     * [bin]: archive arguments as binary plist (what pymobiledevice3 does) instead of XML plist.
     * [wantReply]: ask the iPhone for an answer to the location message (it may then describe an error).
     */
    fun simulateLocation(
        s: UsbMux.Stream, lat: Double, lon: Double, holdSec: Int, bin: Boolean, wantReply: Boolean,
        pumpTunnel: (Int) -> Unit, log: (String) -> Unit
    ): Int {
        val c = Conn(s, log, bin)

        log("DTX: sending our capabilities (${if (bin) "binary" else "XML"} plist)")
        c.send(
            0, "_notifyOfPublishedCapabilities:",
            listOf(mapOf("com.apple.private.DTXBlockCompression" to 0L, "com.apple.private.DTXConnection" to 1L)),
            false
        )
        val caps = c.waitFor(6, 5000) { String(it.payload, Charsets.ISO_8859_1).contains("_notifyOfPublishedCapabilities:") }
        if (caps == null) { log("DTX: the iPhone did not answer the capabilities exchange."); return R_FAIL }
        log("DTX: capabilities exchanged")

        val code = 1
        log("DTX: requesting the LocationSimulation channel")
        val reqId = c.send(
            0, "_requestChannelWithCode:identifier:",
            listOf(code, "com.apple.instruments.server.services.LocationSimulation"), true
        )
        val rep = c.waitFor(6, 5000) { it.id == reqId.toLong() }
        if (rep == null) { log("DTX: no answer to the channel request."); return R_FAIL }
        if (rep.flags and 0xFF == 4L) { log("DTX: the iPhone refused the channel (error reply)."); return R_FAIL }
        log("DTX: channel open")

        log("DTX: simulateLocationWithLatitude:longitude: ($lat, $lon)${if (wantReply) " (asking for a reply)" else ""}")
        val sentAt = SystemClock.elapsedRealtime()
        val locId = c.send(code, "simulateLocationWithLatitude:longitude:", listOf(lat, lon), wantReply)
        log("▶ Location sent. Open Maps on the iPhone now (it stays for $holdSec s while this connection is open).")

        var answered = false
        val end = sentAt + holdSec * 1000L
        var nextNote = sentAt + 10000L
        while (SystemClock.elapsedRealtime() < end) {
            val nowMs = SystemClock.elapsedRealtime()
            if (nowMs >= nextNote) { log("  … still connected (${(nowMs - sentAt) / 1000} s)"); nextNote += 10000L }
            try {
                val m = c.recv(500)
                log(c.describe(m))
                if (wantReply && m.id == locId.toLong()) {
                    answered = true
                    val t = (m.flags and 0xFF).toInt()
                    log("  ↳ the iPhone's answer to the location message: type $t (${when (t) { 0 -> "OK / acknowledged"; 3 -> "OK with a value"; 4 -> "ERROR"; else -> "?" }})")
                }
            } catch (e: IOException) {
                if (e.message?.contains("timeout") != true) {
                    val ms = SystemClock.elapsedRealtime() - sentAt
                    log("DTX: the connection ended after ${ms / 1000.0} s (planned $holdSec s): ${e.message}")
                    return if (ms < 3000) R_REJECTED else R_OK
                }
                pumpTunnel(0)
            }
        }

        if (wantReply && !answered) log("DTX: the iPhone never answered the location message.")
        log("DTX: stopLocationSimulation")
        try { c.send(code, "stopLocationSimulation", emptyList(), false) } catch (e: IOException) { log("DTX: could not send stop: ${e.message}") }
        return R_OK
    }

    /**
     * Live mode: opens the LocationSimulation channel and then keeps sending the position from [IosFeed]
     * until [IosSession.stopRequested]. Returns true after a normal stop, false if the connection broke
     * (the caller reconnects).
     */
    fun live(s: UsbMux.Stream, pumpTunnel: (Int) -> Unit, log: (String) -> Unit): Boolean {
        val c = Conn(s, log, true)
        c.send(
            0, "_notifyOfPublishedCapabilities:",
            listOf(mapOf("com.apple.private.DTXBlockCompression" to 0L, "com.apple.private.DTXConnection" to 1L)),
            false
        )
        val caps = c.waitFor(6, 5000) { String(it.payload, Charsets.ISO_8859_1).contains("_notifyOfPublishedCapabilities:") }
        if (caps == null) { log("DTX: the iPhone did not answer the capabilities exchange."); return false }
        val code = 1
        val reqId = c.send(
            0, "_requestChannelWithCode:identifier:",
            listOf(code, "com.apple.instruments.server.services.LocationSimulation"), true
        )
        val rep = c.waitFor(6, 5000) { it.id == reqId.toLong() }
        if (rep == null) { log("DTX: no answer to the channel request."); return false }
        if (rep.flags and 0xFF == 4L) { log("DTX: the iPhone refused the channel (error reply)."); return false }
        log("DTX: channel open (live mode)")
        IosState.status = "Connected, waiting for a position…"

        var lastSeq = -1L
        var lastSendAt = 0L
        while (!IosSession.stopRequested()) {
            val la = IosFeed.lat
            val lo = IosFeed.lon
            val sq = IosFeed.seq
            val now = SystemClock.elapsedRealtime()
            if (!la.isNaN() && !lo.isNaN() && (sq != lastSeq || now - lastSendAt > 5000)) {
                try {
                    c.send(code, "simulateLocationWithLatitude:longitude:", listOf(la, lo), true)
                } catch (e: IOException) {
                    log("DTX: could not send the position: ${e.message}")
                    return false
                }
                lastSeq = sq
                lastSendAt = now
                IosState.updates++
                IosState.status = "Connected: the iPhone is at ${"%.5f".format(Locale.US, la)}, ${"%.5f".format(Locale.US, lo)}"
            }
            try {
                val m = c.recv(200)
                if ((m.flags and 0xFF) == 4L) log(c.describe(m))     // only errors are interesting
            } catch (e: IOException) {
                if (e.message?.contains("timeout") != true) {
                    log("DTX: the connection ended: ${e.message}")
                    return false
                }
                pumpTunnel(0)
            }
        }

        log("DTX: stopLocationSimulation")
        try { c.send(code, "stopLocationSimulation", emptyList(), false) } catch (e: IOException) { log("DTX: could not send stop: ${e.message}") }
        val end = SystemClock.elapsedRealtime() + 400
        while (SystemClock.elapsedRealtime() < end) pumpTunnel(0)
        return true
    }
}
