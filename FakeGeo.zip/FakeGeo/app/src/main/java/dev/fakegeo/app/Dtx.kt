package dev.fakegeo.app

import android.os.SystemClock
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale

private fun dle32(b: ByteArray, o: Int): Long =
    (b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or
        ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24)

private fun dle16(b: ByteArray, o: Int): Int = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)

/**
 * Stage 3b-D: the Instruments "DTX" protocol on com.apple.instruments.dtservicehub, used only for
 * the LocationSimulation channel (simulateLocationWithLatitude:longitude:).
 * Written from the public description of the protocol (pymobiledevice3); not yet verified on a real iPhone,
 * so every message is logged.
 */
object Dtx {

    private const val MAGIC = 0x1F3D5B79

    class Msg(
        val id: Long, val conv: Long, val channel: Int, val expectsReply: Boolean,
        val flags: Long, val aux: ByteArray, val payload: ByteArray
    )

    // ------------------------------------------------------------------ NSKeyedArchiver (XML flavour)

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun uid(n: Int) = "<dict><key>CF\$UID</key><integer>$n</integer></dict>"

    private fun keyed(objects: String): ByteArray {
        val x = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n" +
            "<plist version=\"1.0\"><dict>" +
            "<key>\$archiver</key><string>NSKeyedArchiver</string>" +
            "<key>\$objects</key><array><string>\$null</string>$objects</array>" +
            "<key>\$top</key><dict><key>root</key>${uid(1)}</dict>" +
            "<key>\$version</key><integer>100000</integer>" +
            "</dict></plist>"
        return x.toByteArray(Charsets.UTF_8)
    }

    private fun archiveString(s: String) = keyed("<string>${esc(s)}</string>")

    private fun archiveDouble(d: Double) = keyed("<real>${String.format(Locale.US, "%.9f", d)}</real>")

    /** NSDictionary<String, Long> */
    private fun archiveDict(m: Map<String, Long>): ByteArray {
        val n = m.size
        val keysUids = StringBuilder()
        val valsUids = StringBuilder()
        val items = StringBuilder()
        var idx = 3
        for ((k, v) in m) {
            keysUids.append(uid(idx)); items.append("<string>${esc(k)}</string>"); idx++
            valsUids.append(uid(idx)); items.append("<integer>$v</integer>"); idx++
        }
        val dict = "<dict><key>\$class</key>${uid(2)}" +
            "<key>NS.keys</key><array>$keysUids</array>" +
            "<key>NS.objects</key><array>$valsUids</array></dict>"
        val cls = "<dict><key>\$classname</key><string>NSDictionary</string>" +
            "<key>\$classes</key><array><string>NSDictionary</string><string>NSObject</string></array></dict>"
        check(n >= 0)
        return keyed(dict + cls + items)
    }

    // ------------------------------------------------------------------ DTX framing

    private fun buildAux(args: List<Any>): ByteArray {
        if (args.isEmpty()) return ByteArray(0)
        val body = ByteArrayOutputStream()
        fun i32(v: Int) { body.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array()) }
        fun i64(v: Long) { body.write(ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(v).array()) }
        fun obj(b: ByteArray) { i32(2); i32(b.size); body.write(b) }
        for (a in args) {
            i32(0x0a)                       // empty key
            when (a) {
                is Int -> { i32(3); i32(a) }
                is Long -> { i32(4); i64(a) }
                is Double -> obj(archiveDouble(a))
                is String -> obj(archiveString(a))
                is Map<*, *> -> {
                    val m = LinkedHashMap<String, Long>()
                    for ((k, v) in a) m[k.toString()] = (v as Number).toLong()
                    obj(archiveDict(m))
                }
                else -> throw IOException("DTX: unsupported argument type ${a.javaClass.simpleName}")
            }
        }
        val b = body.toByteArray()
        val bb = ByteBuffer.allocate(16 + b.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.putLong(0x1f0L)
        bb.putLong(b.size.toLong())
        bb.put(b)
        return bb.array()
    }

    private fun printable(b: ByteArray, minRun: Int = 5, max: Int = 240): String {
        val out = StringBuilder()
        val cur = StringBuilder()
        fun flush() {
            if (cur.length >= minRun) { if (out.isNotEmpty()) out.append(" | "); out.append(cur) }
            cur.setLength(0)
        }
        for (x in b) {
            val c = x.toInt() and 0xFF
            if (c in 0x20..0x7e) cur.append(c.toChar()) else flush()
        }
        flush()
        return if (out.length > max) out.substring(0, max) + "…" else out.toString()
    }

    class Conn(private val s: UsbMux.Stream, private val log: (String) -> Unit) {
        private var nextId = 1

        fun send(channel: Int, selector: String?, args: List<Any>, expectsReply: Boolean): Int {
            val aux = buildAux(args)
            val sel = if (selector != null) archiveString(selector) else ByteArray(0)
            val id = nextId++
            val total = aux.size + sel.size
            val bb = ByteBuffer.allocate(32 + 16 + total).order(ByteOrder.LITTLE_ENDIAN)
            bb.putInt(MAGIC)
            bb.putInt(32)                           // header length
            bb.putShort(0); bb.putShort(1)          // fragment 0 of 1
            bb.putInt(16 + total)
            bb.putInt(id)
            bb.putInt(0)                            // conversation index
            bb.putInt(channel)
            bb.putInt(if (expectsReply) 1 else 0)
            bb.putInt(if (expectsReply) 2 else 1)   // payload flags
            bb.putInt(aux.size)
            bb.putLong(total.toLong())
            bb.put(aux); bb.put(sel)
            s.write(bb.array())
            return id
        }

        fun recv(timeoutMs: Int): Msg {
            var h = s.read(32, timeoutMs)
            val acc = ByteArrayOutputStream()
            var id = 0L; var conv = 0L; var channel = 0; var expects = false
            var first = true
            while (true) {
                if (dle32(h, 0).toInt() != MAGIC) throw IOException("DTX: bad magic ${h.copyOf(8).joinToString("") { "%02x".format(it) }}")
                val cb = dle32(h, 4).toInt()
                if (cb > 32) s.read(cb - 32, 5000)
                val fid = dle16(h, 8)
                val fcount = dle16(h, 10)
                val len = dle32(h, 12).toInt()
                if (first) {
                    id = dle32(h, 16); conv = dle32(h, 20); channel = dle32(h, 24).toInt(); expects = dle32(h, 28) != 0L
                    first = false
                }
                if (len < 0 || len > 16_000_000) throw IOException("DTX: absurd length $len")
                if (fcount <= 1) { acc.write(s.read(len, 10000)); break }
                if (fid != 0) acc.write(s.read(len, 10000))      // the first fragment carries no data
                if (fid == fcount - 1) break
                h = s.read(32, 10000)
            }
            val d = acc.toByteArray()
            if (d.size < 16) return Msg(id, conv, channel, expects, 0, ByteArray(0), ByteArray(0))
            val flags = dle32(d, 0)
            val auxLen = dle32(d, 4).toInt()
            val total = (dle32(d, 8) or (dle32(d, 12) shl 32)).toInt()
            val auxEnd = (16 + auxLen).coerceAtMost(d.size)
            val payEnd = (16 + total).coerceIn(auxEnd, d.size)
            return Msg(id, conv, channel, expects, flags, d.copyOfRange(16, auxEnd), d.copyOfRange(auxEnd, payEnd))
        }

        fun describe(m: Msg): String =
            "  DTX <- id ${m.id} conv ${m.conv} channel ${m.channel} flags 0x%x aux ${m.aux.size} B payload ${m.payload.size} B  [%s]  aux[%s]"
                .format(m.flags, printable(m.payload), printable(m.aux, 4, 120))

        /** Reads messages until [accept] says yes or [maxMsgs] were read. */
        fun waitFor(maxMsgs: Int, timeoutMs: Int, accept: (Msg) -> Boolean): Msg? {
            for (i in 0 until maxMsgs) {
                val m = recv(timeoutMs)
                log(describe(m))
                if (accept(m)) return m
            }
            return null
        }
    }

    // ------------------------------------------------------------------ LocationSimulation

    /**
     * Opens the LocationSimulation channel, sets the location, keeps the connection alive for [holdSec] seconds
     * (the simulation stops when the connection closes) and then clears it.
     * [pumpTunnel] must keep the tunnel's packets flowing while we wait.
     */
    fun simulateLocation(
        s: UsbMux.Stream, lat: Double, lon: Double, holdSec: Int,
        pumpTunnel: (Int) -> Unit, log: (String) -> Unit
    ): Boolean {
        val c = Conn(s, log)

        log("DTX: sending our capabilities")
        c.send(
            0, "_notifyOfPublishedCapabilities:",
            listOf(mapOf("com.apple.private.DTXBlockCompression" to 0L, "com.apple.private.DTXConnection" to 1L)),
            false
        )
        val caps = c.waitFor(6, 5000) { String(it.payload, Charsets.ISO_8859_1).contains("_notifyOfPublishedCapabilities:") }
        if (caps == null) { log("DTX: the iPhone did not answer the capabilities exchange."); return false }
        log("DTX: capabilities exchanged")

        val code = 1
        log("DTX: requesting the LocationSimulation channel")
        val reqId = c.send(
            0, "_requestChannelWithCode:identifier:",
            listOf(code, "com.apple.instruments.server.services.LocationSimulation"), true
        )
        val rep = c.waitFor(6, 5000) { it.id == reqId.toLong() }
        if (rep == null) { log("DTX: no answer to the channel request."); return false }
        if (rep.flags and 0xFF == 4L) { log("DTX: the iPhone refused the channel (error reply)."); return false }
        log("DTX: channel open")

        log("DTX: simulateLocationWithLatitude:longitude: ($lat, $lon)")
        c.send(code, "simulateLocationWithLatitude:longitude:", listOf(lat, lon), false)
        log("▶ Location sent. Open Maps on the iPhone now (it stays for $holdSec s while this connection is open).")

        val end = SystemClock.elapsedRealtime() + holdSec * 1000L
        while (SystemClock.elapsedRealtime() < end) {
            try {
                val m = c.recv(500)
                log(c.describe(m))
            } catch (e: IOException) {
                if (e.message?.contains("timeout") != true) { log("DTX: connection ended: ${e.message}"); return true }
                pumpTunnel(0)
            }
        }

        log("DTX: stopLocationSimulation")
        try { c.send(code, "stopLocationSimulation", emptyList(), false) } catch (e: IOException) { log("DTX: could not send stop: ${e.message}") }
        return true
    }
}
