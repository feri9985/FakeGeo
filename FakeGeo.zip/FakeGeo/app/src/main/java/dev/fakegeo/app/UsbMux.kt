package dev.fakegeo.app

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.SystemClock
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Stage 1 of "iOS over USB-OTG": talk to an iPhone directly from this phone.
 *
 *   USB bulk  ->  usbmux packets  ->  a small TCP stack  ->  lockdownd (port 62078)
 *
 * This stage only OPENS the channel and asks lockdownd things it answers before pairing
 * (iOS version, model). It changes nothing on the iPhone. Next stages (not here yet):
 *   2) pairing (Trust prompt) + TLS session
 *   3) iOS <= 16: mount Developer Disk Image + com.apple.dt.simulatelocation
 *      iOS 17+  : CoreDevice tunnel (RemoteXPC) + DVT location simulation
 */
object UsbMux {

    const val APPLE_VID = 0x05AC
    private const val ACTION_PERM = "dev.fakegeo.USB_PERMISSION"

    private fun manager(ctx: Context) = ctx.getSystemService(Context.USB_SERVICE) as UsbManager

    fun findIphone(ctx: Context): UsbDevice? =
        manager(ctx).deviceList.values.firstOrNull { it.vendorId == APPLE_VID }

    /** Asks Android for USB access to this device. [cb] runs on the main thread. */
    fun requestPermission(ctx: Context, dev: UsbDevice, cb: (Boolean) -> Unit) {
        val m = manager(ctx)
        if (m.hasPermission(dev)) { cb(true); return }
        val app = ctx.applicationContext
        val rcv = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                try { app.unregisterReceiver(this) } catch (_: Exception) {}
                cb(i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
            }
        }
        val f = IntentFilter(ACTION_PERM)
        if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(rcv, f, Context.RECEIVER_NOT_EXPORTED)
        else app.registerReceiver(rcv, f)
        // The system fills in extras, so the PendingIntent must be mutable (and explicit on Android 14+).
        val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        val pi = PendingIntent.getBroadcast(app, 0, Intent(ACTION_PERM).setPackage(app.packageName), flags)
        m.requestPermission(dev, pi)
    }

    /** Blocking. Call from a background thread. Returns a human-readable report. */
    fun probe(ctx: Context, dev: UsbDevice): String {
        val sb = StringBuilder()
        fun p(s: String) { sb.appendLine(s); MockState.log("USB: $s") }

        p("USB device vid=%04x pid=%04x".format(dev.vendorId, dev.productId))
        var link: MuxLink? = null
        try {
            link = MuxLink.open(manager(ctx), dev, ::p) ?: return sb.toString()
            if (!link.handshake()) return sb.toString()

            val tcp = link.connect(62078)
            if (tcp == null) {
                p("Could not open lockdownd (port 62078). Is the iPhone unlocked?")
                return sb.toString()
            }
            p("Connected to lockdownd")

            val type = Lockdown.request(tcp, mapOf("Request" to "QueryType"))
            p("QueryType: ${Lockdown.value(type, "Type") ?: Lockdown.value(type, "Error") ?: "?"}")

            val info = LinkedHashMap<String, String?>()
            for (k in listOf("ProductVersion", "ProductType", "DeviceName", "BuildVersion", "DeviceClass", "PasswordProtected")) {
                val r = Lockdown.request(tcp, mapOf("Request" to "GetValue", "Key" to k))
                info[k] = Lockdown.value(r, "Value")
                val err = Lockdown.value(r, "Error")
                p("$k = ${info[k] ?: "(none${if (err != null) ": $err" else ""})"}")
            }
            tcp.close()

            val ver = info["ProductVersion"]
            val major = ver?.substringBefore('.')?.toIntOrNull()
            p("")
            when {
                major == null ->
                    p("Verdict: iOS version not readable before pairing. Unlock the iPhone and re-run; stage 2 (pairing) will be needed.")
                major >= 17 ->
                    p("Verdict: iOS $ver. Needs the CoreDevice tunnel + Developer Mode (hard path, stage 3b).")
                else ->
                    p("Verdict: iOS $ver. Classic path: pair, mount Developer Disk Image, com.apple.dt.simulatelocation (stage 3a).")
            }
            p("USB channel works: usbmux + lockdownd reachable from Android.")
        } catch (e: Exception) {
            p("ERROR: ${e.javaClass.simpleName}: ${e.message}")
        } finally {
            link?.close()
        }
        return sb.toString()
    }

    // ------------------------------------------------------------------ lockdown (plist over TCP)

    private object Lockdown {
        private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

        fun request(t: Tcp, req: Map<String, String>): String {
            val xml = buildString {
                append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
                append("<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">")
                append("<plist version=\"1.0\"><dict>")
                append("<key>Label</key><string>FakeGeo</string>")
                for ((k, v) in req) append("<key>${esc(k)}</key><string>${esc(v)}</string>")
                append("</dict></plist>")
            }.toByteArray(Charsets.UTF_8)
            val frame = ByteBuffer.allocate(4 + xml.size).order(ByteOrder.BIG_ENDIAN).putInt(xml.size).put(xml).array()
            t.write(frame)
            val len = ByteBuffer.wrap(t.read(4, 5000)).order(ByteOrder.BIG_ENDIAN).int
            if (len < 0 || len > 4_000_000) throw IOException("bad lockdown length $len")
            return String(t.read(len, 5000), Charsets.UTF_8)
        }

        /** Tiny plist reader: the value of a top-level key if it is a string/integer/bool. */
        fun value(xml: String, key: String): String? {
            val k = Regex.escape(key)
            Regex("<key>$k</key>\\s*<(string|integer)>(.*?)</\\1>", RegexOption.DOT_MATCHES_ALL)
                .find(xml)?.let { return it.groupValues[2] }
            Regex("<key>$k</key>\\s*<(true|false)/>").find(xml)?.let { return it.groupValues[1] }
            return null
        }
    }

    // ------------------------------------------------------------------ TCP over usbmux

    private const val TH_FIN = 0x01
    private const val TH_SYN = 0x02
    private const val TH_RST = 0x04
    private const val TH_ACK = 0x10

    class Tcp internal constructor(private val link: MuxLink, private val dport: Int) {
        private val sport = 0x4647
        private var seq = 0L
        private var ack = 0L
        private var rbuf = ByteArray(0)
        private var closed = false

        private fun sendTcp(flags: Int, data: ByteArray) {
            val bb = ByteBuffer.allocate(20 + data.size).order(ByteOrder.BIG_ENDIAN)
            bb.putShort(sport.toShort()); bb.putShort(dport.toShort())
            bb.putInt(seq.toInt()); bb.putInt(ack.toInt())
            bb.put(0x50.toByte())                       // data offset = 5 words
            bb.put(flags.toByte())
            bb.putShort((131072 shr 8).toShort())       // window, scaled by 8 bits (as usbmuxd does)
            bb.putShort(0); bb.putShort(0)              // checksum (unused), urgent
            bb.put(data)
            link.send(6, bb.array())
        }

        internal fun open(): Boolean {
            sendTcp(TH_SYN, ByteArray(0))
            seq = 1
            val end = SystemClock.elapsedRealtime() + 4000
            while (SystemClock.elapsedRealtime() < end) {
                val pkt = link.readPacket(1000) ?: continue
                if (pkt.first != 6 || pkt.second.size < 20) continue
                val b = ByteBuffer.wrap(pkt.second).order(ByteOrder.BIG_ENDIAN)
                val flags = pkt.second[13].toInt() and 0xFF
                if (flags and TH_RST != 0) { link.log("Connection refused (RST) on port $dport"); return false }
                if (flags and TH_SYN != 0 && flags and TH_ACK != 0) {
                    ack = (b.getInt(4).toLong() and 0xFFFFFFFFL) + 1
                    sendTcp(TH_ACK, ByteArray(0))
                    return true
                }
            }
            return false
        }

        fun write(data: ByteArray) {
            var off = 0
            while (off < data.size) {
                val n = minOf(4096, data.size - off)
                sendTcp(TH_ACK, data.copyOfRange(off, off + n))
                seq += n
                off += n
            }
        }

        fun read(n: Int, timeoutMs: Int): ByteArray {
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (rbuf.size < n) {
                if (closed) throw IOException("connection closed by the iPhone")
                val left = end - SystemClock.elapsedRealtime()
                if (left <= 0) throw IOException("timeout waiting for the iPhone")
                val pkt = link.readPacket(left.toInt().coerceAtMost(1000)) ?: continue
                if (pkt.first != 6 || pkt.second.size < 20) continue
                val flags = pkt.second[13].toInt() and 0xFF
                val hl = ((pkt.second[12].toInt() shr 4) and 0xF) * 4
                if (flags and TH_RST != 0) { closed = true; throw IOException("connection reset by the iPhone") }
                val data = if (pkt.second.size > hl) pkt.second.copyOfRange(hl, pkt.second.size) else ByteArray(0)
                if (data.isNotEmpty()) {
                    ack += data.size
                    rbuf += data
                    sendTcp(TH_ACK, ByteArray(0))
                }
                if (flags and TH_FIN != 0) closed = true
            }
            val out = rbuf.copyOfRange(0, n)
            rbuf = rbuf.copyOfRange(n, rbuf.size)
            return out
        }

        fun close() {
            try { sendTcp(TH_RST, ByteArray(0)) } catch (_: Exception) {}
        }
    }

    // ------------------------------------------------------------------ usbmux over USB bulk

    class MuxLink private constructor(
        private val conn: UsbDeviceConnection,
        private val itf: UsbInterface,
        private val epIn: UsbEndpoint,
        private val epOut: UsbEndpoint,
        val log: (String) -> Unit
    ) {
        private var version = 0
        private var txSeq = 0
        private var rxSeq = 0xFFFF
        private var buf = ByteArray(0)
        private val tmp = ByteArray(16384)

        companion object {
            fun open(m: UsbManager, dev: UsbDevice, log: (String) -> Unit): MuxLink? {
                // Find the usbmux interface (class 0xFF, subclass 0xFE, protocol 2) in any configuration.
                var cfgFound: android.hardware.usb.UsbConfiguration? = null
                var itfFound: UsbInterface? = null
                for (ci in 0 until dev.configurationCount) {
                    val cfg = dev.getConfiguration(ci)
                    for (ii in 0 until cfg.interfaceCount) {
                        val i = cfg.getInterface(ii)
                        log("config ${cfg.id} interface ${i.id}: class=${i.interfaceClass} sub=${i.interfaceSubclass} proto=${i.interfaceProtocol}")
                        if (itfFound == null && i.interfaceClass == 255 && i.interfaceSubclass == 254 && i.interfaceProtocol == 2) {
                            cfgFound = cfg; itfFound = i
                        }
                    }
                }
                val itf = itfFound
                val cfg = cfgFound
                if (itf == null || cfg == null) {
                    log("No usbmux interface on this USB device (is it an iPhone? try another cable/adapter).")
                    return null
                }
                val c = m.openDevice(dev)
                if (c == null) { log("Could not open the USB device (permission?)"); return null }
                if (dev.configurationCount > 1) {
                    // The mux interface may live in a non-default configuration.
                    if (!c.setConfiguration(cfg)) log("setConfiguration(${cfg.id}) failed; continuing")
                }
                if (!c.claimInterface(itf, true)) {
                    log("Could not claim the usbmux interface"); c.close(); return null
                }
                var ein: UsbEndpoint? = null
                var eout: UsbEndpoint? = null
                for (e in 0 until itf.endpointCount) {
                    val ep = itf.getEndpoint(e)
                    if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                    if (ep.direction == UsbConstants.USB_DIR_IN) ein = ep else eout = ep
                }
                if (ein == null || eout == null) {
                    log("usbmux interface has no bulk endpoints"); c.close(); return null
                }
                log("usbmux interface claimed (bulk in/out ok)")
                return MuxLink(c, itf, ein, eout, log)
            }
        }

        fun close() {
            try { conn.releaseInterface(itf) } catch (_: Exception) {}
            try { conn.close() } catch (_: Exception) {}
        }

        fun send(proto: Int, payload: ByteArray) {
            val hdr = if (version >= 2) 16 else 8
            val bb = ByteBuffer.allocate(hdr + payload.size).order(ByteOrder.BIG_ENDIAN)
            bb.putInt(proto); bb.putInt(hdr + payload.size)
            if (version >= 2) {
                bb.putInt(0xFEEDFACE.toInt())
                bb.putShort(txSeq.toShort()); bb.putShort(rxSeq.toShort())
                txSeq = (txSeq + 1) and 0xFFFF
            }
            bb.put(payload)
            val a = bb.array()
            var off = 0
            while (off < a.size) {
                val n = minOf(16384, a.size - off)
                val r = conn.bulkTransfer(epOut, a, off, n, 5000)
                if (r < 0) throw IOException("USB write failed")
                off += r
            }
            // A transfer that is an exact multiple of the packet size needs a zero-length packet to end it.
            if (a.size % epOut.maxPacketSize == 0) conn.bulkTransfer(epOut, ByteArray(0), 0, 0, 1000)
        }

        /** Next mux packet as (protocol, payload after the mux header), or null on timeout. */
        fun readPacket(timeoutMs: Int): Pair<Int, ByteArray>? {
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (true) {
                if (buf.size >= 8) {
                    val len = ByteBuffer.wrap(buf, 4, 4).order(ByteOrder.BIG_ENDIAN).int
                    if (len < 8 || len > 1_000_000) throw IOException("bad usbmux length $len")
                    if (buf.size >= len) {
                        val proto = ByteBuffer.wrap(buf, 0, 4).order(ByteOrder.BIG_ENDIAN).int
                        val hdr = if (version >= 2) 16 else 8
                        if (version >= 2 && len >= 16) {
                            // v2 header: proto(4) len(4) magic(4) tx_seq(2) rx_seq(2): remember the device's tx_seq
                            rxSeq = ByteBuffer.wrap(buf).order(ByteOrder.BIG_ENDIAN).getShort(12).toInt() and 0xFFFF
                        }
                        val payload = if (proto == 0) buf.copyOfRange(maxOf(8, len - 12), len)   // version reply
                                      else buf.copyOfRange(minOf(hdr, len), len)
                        buf = buf.copyOfRange(len, buf.size)
                        return Pair(proto, payload)
                    }
                }
                val left = end - SystemClock.elapsedRealtime()
                if (left <= 0) return null
                val n = conn.bulkTransfer(epIn, tmp, tmp.size, left.toInt().coerceAtMost(500))
                if (n > 0) buf += tmp.copyOfRange(0, n)
            }
        }

        fun handshake(): Boolean {
            val vh = ByteBuffer.allocate(12).order(ByteOrder.BIG_ENDIAN).putInt(2).putInt(0).putInt(0).array()
            send(0, vh)
            val pkt = readPacket(3000)
            if (pkt == null) { log("No reply from the iPhone (unlock it, then retry)"); return false }
            if (pkt.first != 0 || pkt.second.size < 4) { log("Unexpected first packet (proto ${pkt.first})"); return false }
            val major = ByteBuffer.wrap(pkt.second).order(ByteOrder.BIG_ENDIAN).int
            log("usbmux protocol version $major")
            version = major
            if (version >= 2) send(2, byteArrayOf(7))
            return true
        }

        fun connect(port: Int): Tcp? {
            val t = Tcp(this, port)
            return if (t.open()) t else null
        }
    }
}
