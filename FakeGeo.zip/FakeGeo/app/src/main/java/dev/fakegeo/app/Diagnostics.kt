package dev.fakegeo.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Process
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

/** Shows what each location provider returns right now, so compatibility problems can be pinpointed. */
object Diagnostics {

    fun show(a: Activity, pinLat: Double?, pinLon: Double?) {
        val tv = TextView(a).apply {
            textSize = 12f
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(40, 30, 40, 30)
            setTextColor(android.graphics.Color.WHITE)
        }
        val sv = ScrollView(a).apply { addView(tv) }
        val dlg = AlertDialog.Builder(a).setTitle("Diagnostics").setView(sv)
            .setPositiveButton("Close", null).create()
        dlg.show()

        val sb = StringBuilder()
        fun out() { tv.text = sb.toString() }
        sb.append("Phone: ${Build.MANUFACTURER} ${Build.MODEL}\n")
        sb.append("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        sb.append("App version: ${try { a.packageManager.getPackageInfo(a.packageName, 0).versionName } catch (e: Exception) { "?" }}\n")
        sb.append("Service running: ${MockState.running}\n")

        // Is FakeGeo the selected mock location app?
        val mockOk = try {
            val ops = a.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            @Suppress("DEPRECATION")
            val r = ops.checkOpNoThrow("android:mock_location", Process.myUid(), a.packageName)
            r == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) { false }
        sb.append("Selected as mock app: $mockOk\n")

        val lm = a.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        sb.append("Location enabled: ${if (Build.VERSION.SDK_INT >= 28) lm.isLocationEnabled else "?"}\n")
        sb.append("Pin: ${pinLat ?: "none"}, ${pinLon ?: "none"}\n\n")

        if (a.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            sb.append("Location permission not granted to FakeGeo.\n")
            out(); return
        }

        val names = mutableListOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        if (Build.VERSION.SDK_INT >= 31) names.add(LocationManager.FUSED_PROVIDER)
        val enabled = lm.getProviders(true)
        fun line(l: Location?): String {
            if (l == null) return "none"
            val mock = if (Build.VERSION.SDK_INT >= 31) l.isMock else @Suppress("DEPRECATION") l.isFromMockProvider
            val age = (System.currentTimeMillis() - l.time) / 1000
            var d = ""
            if (pinLat != null && pinLon != null) {
                val r = FloatArray(1)
                Location.distanceBetween(pinLat, pinLon, l.latitude, l.longitude, r)
                d = String.format(Locale.US, " %.0fm from pin", r[0])
            }
            return String.format(Locale.US, "%.5f,%.5f acc=%.0fm age=%ds mock=%s%s", l.latitude, l.longitude, l.accuracy, age, mock, d)
        }
        for (n in names) {
            sb.append("[$n] enabled=${enabled.contains(n)}\n  last: ")
            sb.append(try { line(lm.getLastKnownLocation(n)) } catch (e: Exception) { "error ${e.message}" })
            sb.append("\n")
        }
        sb.append("\nLive reading (a few seconds)...\n")
        out()

        if (Build.VERSION.SDK_INT >= 30) {
            for (n in names) {
                try {
                    lm.getCurrentLocation(n, null, a.mainExecutor) { l ->
                        sb.append("[$n] now: ${line(l)}\n")
                        out()
                    }
                } catch (e: Exception) {
                    sb.append("[$n] now: error ${e.message}\n"); out()
                }
            }
        }
        sb.append("\nSend this screen's text/screenshot to the developer.\n")
        out()
    }
}
