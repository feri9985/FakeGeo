package dev.fakegeo.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Fav(val name: String, val lat: Double, val lon: Double)

/** Named favorite places. Export / import as JSON text. */
object FavStore {
    private const val KEY = "favs"
    private fun prefs(c: Context) = c.getSharedPreferences("fakegeo", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Fav> = parse(prefs(c).getString(KEY, "[]") ?: "[]").toMutableList()

    fun parse(json: String): List<Fav> {
        val out = mutableListOf<Fav>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Fav(o.getString("name"), o.getDouble("lat"), o.getDouble("lon")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun toJson(list: List<Fav>): String {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("name", it.name).put("lat", it.lat).put("lon", it.lon)) }
        return arr.toString()
    }

    private fun save(c: Context, list: List<Fav>) {
        prefs(c).edit().putString(KEY, toJson(list)).apply()
    }

    fun add(c: Context, f: Fav) {
        val l = load(c)
        l.removeAll { it.name.equals(f.name, true) }
        l.add(0, f)
        save(c, l)
    }

    fun remove(c: Context, index: Int) {
        val l = load(c)
        if (index in l.indices) { l.removeAt(index); save(c, l) }
    }

    /** Merge imported favorites; returns how many were added. */
    fun importJson(c: Context, json: String): Int {
        val items = parse(json)
        items.forEach { add(c, it) }
        return items.size
    }
}
