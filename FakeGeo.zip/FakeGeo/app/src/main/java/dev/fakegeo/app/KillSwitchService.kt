package dev.fakegeo.app

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream

/**
 * یک VPN محلی که هیچ‌جا وصل نمی‌شه و همه‌ی بسته‌های اپ‌های انتخاب‌شده رو دور می‌ریزه (blackhole).
 * اگه هیچ اپی انتخاب نشده باشه، اینترنت همه‌ی اپ‌ها (به‌جز FakeGeo) قطع می‌شه.
 */
class KillSwitchService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var drain: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == KillSwitch.ACTION_UNBLOCK) {
            stopBlocking()
            stopSelf()
        } else {
            startBlocking()
        }
        return START_NOT_STICKY
    }

    private fun startBlocking() {
        if (tun != null) return
        if (VpnService.prepare(this) != null) {
            MockState.log("Kill switch: VPN permission is missing (open the app and enable the kill switch)")
            stopSelf()
            return
        }
        try {
            val prefs = getSharedPreferences("fakegeo", MODE_PRIVATE)
            val saved = prefs.getStringSet("ks_apps", emptySet())?.toSet().orEmpty()

            val builder = Builder()
                .setSession("FakeGeo kill switch")
                .addAddress("10.255.255.1", 32)
                .addRoute("0.0.0.0", 0)
                .addAddress("fd00:255::1", 128)
                .addRoute("::", 0)
                .setBlocking(true)

            if (saved.isEmpty()) {
                builder.addDisallowedApplication(packageName) // همه‌ی اپ‌ها جز خودمون
            } else {
                var valid = 0
                for (pkg in saved) {
                    try {
                        builder.addAllowedApplication(pkg)
                        valid++
                    } catch (_: Exception) {
                    }
                }
                if (valid == 0) {
                    MockState.log("Kill switch: none of the selected apps are installed")
                    stopSelf()
                    return
                }
            }
            tun = builder.establish()
            val fd = tun
            if (fd == null) {
                MockState.log("Kill switch: could not start")
                stopSelf()
                return
            }
            KillSwitch.blocking = true
            MockState.log("🛑 Kill switch: BLOCKING internet for protected apps")
            drain = Thread {
                try {
                    val input = FileInputStream(fd.fileDescriptor)
                    val buf = ByteArray(32767)
                    while (!Thread.currentThread().isInterrupted) {
                        if (input.read(buf) < 0) break // بسته‌ها خونده و دور ریخته می‌شن
                    }
                } catch (_: Exception) {
                }
            }.also { it.start() }
        } catch (e: Exception) {
            MockState.log("Kill switch error: ${e.message}")
            stopBlocking()
            stopSelf()
        }
    }

    private fun stopBlocking() {
        drain?.interrupt()
        drain = null
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        if (KillSwitch.blocking) MockState.log("✅ Kill switch: internet restored")
        KillSwitch.blocking = false
    }

    override fun onRevoke() {
        stopBlocking()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopBlocking()
        super.onDestroy()
    }
}
