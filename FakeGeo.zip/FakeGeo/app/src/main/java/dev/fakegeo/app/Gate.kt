package dev.fakegeo.app

import android.content.Context
import android.os.Build
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Login + "one account = one phone" lock, using Firebase over plain HTTPS (no extra libraries).
 *  1) sign in with e-mail/password (Firebase Authentication)
 *  2) the first phone that signs in is saved in Firestore: devices/<uid>
 *  3) any other phone using the same account is refused
 */
object Gate {
    private const val API_KEY = "AIzaSyDEp-J18dNaRETFaub-Cj-7m-tgM0-Rw9c"
    private const val PROJECT = "fakegeo-6d4f0"
    private const val DOMAIN = "@fakegeo.app"          // lets friends type a short username
    private const val PASS_MS = 6L * 60 * 60 * 1000     // MainActivity re-checks online every 6 hours
    private const val GRACE_MS = 3L * 24 * 60 * 60 * 1000 // works offline for up to 3 days

    sealed class Res {
        object Ok : Res()
        class Denied(val msg: String) : Res()
        class NetError(val msg: String) : Res()
    }

    private class Http(val code: Int, val body: String)

    private fun prefs(c: Context) = c.getSharedPreferences("gate", Context.MODE_PRIVATE)

    /** Used by MainActivity (needs a fresh online check every few hours). */
    fun passValid(c: Context) = prefs(c).getLong("pass_until", 0L) > System.currentTimeMillis()

    /** Used by the background services (also OK while offline, within the grace time). */
    fun isAllowed(c: Context) = prefs(c).getLong("grace_until", 0L) > System.currentTimeMillis()

    fun hasSession(c: Context) = !prefs(c).getString("refresh", null).isNullOrEmpty()

    fun savedUser(c: Context): String = prefs(c).getString("email", "") ?: ""

    fun logout(c: Context) { prefs(c).edit().clear().apply() }

    /** Lets the user work offline for a while when the check could not reach the internet. */
    fun allowOfflineIfGrace(c: Context): Boolean {
        if (!isAllowed(c)) return false
        prefs(c).edit().putLong("pass_until", System.currentTimeMillis() + PASS_MS).apply()
        return true
    }

    private fun deviceId(c: Context): String =
        Settings.Secure.getString(c.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"

    private fun call(url: String, method: String, body: String?, type: String, token: String?): Http {
        val con = URL(url).openConnection() as HttpURLConnection
        try {
            con.requestMethod = method
            con.connectTimeout = 15000
            con.readTimeout = 15000
            if (token != null) con.setRequestProperty("Authorization", "Bearer $token")
            if (body != null) {
                con.doOutput = true
                con.setRequestProperty("Content-Type", type)
                con.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = con.responseCode
            val s = if (code in 200..299) con.inputStream else con.errorStream
            val text = s?.bufferedReader()?.use { it.readText() } ?: ""
            return Http(code, text)
        } finally {
            con.disconnect()
        }
    }

    private fun errMsg(body: String): String = try {
        JSONObject(body).optJSONObject("error")?.optString("message") ?: ""
    } catch (_: Exception) { "" }

    private fun explain(m: String): String = when {
        m.startsWith("INVALID_LOGIN_CREDENTIALS") || m.startsWith("INVALID_PASSWORD") ||
            m.startsWith("EMAIL_NOT_FOUND") || m.startsWith("INVALID_EMAIL") -> "یوزر یا رمز اشتباهه"
        m.startsWith("USER_DISABLED") -> "این حساب غیرفعال شده"
        m.startsWith("TOO_MANY_ATTEMPTS") -> "تلاش زیاد بود؛ چند دقیقه بعد دوباره امتحان کن"
        m.startsWith("TOKEN_EXPIRED") || m.startsWith("USER_NOT_FOUND") ||
            m.startsWith("INVALID_REFRESH_TOKEN") -> "دوباره وارد شو"
        m.isEmpty() -> "خطای نامشخص"
        else -> "خطا: $m"
    }

    /** First login with username + password. */
    fun login(c: Context, user: String, pass: String): Res = try {
        val email = (if (user.contains("@")) user else user + DOMAIN).trim().lowercase()
        val b = JSONObject().put("email", email).put("password", pass)
            .put("returnSecureToken", true).toString()
        val r = call(
            "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=$API_KEY",
            "POST", b, "application/json", null
        )
        if (r.code == 200) {
            val j = JSONObject(r.body)
            checkDevice(c, j.getString("idToken"), j.getString("localId"), j.getString("refreshToken"), email)
        } else if (r.code >= 500) Res.NetError("سرور در دسترس نیست")
        else Res.Denied(explain(errMsg(r.body)))
    } catch (e: Exception) {
        Res.NetError("اینترنت نیست یا مشکل اتصال داری")
    }

    /** Silent re-check of a saved login (every app start / every 6 hours). */
    fun verify(c: Context): Res = try {
        val rt = prefs(c).getString("refresh", "") ?: ""
        val email = savedUser(c)
        if (rt.isEmpty()) Res.Denied("")
        else {
            val r = call(
                "https://securetoken.googleapis.com/v1/token?key=$API_KEY",
                "POST",
                "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(rt, "UTF-8"),
                "application/x-www-form-urlencoded", null
            )
            if (r.code == 200) {
                val j = JSONObject(r.body)
                checkDevice(c, j.getString("id_token"), j.getString("user_id"), j.optString("refresh_token", rt), email)
            } else if (r.code >= 500 || r.code == 429) Res.NetError("سرور در دسترس نیست")
            else {
                val m = explain(errMsg(r.body))
                logout(c)
                Res.Denied(m)
            }
        }
    } catch (e: Exception) {
        Res.NetError("اینترنت نیست یا مشکل اتصال داری")
    }

    private fun str(v: String) = JSONObject().put("stringValue", v)

    private fun checkDevice(c: Context, idToken: String, uid: String, refresh: String, email: String): Res {
        val dev = deviceId(c)
        val base = "https://firestore.googleapis.com/v1/projects/$PROJECT/databases/(default)/documents/devices"
        val g = call("$base/$uid", "GET", null, "", idToken)
        when (g.code) {
            200 -> {
                val saved = JSONObject(g.body).optJSONObject("fields")
                    ?.optJSONObject("deviceId")?.optString("stringValue")
                if (saved != dev) {
                    logout(c)
                    return Res.Denied("این حساب روی گوشی دیگه‌ای فعال شده. به ادمین بگو.")
                }
            }
            404 -> {
                val fields = JSONObject().put("deviceId", str(dev)).put("email", str(email))
                    .put("model", str(Build.MANUFACTURER + " " + Build.MODEL))
                val cr = call("$base?documentId=$uid", "POST",
                    JSONObject().put("fields", fields).toString(), "application/json", idToken)
                if (cr.code !in 200..299) {
                    return if (cr.code >= 500) Res.NetError("سرور در دسترس نیست")
                    else Res.Denied("ثبت گوشی ناموفق بود (کد ${cr.code})")
                }
            }
            403 -> return Res.Denied("دسترسی دیتابیس بسته‌ست (Rules رو چک کن)")
            else -> return Res.NetError("پاسخ نامعتبر از سرور (کد ${g.code})")
        }
        val now = System.currentTimeMillis()
        prefs(c).edit()
            .putString("email", email)
            .putString("refresh", refresh)
            .putString("uid", uid)
            .putLong("pass_until", now + PASS_MS)
            .putLong("grace_until", now + GRACE_MS)
            .apply()
        return Res.Ok
    }
}
