package dev.fakegeo.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout

/** Floating joystick drawn over other apps (needs the "Display over other apps" permission). */
class JoystickService : Service() {

    private var wm: WindowManager? = null
    private var root: LinearLayout? = null

    private val speeds = doubleArrayOf(1.4, 3.0, 5.5, 14.0)
    private val speedNames = arrayOf("Walk", "Run", "Bike", "Car")
    private var speedIdx = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private inner class Pad(c: Context) : View(c) {
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL; color = Color.parseColor("#AA151B2E")
        }
        private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat(); color = Color.parseColor("#3B82F6")
        }
        private val knob = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#3B82F6") }
        private var kx = 0f
        private var ky = 0f

        override fun onDraw(canvas: Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            val r = Math.min(cx, cy) - dp(3)
            canvas.drawCircle(cx, cy, r, ring)
            canvas.drawCircle(cx, cy, r, edge)
            canvas.drawCircle(cx + kx, cy + ky, r * 0.38f, knob)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val cx = width / 2f
            val cy = height / 2f
            val r = Math.min(cx, cy) - dp(3)
            when (e.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    var dx = e.x - cx
                    var dy = e.y - cy
                    val d = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
                    val lim = r * 0.62f
                    if (d > lim) { dx = dx / d * lim; dy = dy / d * lim }
                    kx = dx; ky = dy
                    Motion.joyMaxMps = speeds[speedIdx]
                    Motion.jx = (dx / lim).toDouble()
                    Motion.jy = (-dy / lim).toDouble() // screen y is inverted: up = north
                    if (Motion.mode == Motion.Mode.NONE) Motion.mode = Motion.Mode.JOYSTICK
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    kx = 0f; ky = 0f
                    Motion.jx = 0.0; Motion.jy = 0.0
                }
            }
            invalidate()
            return true
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (root != null) return START_NOT_STICKY
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        Motion.mode = Motion.Mode.JOYSTICK
        Motion.joyMaxMps = speeds[speedIdx]

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#66000000"))
                cornerRadius = dp(18).toFloat()
            }
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val pad = Pad(this)
        box.addView(pad, LinearLayout.LayoutParams(dp(150), dp(150)))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val bSpeed = Button(this).apply {
            text = speedNames[speedIdx]
            isAllCaps = false
            textSize = 12f
            setOnClickListener {
                speedIdx = (speedIdx + 1) % speeds.size
                text = speedNames[speedIdx]
                Motion.joyMaxMps = speeds[speedIdx]
            }
        }
        val bClose = Button(this).apply {
            text = "✕"
            textSize = 12f
            setOnClickListener {
                Motion.stop()
                stopSelf()
            }
        }
        row.addView(bSpeed, LinearLayout.LayoutParams(0, dp(44), 1f))
        row.addView(bClose, LinearLayout.LayoutParams(dp(52), dp(44)))
        box.addView(row)

        // drag handle: dragging the little bar moves the whole joystick
        val handle = View(this).apply {
            background = GradientDrawable().apply { setColor(Color.parseColor("#88FFFFFF")); cornerRadius = dp(3).toFloat() }
        }
        box.addView(handle, 0, LinearLayout.LayoutParams(dp(48), dp(6)).apply { setMargins(0, 0, 0, dp(6)) })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            x = dp(16); y = dp(120)
        }
        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = ox + (e.rawX - sx).toInt()
                        lp.y = oy - (e.rawY - sy).toInt()
                        try { wm?.updateViewLayout(box, lp) } catch (_: Exception) {}
                    }
                }
                return true
            }
        })
        try {
            wm?.addView(box, lp)
            root = box
        } catch (e: Exception) {
            MockState.log("Joystick overlay failed: ${e.message}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { root?.let { wm?.removeView(it) } } catch (_: Exception) {}
        root = null
        if (Motion.mode == Motion.Mode.JOYSTICK) Motion.stop()
        super.onDestroy()
    }
}
