package dev.fakegeo.app

import android.util.Log

/**
 * Runs [block] and swallows any exception, but logs it (visible in logcat / Diagnostics) instead of hiding it.
 * Use it only for best-effort cleanup (close, release, unregister) where failing is harmless.
 */
inline fun ignoring(tag: String = "FakeGeo", block: () -> Unit) {
    try {
        block()
    } catch (e: Exception) {
        Log.d(tag, "ignored: $e")
    }
}
