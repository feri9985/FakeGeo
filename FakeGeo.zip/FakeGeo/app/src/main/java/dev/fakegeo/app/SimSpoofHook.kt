package dev.fakegeo.app

import android.telephony.SubscriptionInfo
import android.telephony.TelephonyManager
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * ماژول Xposed که با LSPatch داخل APK اپ هدف جاسازی می‌شه.
 * اطلاعاتی که اپ از TelephonyManager / SubscriptionInfo می‌خونه رو با مقدار کشور دلخواه عوض می‌کنه.
 * مقادیر موقع بیلد تعیین می‌شن (BuildConfig.SIM_*).
 */
class SimSpoofHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName == BuildConfig.APPLICATION_ID) return

        val iso = BuildConfig.SIM_COUNTRY
        val numeric = BuildConfig.SIM_MCCMNC
        val name = BuildConfig.SIM_OPERATOR_NAME
        val mcc = numeric.take(3)
        val mnc = numeric.drop(3)

        XposedBridge.log("FakeGeo: spoofing SIM in ${lpparam.packageName} -> $iso / $numeric / $name")

        val tm = TelephonyManager::class.java
        hook(tm, listOf("getSimCountryIso", "getNetworkCountryIso",
            "getSimCountryIsoForPhone", "getNetworkCountryIsoForPhone"), iso)
        hook(tm, listOf("getSimOperator", "getNetworkOperator", "getSimOperatorNumeric",
            "getNetworkOperatorForPhone"), numeric)
        hook(tm, listOf("getSimOperatorName", "getNetworkOperatorName"), name)

        val si = SubscriptionInfo::class.java
        hook(si, listOf("getCountryIso"), iso)
        hook(si, listOf("getMccString"), mcc)
        hook(si, listOf("getMncString"), mnc)
        hook(si, listOf("getMcc"), mcc.toIntOrNull() ?: 0)
        hook(si, listOf("getMnc"), mnc.toIntOrNull() ?: 0)
        hook(si, listOf("getCarrierName", "getDisplayName"), name)
    }

    private fun hook(cls: Class<*>, methods: List<String>, value: Any) {
        for (m in methods) {
            try {
                XposedBridge.hookAllMethods(cls, m, object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        param.result = value
                    }
                })
            } catch (t: Throwable) {
                XposedBridge.log("FakeGeo: hook $m failed: $t")
            }
        }
    }
}
