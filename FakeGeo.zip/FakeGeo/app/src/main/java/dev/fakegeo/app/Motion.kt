package dev.fakegeo.app

import android.location.Location

/**
 * Shared movement state (same process: MainActivity, JoystickService and MockLocationService).
 * ROUTE: follow a polyline at a given speed. JOYSTICK: move in a direction chosen on the overlay pad.
 */
object Motion {
    enum class Mode { NONE, ROUTE, JOYSTICK }

    @Volatile var mode = Mode.NONE
    @Volatile var speedMps = 1.4          // route speed
    @Volatile var loop = false
    @Volatile var paused = false

    // joystick input: -1..1 (x = east, y = north)
    @Volatile var jx = 0.0
    @Volatile var jy = 0.0
    @Volatile var joyMaxMps = 6.0

    // current position while moving (null = not moving)
    @Volatile var curLat: Double? = null
    @Volatile var curLon: Double? = null
    @Volatile var heading = 0f
    @Volatile var curSpeed = 0f

    // set by the UI to make the service jump to a point (e.g. route start)
    @Volatile var teleportLat: Double? = null
    @Volatile var teleportLon: Double? = null

    // route
    @Volatile var route: List<DoubleArray> = emptyList() // [lat, lon]
    private var segIdx = 0
    private var segPos = 0.0 // meters travelled in current segment
    @Volatile var progress = 0.0 // 0..1

    private var totalLen = 0.0
    private var cum = DoubleArray(0)

    fun dist(a: DoubleArray, b: DoubleArray): Double {
        val r = FloatArray(1)
        Location.distanceBetween(a[0], a[1], b[0], b[1], r)
        return r[0].toDouble()
    }

    @Synchronized
    fun loadRoute(points: List<DoubleArray>) {
        route = points
        cum = DoubleArray(points.size)
        var t = 0.0
        for (i in 1 until points.size) {
            t += dist(points[i - 1], points[i])
            cum[i] = t
        }
        totalLen = t
        segIdx = 0
        segPos = 0.0
        progress = 0.0
    }

    fun routeLengthM() = totalLen

    @Synchronized
    fun stop() {
        mode = Mode.NONE
        curLat = null
        curLon = null
        curSpeed = 0f
        jx = 0.0
        jy = 0.0
        paused = false
    }

    /** Advance by dt seconds from the given start position; returns new (lat, lon). */
    @Synchronized
    fun step(lat: Double, lon: Double, dt: Double): Pair<Double, Double> {
        when (mode) {
            Mode.JOYSTICK -> {
                val mag = Math.min(1.0, Math.hypot(jx, jy))
                if (mag < 0.05) { curSpeed = 0f; return Pair(lat, lon) }
                val v = joyMaxMps * mag
                val dx = jx / Math.hypot(jx, jy) * v * dt
                val dy = jy / Math.hypot(jx, jy) * v * dt
                heading = ((Math.toDegrees(Math.atan2(jx, jy)) + 360) % 360).toFloat()
                curSpeed = v.toFloat()
                val nLat = lat + dy / 111_320.0
                val nLon = lon + dx / (111_320.0 * Math.cos(Math.toRadians(lat)))
                return Pair(nLat.coerceIn(-85.0, 85.0), nLon)
            }
            Mode.ROUTE -> {
                if (route.size < 2 || paused) { curSpeed = 0f; return Pair(lat, lon) }
                var move = speedMps * dt
                while (move > 0 && segIdx < route.size - 1) {
                    val segLen = cum[segIdx + 1] - cum[segIdx]
                    val left = segLen - segPos
                    if (move >= left) { move -= left; segIdx++; segPos = 0.0 }
                    else { segPos += move; move = 0.0 }
                }
                if (segIdx >= route.size - 1) {
                    if (loop) {
                        route = route.reversed()
                        loadRoute(route)
                    } else {
                        val last = route.last()
                        mode = Mode.NONE
                        curSpeed = 0f
                        progress = 1.0
                        return Pair(last[0], last[1])
                    }
                }
                val a = route[segIdx]
                val b = route[segIdx + 1]
                val segLen = Math.max(0.01, cum[segIdx + 1] - cum[segIdx])
                val f = (segPos / segLen).coerceIn(0.0, 1.0)
                val nLat = a[0] + (b[0] - a[0]) * f
                val nLon = a[1] + (b[1] - a[1]) * f
                val dy = b[0] - a[0]
                val dx = (b[1] - a[1]) * Math.cos(Math.toRadians(a[0]))
                if (Math.abs(dx) + Math.abs(dy) > 1e-9) {
                    heading = ((Math.toDegrees(Math.atan2(dx, dy)) + 360) % 360).toFloat()
                }
                curSpeed = speedMps.toFloat()
                progress = if (totalLen > 0) ((cum[segIdx] + segPos) / totalLen) else 0.0
                return Pair(nLat, nLon)
            }
            else -> return Pair(lat, lon)
        }
    }
}
