package dev.fakegeo.app

import android.content.Context
import android.hardware.usb.UsbDevice
import android.os.SystemClock
import android.util.Base64
import org.bouncycastle.asn1.pkcs.RSAPublicKey
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.asn1.x509.BasicConstraints
import org.bouncycastle.asn1.x509.Extension
import org.bouncycastle.asn1.x509.KeyUsage
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.IOException
import java.math.BigInteger
import java.nio.ByteBuffer
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.RSAPublicKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.Date
import java.util.UUID
import javax.net.ssl.KeyManagerFactory
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLEngine
import javax.net.ssl.SSLEngineResult
import javax.net.ssl.X509TrustManager

/**
 * Stage 2 of "iOS over USB-OTG": pair with the iPhone (the "Trust this computer?" prompt) and open a
 * TLS-protected lockdownd session. Still changes NOTHING on the iPhone except that it adds this phone
 * to its list of trusted computers.
 *
 * What it does:
 *   1. lockdownd (plain): read UniqueDeviceID + DevicePublicKey
 *   2. create a pair record (root / host / device certificates) and send "Pair"; wait for Trust + passcode
 *   3. new lockdownd connection -> StartSession -> TLS handshake using the host certificate
 *   4. inside the session: read iOS version, Developer Mode, and ask which services can be started
 *      (this tells us what stage 3 needs: Developer Disk Image mounted or not)
 *
 * NOTE: written from the libimobiledevice / pymobiledevice3 protocol; not yet verified on a real iPhone.
 */
object IosPairing {

    private const val PREFS = "fakegeo_ios"

    // Device-certificate pinning on the USB lockdown link. false = only log a mismatch (safe default,
    // because this was not tested on every iOS version). Set to true once the logs show no mismatch.
    private const val STRICT_DEVICE_PIN = false
    private const val LABEL = "FakeGeo"

    // ------------------------------------------------------------------ pair record storage

    class Record(
        val hostId: String,
        val systemBuid: String,
        val rootCert: ByteArray,
        val hostCert: ByteArray,
        val deviceCert: ByteArray,
        val hostKey: ByteArray,
        val escrowBag: ByteArray?
    ) {
        fun toJson(): String = JSONObject().apply {
            put("hostId", hostId); put("buid", systemBuid)
            put("root", b64(rootCert)); put("host", b64(hostCert)); put("device", b64(deviceCert))
            put("hostKey", b64(hostKey)); if (escrowBag != null) put("escrow", b64(escrowBag))
        }.toString()

        companion object {
            fun fromJson(s: String): Record? = try {
                val o = JSONObject(s)
                Record(
                    o.getString("hostId"), o.getString("buid"),
                    unb64(o.getString("root")), unb64(o.getString("host")), unb64(o.getString("device")),
                    unb64(o.getString("hostKey")), if (o.has("escrow")) unb64(o.getString("escrow")) else null
                )
            } catch (_: Exception) { null }
        }
    }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    // The pairing record holds the host private key + escrow bag, i.e. it can control the iPhone.
    // It is stored encrypted with an AES-GCM key that lives inside the Android Keystore (not exportable).
    private const val KEY_ALIAS = "fakegeo_pairing_aes"
    private const val SEALED = "v1:"

    private fun aesKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return kg.generateKey()
    }

    private fun seal(plain: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, aesKey())
        val ct = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return SEALED + b64(cipher.iv) + ":" + b64(ct)
    }

    /** Returns the plain JSON, or null if it cannot be decrypted (e.g. key lost -> user must pair again). */
    private fun unseal(s: String): String? {
        if (!s.startsWith(SEALED)) return s // old plain-text record; load() re-saves it encrypted
        return try {
            val parts = s.removePrefix(SEALED).split(":")
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, aesKey(), GCMParameterSpec(128, unb64(parts[0])))
            String(cipher.doFinal(unb64(parts[1])), Charsets.UTF_8)
        } catch (e: Exception) {
            android.util.Log.w("FakeGeo", "pairing record could not be decrypted: $e")
            null
        }
    }

    private fun load(c: Context, udid: String): Record? {
        val raw = prefs(c).getString("rec_$udid", null) ?: return null
        val rec = unseal(raw)?.let { Record.fromJson(it) } ?: return null
        if (!raw.startsWith(SEALED)) save(c, udid, rec) // migrate old plain-text record
        return rec
    }

    private fun save(c: Context, udid: String, r: Record) {
        try {
            prefs(c).edit().putString("rec_$udid", seal(r.toJson())).apply()
        } catch (e: Exception) {
            // Never fall back to plain text.
            android.util.Log.e("FakeGeo", "could not store pairing record securely: $e")
        }
    }
    fun forget(c: Context) { prefs(c).edit().clear().apply() }

    // ------------------------------------------------------------------ certificates

    private fun pem(type: String, der: ByteArray): ByteArray {
        val body = Base64.encodeToString(der, Base64.NO_WRAP).chunked(64).joinToString("\n")
        return "-----BEGIN $type-----\n$body\n-----END $type-----\n".toByteArray(Charsets.US_ASCII)
    }

    private fun unpem(data: ByteArray): Pair<String, ByteArray> {
        val t = String(data, Charsets.US_ASCII)
        val type = Regex("-----BEGIN ([A-Z ]+)-----").find(t)?.groupValues?.get(1)
            ?: throw IOException("not a PEM block")
        val body = t.replace(Regex("-----[A-Z ]+-----"), "").replace(Regex("\\s"), "")
        return type to Base64.decode(body, Base64.DEFAULT)
    }

    private fun devicePublicKey(pemBytes: ByteArray): PublicKey {
        val (type, der) = unpem(pemBytes)
        val kf = KeyFactory.getInstance("RSA")
        return if (type == "RSA PUBLIC KEY") {
            val k = RSAPublicKey.getInstance(der)
            kf.generatePublic(RSAPublicKeySpec(k.modulus, k.publicExponent))
        } else {
            kf.generatePublic(X509EncodedKeySpec(der))
        }
    }

    private fun makeCert(
        issuerCn: String, subjectCn: String, issuerKey: PrivateKey, subjectPub: PublicKey, ca: Boolean
    ): X509Certificate {
        val now = System.currentTimeMillis()
        val serial = BigInteger(64, SecureRandom()).abs().add(BigInteger.ONE)
        val b = JcaX509v3CertificateBuilder(
            X500Name("CN=$issuerCn"), serial,
            Date(now - 24L * 3600_000), Date(now + 3650L * 24 * 3600_000),
            X500Name("CN=$subjectCn"), subjectPub
        )
        b.addExtension(Extension.basicConstraints, true, BasicConstraints(ca))
        b.addExtension(
            Extension.keyUsage, true,
            KeyUsage(if (ca) (KeyUsage.keyCertSign or KeyUsage.cRLSign) else (KeyUsage.digitalSignature or KeyUsage.keyEncipherment))
        )
        val holder = b.build(JcaContentSignerBuilder("SHA256withRSA").build(issuerKey))
        return JcaX509CertificateConverter().getCertificate(holder)
    }

    private fun newPair(devicePub: PublicKey, log: (String) -> Unit): Record {
        log("Generating keys and certificates (a few seconds)…")
        val kpg = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }
        val root: KeyPair = kpg.generateKeyPair()
        val host: KeyPair = kpg.generateKeyPair()
        val rootCert = makeCert("FakeGeo Root", "FakeGeo Root", root.private, root.public, true)
        val hostCert = makeCert("FakeGeo Root", "FakeGeo Host", root.private, host.public, false)
        val devCert = makeCert("FakeGeo Root", "FakeGeo Device", root.private, devicePub, false)
        return Record(
            hostId = UUID.randomUUID().toString().uppercase(),
            systemBuid = UUID.randomUUID().toString().uppercase(),
            rootCert = pem("CERTIFICATE", rootCert.encoded),
            hostCert = pem("CERTIFICATE", hostCert.encoded),
            deviceCert = pem("CERTIFICATE", devCert.encoded),
            hostKey = pem("PRIVATE KEY", host.private.encoded),
            escrowBag = null
        )
    }

    // ------------------------------------------------------------------ lockdownd over any Stream

    private class Ld(val s: UsbMux.Stream) {
        fun call(req: Map<String, Any?>): Map<String, Any?> {
            val all = LinkedHashMap<String, Any?>()
            all["Label"] = LABEL
            all.putAll(req)
            val body = Plist.encode(all)
            s.write(ByteBuffer.allocate(4 + body.size).putInt(body.size).put(body).array())
            val len = ByteBuffer.wrap(s.read(4, 8000)).int
            if (len <= 0 || len > 4_000_000) throw IOException("bad lockdown length $len")
            return Plist.decode(s.read(len, 8000))
        }
        fun get(key: String, domain: String? = null): Any? {
            val r = LinkedHashMap<String, Any?>()
            r["Request"] = "GetValue"
            r["Key"] = key
            if (domain != null) r["Domain"] = domain
            val res = call(r)
            return res["Value"] ?: res["Error"]?.let { "(error: $it)" }
        }
    }

    // ------------------------------------------------------------------ TLS over a Stream

    private class TlsStream(private val raw: UsbMux.Stream, private val engine: SSLEngine) : UsbMux.Stream {
        private var inNet: ByteBuffer = ByteBuffer.allocate(0)   // encrypted bytes not yet unwrapped (read mode)
        private var inApp = ByteArray(0)                          // decrypted bytes not yet consumed

        private fun fillNet(timeoutMs: Int) {
            val more = raw.readSome(timeoutMs.coerceAtLeast(1))
            val nb = ByteBuffer.allocate(inNet.remaining() + more.size)
            nb.put(inNet); nb.put(more); nb.flip()
            inNet = nb
        }

        private fun sendNet(buf: ByteBuffer) {
            val b = ByteArray(buf.remaining())
            buf.get(b)
            if (b.isNotEmpty()) raw.write(b)
        }

        private fun runTasks() {
            var t = engine.delegatedTask
            while (t != null) { t.run(); t = engine.delegatedTask }
        }

        fun handshake(timeoutMs: Int = 20000) {
            val end = SystemClock.elapsedRealtime() + timeoutMs
            fun left() = (end - SystemClock.elapsedRealtime()).toInt().also {
                if (it <= 0) throw IOException("TLS handshake timeout")
            }
            engine.beginHandshake()
            val app = ByteBuffer.allocate(engine.session.applicationBufferSize)
            val out = ByteBuffer.allocate(engine.session.packetBufferSize)
            var hs = engine.handshakeStatus
            while (hs != SSLEngineResult.HandshakeStatus.FINISHED && hs != SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING) {
                left()
                when (hs) {
                    SSLEngineResult.HandshakeStatus.NEED_WRAP -> {
                        out.clear()
                        val r = engine.wrap(ByteBuffer.allocate(0), out)
                        out.flip(); sendNet(out)
                        if (r.status == SSLEngineResult.Status.CLOSED) throw IOException("TLS closed during handshake")
                        hs = r.handshakeStatus
                    }
                    SSLEngineResult.HandshakeStatus.NEED_UNWRAP -> {
                        if (inNet.remaining() == 0) fillNet(left())
                        app.clear()
                        val r = engine.unwrap(inNet, app)
                        when (r.status) {
                            SSLEngineResult.Status.BUFFER_UNDERFLOW -> fillNet(left())
                            SSLEngineResult.Status.CLOSED -> throw IOException("TLS closed during handshake")
                            else -> {}
                        }
                        hs = r.handshakeStatus
                    }
                    SSLEngineResult.HandshakeStatus.NEED_TASK -> { runTasks(); hs = engine.handshakeStatus }
                    else -> hs = engine.handshakeStatus
                }
            }
        }

        override fun write(data: ByteArray) {
            val src = ByteBuffer.wrap(data)
            val out = ByteBuffer.allocate(engine.session.packetBufferSize)
            while (src.hasRemaining()) {
                out.clear()
                val r = engine.wrap(src, out)
                if (r.status == SSLEngineResult.Status.CLOSED) throw IOException("TLS closed")
                out.flip(); sendNet(out)
            }
        }

        /** Decrypts at least one more chunk into [inApp]. */
        private fun pumpApp(timeoutMs: Int) {
            if (inNet.remaining() == 0) fillNet(timeoutMs)
            val app = ByteBuffer.allocate(engine.session.applicationBufferSize)
            val r = engine.unwrap(inNet, app)
            app.flip()
            if (app.hasRemaining()) {
                val b = ByteArray(app.remaining()); app.get(b); inApp += b
            }
            when (r.status) {
                SSLEngineResult.Status.BUFFER_UNDERFLOW -> fillNet(timeoutMs)
                SSLEngineResult.Status.CLOSED -> throw IOException("TLS closed by the iPhone")
                else -> {}
            }
            if (r.handshakeStatus == SSLEngineResult.HandshakeStatus.NEED_TASK) runTasks()
            if (r.handshakeStatus == SSLEngineResult.HandshakeStatus.NEED_WRAP) {
                val out = ByteBuffer.allocate(engine.session.packetBufferSize)
                engine.wrap(ByteBuffer.allocate(0), out); out.flip(); sendNet(out)
            }
        }

        override fun read(n: Int, timeoutMs: Int): ByteArray {
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (inApp.size < n) {
                val left = (end - SystemClock.elapsedRealtime()).toInt()
                if (left <= 0) throw IOException("timeout waiting for the iPhone (TLS)")
                pumpApp(left)
            }
            val out = inApp.copyOfRange(0, n)
            inApp = inApp.copyOfRange(n, inApp.size)
            return out
        }

        override fun readSome(timeoutMs: Int): ByteArray {
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (inApp.isEmpty()) {
                val left = (end - SystemClock.elapsedRealtime()).toInt()
                if (left <= 0) throw IOException("timeout waiting for the iPhone (TLS)")
                pumpApp(left)
            }
            val o = inApp; inApp = ByteArray(0); return o
        }

        override fun close() { raw.close() }
    }

    private fun tlsEngine(rec: Record): SSLEngine {
        val (_, keyDer) = unpem(rec.hostKey)
        val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyDer))
        val cf = CertificateFactory.getInstance("X.509")
        val hostCert = cf.generateCertificate(ByteArrayInputStream(rec.hostCert)) as X509Certificate
        val rootCert = cf.generateCertificate(ByteArrayInputStream(rec.rootCert)) as X509Certificate

        val ks = KeyStore.getInstance(KeyStore.getDefaultType())
        ks.load(null, null)
        ks.setKeyEntry("host", key, CharArray(0), arrayOf(hostCert, rootCert))
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, CharArray(0))

        // This TLS context is used ONLY for the USB lockdown link to the paired iPhone (never for web traffic).
        // The iPhone presents the "device certificate" created at pairing time, so we pin its public key
        // instead of trusting any certificate.
        val pinned: ByteArray? = try {
            (cf.generateCertificate(ByteArrayInputStream(rec.deviceCert)) as X509Certificate).publicKey.encoded
        } catch (_: Exception) { null }
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
                val leaf = chain?.firstOrNull() ?: throw java.security.cert.CertificateException("empty chain")
                val ok = pinned != null && leaf.publicKey.encoded.contentEquals(pinned)
                if (!ok) {
                    android.util.Log.w("FakeGeo", "iPhone TLS certificate does not match the pairing record")
                    if (STRICT_DEVICE_PIN) throw java.security.cert.CertificateException("device certificate mismatch")
                }
            }
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(kmf.keyManagers, arrayOf(trustAll), null)
        val e = ctx.createSSLEngine()
        e.useClientMode = true
        e.enabledProtocols = e.supportedProtocols.filter { it != "SSLv3" && it != "SSLv2Hello" }.toTypedArray()
        e.enabledCipherSuites = e.supportedCipherSuites.filter {
            !it.contains("NULL") && !it.contains("anon") && !it.contains("EXPORT") && !it.contains("RC4")
        }.toTypedArray()
        return e
    }

    /** Talks to com.apple.amfi.lockdown (Developer Mode switch). Returns the reply, or null on failure. */
    private fun amfi(link: UsbMux.MuxLink, ld: Ld, rec: Record, action: Int, log: (String) -> Unit): Map<String, Any?>? =
        callService(link, ld, rec, "com.apple.amfi.lockdown", mapOf("action" to action), log)

    /** Starts [service], sends one length-prefixed plist request, returns the plist reply (or null). */
    private fun callService(
        link: UsbMux.MuxLink, ld: Ld, rec: Record, service: String, request: Map<String, Any?>, log: (String) -> Unit
    ): Map<String, Any?>? {
        val action = request.entries.firstOrNull()?.value
        val r = ld.call(mapOf("Request" to "StartService", "Service" to service))
        val err = r["Error"] as? String
        if (err != null) { log("$service not available: $err"); return null }
        val port = (r["Port"] as? Long)?.toInt() ?: run { log("$service: no port"); return null }
        val tcp = link.connect(port) ?: run { log("$service: could not connect to port $port"); return null }
        try {
            val st: UsbMux.Stream = if (r["EnableServiceSSL"] == true) {
                TlsStream(tcp, tlsEngine(rec)).also { it.handshake() }
            } else tcp
            val body = Plist.encode(request)
            st.write(ByteBuffer.allocate(4 + body.size).putInt(body.size).put(body).array())
            val len = ByteBuffer.wrap(st.read(4, 8000)).int
            if (len <= 0 || len > 1_000_000) { log("$service: bad reply length $len"); return null }
            return Plist.decode(st.read(len, 8000))
        } catch (e: Exception) {
            log("$service ($action) error: ${e.message}")
            return null
        } finally {
            ignoring { tcp.close() }
        }
    }

    // ------------------------------------------------------------------ Developer Disk Image (iOS 17+)

    /** Plain length-prefixed plist channel (what the image mounter speaks; no Label field). */
    private class Chan(val s: UsbMux.Stream) {
        fun send(req: Map<String, Any?>) {
            val body = Plist.encode(req)
            s.write(ByteBuffer.allocate(4 + body.size).putInt(body.size).put(body).array())
        }
        fun recv(timeoutMs: Int = 15000): Map<String, Any?> {
            val len = ByteBuffer.wrap(s.read(4, timeoutMs)).int
            if (len <= 0 || len > 8_000_000) throw IOException("bad reply length $len")
            return Plist.decode(s.read(len, timeoutMs))
        }
        fun call(req: Map<String, Any?>, timeoutMs: Int = 15000): Map<String, Any?> { send(req); return recv(timeoutMs) }
    }

    private fun openService(link: UsbMux.MuxLink, ld: Ld, rec: Record, service: String, log: (String) -> Unit): UsbMux.Stream? {
        val r = ld.call(mapOf("Request" to "StartService", "Service" to service))
        (r["Error"] as? String)?.let { log("$service not available: $it"); return null }
        val port = (r["Port"] as? Long)?.toInt() ?: run { log("$service: no port"); return null }
        val tcp = link.connect(port) ?: run { log("$service: could not connect"); return null }
        return if (r["EnableServiceSSL"] == true) TlsStream(tcp, tlsEngine(rec)).also { it.handshake() } else tcp
    }

    private fun displayName(ctx: Context, uri: android.net.Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: ""
            }
        } catch (e: Exception) {
            android.util.Log.d("FakeGeo", "could not read file name: $e")
        }
        return uri.lastPathSegment ?: ""
    }

    @Suppress("UNCHECKED_CAST")
    private fun mountDdi(ctx: Context, link: UsbMux.MuxLink, ld: Ld, rec: Record, uris: List<android.net.Uri>, log: (String) -> Unit) {
        var image: ByteArray? = null
        var trust: ByteArray? = null
        var manifestBytes: ByteArray? = null
        for (u in uris) {
            val n = displayName(ctx, u).lowercase()
            val bytes by lazy { ctx.contentResolver.openInputStream(u)!!.use { it.readBytes() } }
            when {
                n.contains("trustcache") -> trust = bytes
                n.contains("buildmanifest") -> manifestBytes = bytes
                n.endsWith(".dmg") -> image = bytes
                else -> log("Ignoring unknown file: $n")
            }
        }
        if (image == null || trust == null || manifestBytes == null) {
            log("Pick all 3 files: Image.dmg, BuildManifest.plist and the trustcache file.")
            log("Found: image=${image != null}, buildManifest=${manifestBytes != null}, trustcache=${trust != null}")
            return
        }
        log("Files OK: image ${image.size / 1024} KB, trustcache ${trust.size} B, manifest ${manifestBytes.size} B")

        var st = openService(link, ld, rec, "com.apple.mobile.mobile_image_mounter", log) ?: return
        var ch = Chan(st)
        var step = "LookupImage"
        try {
            log("Asking the iPhone which image is mounted…")
            val look = ch.call(mapOf("Command" to "LookupImage", "ImageType" to "Personalized"))
            log("LookupImage reply: $look")
            val sig = look["ImageSignature"]
            if (sig is List<*> && sig.isNotEmpty()) { log("A Developer Disk Image is already mounted. Nothing to do."); return }

            step = "QueryPersonalizationManifest"
            val digest = java.security.MessageDigest.getInstance("SHA-384").digest(image)
            var im4m: ByteArray? = null
            try {
                val r = ch.call(mapOf(
                    "Command" to "QueryPersonalizationManifest",
                    "PersonalizedImageType" to "DeveloperDiskImage",
                    "ImageType" to "DeveloperDiskImage",
                    "ImageSignature" to digest
                ))
                im4m = r["ImageSignature"] as? ByteArray
            } catch (e: Exception) {
                log("No ticket stored on the iPhone (${e.message}); this is normal the first time.")
            }

            if (im4m == null) {
                // the device closes the connection after a failed query: reconnect
                ignoring { st.close() }
                st = openService(link, ld, rec, "com.apple.mobile.mobile_image_mounter", log) ?: return
                ch = Chan(st)
                step = "QueryPersonalizationIdentifiers"
                val ids = ch.call(mapOf("Command" to "QueryPersonalizationIdentifiers"))["PersonalizationIdentifiers"] as? Map<String, Any?>
                    ?: run { log("The iPhone gave no personalization identifiers."); return }
                val nonce = ch.call(mapOf("Command" to "QueryNonce", "PersonalizedImageType" to "DeveloperDiskImage"))["PersonalizationNonce"] as? ByteArray
                    ?: run { log("The iPhone gave no nonce."); return }
                val ecid = ld.get("UniqueChipID") as? Long ?: run { log("Cannot read the iPhone ECID."); return }
                step = "TSS (Apple signing)"
                im4m = Tss.personalize(Plist.decode(manifestBytes), ids, ecid, nonce, log)
                log("Got the signed ticket from Apple (${im4m.size} bytes).")
            }

            step = "ReceiveBytes/upload"
            log("Uploading the image to the iPhone…")
            val ack = ch.call(mapOf(
                "Command" to "ReceiveBytes", "ImageType" to "Personalized",
                "ImageSize" to image.size.toLong(), "ImageSignature" to im4m
            ))
            if (ack["Status"] != "ReceiveBytesAck") { log("The iPhone refused the upload: $ack"); return }
            st.write(image)
            val up = ch.recv(120_000)
            if (up["Status"] != "Complete") { log("Upload failed: $up"); return }

            step = "MountImage"
            log("Mounting…")
            val m = ch.call(mapOf(
                "Command" to "MountImage", "ImageType" to "Personalized",
                "ImageSignature" to im4m, "ImageTrustCache" to trust
            ), 120_000)
            if (m["Status"] == "Complete") log("✅ Developer Disk Image MOUNTED.")
            else log("Mount failed: ${m["DetailedError"] ?: m}")
        } catch (e: Exception) {
            log("DDI error at step [$step]: ${e.javaClass.simpleName}: ${e.message}")
        } finally {
            ignoring { st.close() }
        }
    }

    // ------------------------------------------------------------------ CoreDevice tunnel (iOS 17+)

    private fun tunnelProbe(
        link: UsbMux.MuxLink, ld: Ld, rec: Record, log: (String) -> Unit,
        simLat: Double? = null, simLon: Double? = null, live: Boolean = false
    ) {
        // The exact framing of the handshake (a NUL byte after the magic or not) is not 100% certain: try both.
        for (nul in listOf(false, true)) {
            val st = openService(link, ld, rec, "com.apple.internal.devicecompute.CoreDeviceProxy", log) ?: return
            try {
                log("Tunnel handshake (${if (nul) "with" else "without"} a NUL byte after the magic)…")
                val hs = CoreTunnel.handshake(st, nul, log)
                log("Tunnel handshake OK")
                try {
                    CoreTunnel.probe(st, hs, log, simLat, simLon, 75, live)
                } catch (e: Exception) {
                    log("Tunnel probe error: ${e.javaClass.simpleName}: ${e.message}")
                }
                return
            } catch (e: Exception) {
                log("Tunnel handshake error: ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                ignoring { st.close() }
            }
        }
    }

    // ------------------------------------------------------------------ main entry (background thread)

    fun pairAndTest(
        ctx: Context, dev: UsbDevice, enableDevMode: Boolean = false,
        ddiUris: List<android.net.Uri>? = null, tunnelTest: Boolean = false,
        simLat: Double? = null, simLon: Double? = null, live: Boolean = false
    ): String {
        val sb = StringBuilder()
        fun p(s: String) { sb.appendLine(s); MockState.log("iOS: $s") }

        var link: UsbMux.MuxLink? = null
        var s1: UsbMux.Stream? = null
        var s2: UsbMux.Stream? = null
        try {
            link = UsbMux.MuxLink.open(UsbMux.manager(ctx), dev, ::p) ?: return sb.toString()
            if (!link.handshake()) return sb.toString()

            // ---- 1) plain lockdownd: identity
            val c1 = link.connect(62078) ?: run { p("Could not open lockdownd. Is the iPhone unlocked?"); return sb.toString() }
            s1 = c1
            val ld1 = Ld(c1)
            val udid = ld1.get("UniqueDeviceID") as? String
            if (udid == null || udid.startsWith("(error")) { p("Cannot read UniqueDeviceID: $udid"); return sb.toString() }
            p("iPhone UDID: ${udid.take(8)}…")

            var recVar: Record? = load(ctx, udid)
            if (recVar != null) {
                p("Using the saved pairing.")
            } else {
                // ---- 2) pair
                val pubPem = ld1.get("DevicePublicKey") as? ByteArray
                if (pubPem == null) { p("Cannot read the iPhone public key."); return sb.toString() }
                val rec = newPair(devicePublicKey(pubPem), ::p)
                val pairReq = mapOf(
                    "Request" to "Pair",
                    "ProtocolVersion" to "2",
                    "PairRecord" to mapOf(
                        "DeviceCertificate" to rec.deviceCert,
                        "HostCertificate" to rec.hostCert,
                        "RootCertificate" to rec.rootCert,
                        "HostID" to rec.hostId,
                        "SystemBUID" to rec.systemBuid
                    ),
                    "PairingOptions" to mapOf("ExtendedPairingErrors" to true)
                )
                p("Sending the pair request. On the iPhone tap TRUST and enter the passcode.")
                val deadline = SystemClock.elapsedRealtime() + 90_000
                var escrow: ByteArray? = null
                while (true) {
                    val r = ld1.call(pairReq)
                    val err = r["Error"] as? String
                    if (err == null) { escrow = r["EscrowBag"] as? ByteArray; break }
                    when (err) {
                        "PairingDialogResponsePending", "PasswordProtected" -> {
                            if (SystemClock.elapsedRealtime() > deadline) { p("Timed out waiting for Trust."); return sb.toString() }
                            p(if (err == "PasswordProtected") "iPhone is locked: unlock it…" else "Waiting for Trust…")
                            Thread.sleep(2000)
                        }
                        "UserDeniedPairing" -> { p("You tapped Don't Trust. Run again and tap Trust."); return sb.toString() }
                        else -> { p("Pairing failed: $err"); return sb.toString() }
                    }
                }
                val done = Record(rec.hostId, rec.systemBuid, rec.rootCert, rec.hostCert, rec.deviceCert, rec.hostKey, escrow)
                save(ctx, udid, done)
                recVar = done
                p("Paired. Pairing saved on this phone.")
            }
            val rec: Record = checkNotNull(recVar)
            ignoring { s1?.close() }
            s1 = null

            // ---- 3) session with TLS
            val c2 = link.connect(62078) ?: run { p("Could not reopen lockdownd."); return sb.toString() }
            s2 = c2
            val plain = Ld(c2)
            val ss = plain.call(mapOf("Request" to "StartSession", "HostID" to rec.hostId, "SystemBUID" to rec.systemBuid))
            val ssErr = ss["Error"] as? String
            if (ssErr != null) {
                if (ssErr == "InvalidHostID") { forget(ctx); p("The iPhone no longer trusts this phone. Saved pairing deleted: run again.") }
                else p("StartSession failed: $ssErr")
                return sb.toString()
            }
            val sessionId = ss["SessionID"] as? String
            val useSsl = ss["EnableSessionSSL"] == true
            p("Session started (TLS: $useSsl)")
            val secure: UsbMux.Stream = if (useSsl) {
                val t = TlsStream(c2, tlsEngine(rec))
                t.handshake()
                p("TLS handshake OK")
                t
            } else c2
            val ld = Ld(secure)


            if (enableDevMode) {
                p("")
                p("DeveloperModeStatus (before) = ${ld.get("DeveloperModeStatus", "com.apple.security.mac.amfi")}")
                // action 0: make the "Developer Mode" switch appear in Settings; action 1: turn it on (needs no passcode)
                for (action in listOf(0, 1)) {
                    val r = amfi(link, ld, rec, action, ::p)
                    p("AMFI action $action -> ${r ?: "(no answer)"}")
                }
                p("")
                p("Now on the iPhone: Settings > Privacy & Security > Developer Mode (at the bottom). " +
                    "Turn it ON, let the iPhone restart, unlock it, tap Turn On when asked. Then run step 2 again.")
                if (sessionId != null) ignoring { ld.call(mapOf("Request" to "StopSession", "SessionID" to sessionId)) }
                return sb.toString()
            }

            if (tunnelTest || simLat != null || live) {
                p("")
                tunnelProbe(link, ld, rec, ::p, simLat, simLon, live)
                if (sessionId != null) ignoring { ld.call(mapOf("Request" to "StopSession", "SessionID" to sessionId)) }
                return sb.toString()
            }

            if (ddiUris != null) {
                p("")
                mountDdi(ctx, link, ld, rec, ddiUris, ::p)
                if (sessionId != null) ignoring { ld.call(mapOf("Request" to "StopSession", "SessionID" to sessionId)) }
                return sb.toString()
            }

            // ---- 4) what can we do on this iPhone?
            p("")
            p("ProductVersion = ${ld.get("ProductVersion")}")
            p("ProductType = ${ld.get("ProductType")}")
            p("DeveloperModeStatus = ${ld.get("DeveloperModeStatus", "com.apple.security.mac.amfi")}")
            // NOTE: the image mounter's real name is "com.apple.mobile.mobile_image_mounter" (the shorter
            // name used in version 2.8 does not exist, so its "InvalidService" meant nothing).
            for (svc in listOf(
                "com.apple.mobile.mobile_image_mounter",
                "com.apple.internal.devicecompute.CoreDeviceProxy",
                "com.apple.dt.simulatelocation",
                "com.apple.instruments.remoteserver",
                "com.apple.mobile.heartbeat"
            )) {
                val r = ld.call(mapOf("Request" to "StartService", "Service" to svc))
                val err = r["Error"] as? String
                p("service $svc -> " + if (err != null) "NOT available ($err)" else "OK (port ${r["Port"]}, ssl=${r["EnableServiceSSL"]})")
            }
            // Is a Developer Disk Image already mounted?
            for (type in listOf("Personalized", "Developer")) {
                val r = callService(
                    link, ld, rec, "com.apple.mobile.mobile_image_mounter",
                    mapOf("Command" to "LookupImage", "ImageType" to type), ::p
                )
                if (r != null) {
                    val sig = r["ImageSignature"]
                    val mounted = sig is List<*> && sig.isNotEmpty()
                    p("DDI \"$type\": " + if (mounted) "MOUNTED" else "not mounted (${r["Error"] ?: r["Status"] ?: "no signature"})")
                }
            }
            if (sessionId != null) ignoring { ld.call(mapOf("Request" to "StopSession", "SessionID" to sessionId)) }
            p("")
            p("Stage 2 finished. Send me this report; stage 3 depends on the iOS version and service results above.")
        } catch (e: Exception) {
            p("ERROR: ${e.javaClass.simpleName}: ${e.message}")
        } finally {
            ignoring { s1?.close() }
            ignoring { s2?.close() }
            link?.close()
        }
        return sb.toString()
    }
}
