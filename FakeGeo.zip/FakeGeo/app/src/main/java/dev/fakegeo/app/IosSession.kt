package dev.fakegeo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbDevice
import android.os.SystemClock

/** The position the iPhone should show. Fed by the pin button and, while it runs, by MockLocationService (route / joystick). */
object IosFeed {
    @Volatile var lat = Double.NaN
    @Volatile var lon = Double.NaN
    @Volatile var seq = 0L
    @Volatile var active = false

    fun set(la: Double, lo: Double) {
        lat = la
        lon = lo
        seq++
    }
}

/** What the screen and the notification show about the iPhone connection. */
object IosState {
    @Volatile var running = false
    @Volatile var status = ""
    @Volatile var updates = 0
    @Volatile var reconnects = 0
    @Volatile var lastError = ""
    @Volatile var lastReport = ""
}

/**
 * Keeps the whole chain (USB -> pairing -> CoreDevice tunnel -> RSD -> DTX LocationSimulation) alive in a
 * background thread, sends every new position to the iPhone and reconnects when the connection drops.
 * The iPhone goes back to its real location as soon as the connection closes.
 */
object IosSession {
    @Volatile private var stopFlag = false
    @Volatile private var thread: Thread? = null

    fun stopRequested() = stopFlag

    private var lastAlertAt = 0L

    /** Loud alert: when the connection drops the iPhone is back on its REAL location. */
    private fun alert(ctx: Context, msg: String) {
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastAlertAt < 20_000) return
            lastAlertAt = now
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel("fakegeo_alert", "Alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 400, 200, 400)
                }
            )
            val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            nm.notify(4, Notification.Builder(ctx, "fakegeo_alert")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("FakeGeo ⚠️ iPhone")
                .setContentText(msg)
                .setStyle(Notification.BigTextStyle().bigText(msg))
                .setCategory(Notification.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build())
            MockState.log("iPhone: $msg")
        } catch (_: Exception) {}
    }

    fun stop() {
        stopFlag = true
        if (IosState.running) IosState.status = "Stopping…"
    }

    fun start(ctx: Context, dev: UsbDevice, onEnd: () -> Unit) {
        if (thread?.isAlive == true) return
        stopFlag = false
        IosState.updates = 0
        IosState.reconnects = 0
        IosState.lastError = ""
        IosState.running = true
        IosState.status = "Connecting to the iPhone…"
        thread = Thread {
            var attempt = 0
            var quickFailures = 0
            try {
                while (!stopFlag) {
                    val t0 = SystemClock.elapsedRealtime()
                    IosState.status = if (attempt == 0) "Connecting to the iPhone…" else "Reconnecting to the iPhone (#$attempt)…"
                    val rep = try {
                        IosPairing.pairAndTest(ctx, dev, live = true)
                    } catch (e: Throwable) {
                        "ERROR: $e"
                    }
                    IosState.lastReport = rep.takeLast(8000)
                    if (stopFlag) break
                    val lived = SystemClock.elapsedRealtime() - t0
                    quickFailures = if (lived > 20_000) 0 else quickFailures + 1
                    if (quickFailures >= 5) {
                        IosState.lastError = "5 quick failures in a row"
                        IosState.status = "Stopped: 5 quick failures in a row. Is the iPhone unlocked and connected? See the report."
                        alert(ctx, "Could not keep the iPhone connection. The iPhone is on its REAL location.")
                        break
                    }
                    attempt++
                    alert(ctx, "iPhone connection lost: the iPhone is on its REAL location until it reconnects.")
                    IosState.reconnects = attempt
                    IosState.status = "Connection lost, retrying…"
                    var waited = 0
                    while (waited < 3000 && !stopFlag) {
                        Thread.sleep(250)
                        waited += 250
                    }
                }
            } finally {
                IosState.running = false
                IosFeed.active = false
                if (stopFlag) IosState.status = "Stopped: the iPhone is back on its real location."
                onEnd()
            }
        }.also {
            it.isDaemon = true
            it.start()
        }
    }
}
