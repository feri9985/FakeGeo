package dev.fakegeo.app

import android.content.Context
import android.hardware.usb.UsbDevice
import android.os.SystemClock

/** The position the iPhone should show. Fed by the pin button and, while it runs, by MockLocationService (route / joystick). */
object IosFeed {
    @Volatile var lat = Double.NaN
    @Volatile var lon = Double.NaN
    @Volatile var seq = 0L
    @Volatile var active = false

    fun set(la: Double, lo: Double) {
        lat = la
        lon = lo
        seq++
    }
}

/** What the screen and the notification show about the iPhone connection. */
object IosState {
    @Volatile var running = false
    @Volatile var status = ""
    @Volatile var updates = 0
    @Volatile var reconnects = 0
    @Volatile var lastError = ""
    @Volatile var lastReport = ""
}

/**
 * Keeps the whole chain (USB -> pairing -> CoreDevice tunnel -> RSD -> DTX LocationSimulation) alive in a
 * background thread, sends every new position to the iPhone and reconnects when the connection drops.
 * The iPhone goes back to its real location as soon as the connection closes.
 */
object IosSession {
    @Volatile private var stopFlag = false
    @Volatile private var thread: Thread? = null

    fun stopRequested() = stopFlag

    fun stop() {
        stopFlag = true
        if (IosState.running) IosState.status = "Stopping…"
    }

    fun start(ctx: Context, dev: UsbDevice, onEnd: () -> Unit) {
        if (thread?.isAlive == true) return
        stopFlag = false
        IosState.updates = 0
        IosState.reconnects = 0
        IosState.lastError = ""
        IosState.running = true
        IosState.status = "Connecting to the iPhone…"
        thread = Thread {
            var attempt = 0
            var quickFailures = 0
            try {
                while (!stopFlag) {
                    val t0 = SystemClock.elapsedRealtime()
                    IosState.status = if (attempt == 0) "Connecting to the iPhone…" else "Reconnecting to the iPhone (#$attempt)…"
                    val rep = try {
                        IosPairing.pairAndTest(ctx, dev, live = true)
                    } catch (e: Throwable) {
                        "ERROR: $e"
                    }
                    IosState.lastReport = rep.takeLast(8000)
                    if (stopFlag) break
                    val lived = SystemClock.elapsedRealtime() - t0
                    quickFailures = if (lived > 20_000) 0 else quickFailures + 1
                    if (quickFailures >= 5) {
                        IosState.lastError = "5 quick failures in a row"
                        IosState.status = "Stopped: 5 quick failures in a row. Is the iPhone unlocked and connected? See the report."
                        break
                    }
                    attempt++
                    IosState.reconnects = attempt
                    IosState.status = "Connection lost, retrying…"
                    var waited = 0
                    while (waited < 3000 && !stopFlag) {
                        Thread.sleep(250)
                        waited += 250
                    }
                }
            } finally {
                IosState.running = false
                IosFeed.active = false
                if (stopFlag) IosState.status = "Stopped: the iPhone is back on its real location."
                onEnd()
            }
        }.also {
            it.isDaemon = true
            it.start()
        }
    }
}
