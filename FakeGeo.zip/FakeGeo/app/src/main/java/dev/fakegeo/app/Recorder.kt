package dev.fakegeo.app

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Session recorder (diagnostics only). Logs which app is in the foreground and, if the DUMP permission was
 * granted through adb, which location requests the system lists for that app. It only READS; it does not
 * touch other apps.
 */
object Recorder {
    private val sb = StringBuilder()
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var lastPkg: String? = null
    private var lastDump = 0L
    private val seen = HashSet<String>()
    @Volatile var running = false
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun hasUsageAccess(c: Context): Boolean = try {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        ops.checkOpNoThrow("android:get_usage_stats", Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    @Synchronized fun text(): String = sb.toString()
    @Synchronized fun clear() { sb.setLength(0); seen.clear(); lastPkg = null }

    @Synchronized private fun log(s: String) {
        sb.append(fmt.format(Date())).append("  ").append(s).append('\n')
        if (sb.length > 60_000) sb.delete(0, sb.length - 50_000)
    }

    @Synchronized fun start(c: Context) {
        if (running) return
        val app = c.applicationContext
        running = true
        thread = HandlerThread("fg-recorder").also { it.start() }
        handler = Handler(thread!!.looper)
        log("Recorder started. Usage access=${hasUsageAccess(app)}, mock service running=${MockState.running}")
        val r = object : Runnable {
            override fun run() {
                if (!running) return
                try { poll(app) } catch (e: Exception) { log("poll error: ${e.message}") }
                handler?.postDelayed(this, 2000)
            }
        }
        handler!!.post(r)
    }

    @Synchronized fun stop() {
        running = false
        log("Recorder stopped")
        thread?.quitSafely()
        thread = null
        handler = null
    }

    private fun foreground(c: Context): String? {
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val ev = usm.queryEvents(end - 15_000, end)
        val e = UsageEvents.Event()
        var pkg: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) pkg = e.packageName
        }
        return pkg
    }

    private fun poll(c: Context) {
        val fg = foreground(c)
        if (fg != null && fg != lastPkg) {
            lastPkg = fg
            log("FOREGROUND -> $fg  (fake GPS running=${MockState.running})")
            lastDump = 0L
        }
        val pkg = lastPkg ?: return
        val now = System.currentTimeMillis()
        if (now - lastDump < 8000) return
        lastDump = now
        dumpLines(pkg)
    }

    /** Needs: adb shell pm grant dev.fakegeo.app android.permission.DUMP */
    private fun dumpLines(pkg: String) {
        if (c0DumpDenied) return
        try {
            val p = Runtime.getRuntime().exec(arrayOf("dumpsys", "location"))
            val lines = p.inputStream.bufferedReader().readLines()
            p.waitFor()
            if (lines.size < 5) { log("dumpsys location: no output (DUMP permission missing?)"); c0DumpDenied = true; return }
            var n = 0
            for (l in lines) {
                if (l.contains(pkg) && n < 8) {
                    val t = l.trim().take(220)
                    if (seen.add("$pkg|${t.replace(Regex("[0-9]+"), "#")}")) log("LOC[$pkg] $t")
                    n++
                }
            }
        } catch (e: Exception) {
            log("dumpsys failed: ${e.message}")
            c0DumpDenied = true
        }
    }

    private var c0DumpDenied = false
}
