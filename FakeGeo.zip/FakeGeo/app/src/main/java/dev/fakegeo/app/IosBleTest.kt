package dev.fakegeo.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.ParcelUuid
import java.util.UUID

/**
 * Experiment: expose the standard BLE "Location and Navigation" service (0x1819) and notify the fake
 * location through it. This is a long shot: iOS is not known to use this service for system
 * location. The test shows whether the iPhone sees the service and subscribes to it.
 * Observation tools on the iPhone: nRF Connect / LightBlue, and the Maps app.
 */
object IosBleTest {

    private fun u16(v: Int): UUID = UUID.fromString(String.format("%08x-0000-1000-8000-00805f9b34fb", v))

    private val LNS = u16(0x1819)
    private val LN_FEATURE = u16(0x2A6A)
    private val LN_LOC_SPEED = u16(0x2A67)
    private val CCC = u16(0x2902)

    @Volatile
    var running: Boolean = false
        private set

    private var server: BluetoothGattServer? = null
    private var advertiser: BluetoothLeAdvertiser? = null
    private var locChar: BluetoothGattCharacteristic? = null
    private val subscribed = java.util.Collections.synchronizedSet(HashSet<BluetoothDevice>())

    fun hasAdvertisePermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED

    private val advCb = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
            IosDiagnostics.log("BLE advertising started (Location and Navigation 0x1819)")
        }

        override fun onStartFailure(errorCode: Int) {
            IosDiagnostics.log("BLE advertising failed, code=$errorCode")
        }
    }

    private val gattCb = object : BluetoothGattServerCallback() {
        override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
            IosDiagnostics.log("GATT ${device.address} state=$newState status=$status")
            if (newState != BluetoothProfile.STATE_CONNECTED) subscribed.remove(device)
        }

        override fun onServiceAdded(status: Int, service: BluetoothGattService?) {
            IosDiagnostics.log("GATT service added status=$status")
        }

        @SuppressLint("MissingPermission")
        override fun onCharacteristicReadRequest(
            device: BluetoothDevice, requestId: Int, offset: Int, characteristic: BluetoothGattCharacteristic
        ) {
            IosDiagnostics.log("GATT read ${characteristic.uuid} from ${device.address}")
            val full = if (characteristic.uuid == LN_FEATURE) byteArrayOf(0x05, 0, 0, 0) else ByteArray(0)
            val part = if (offset <= full.size) full.copyOfRange(offset, full.size) else ByteArray(0)
            try { server?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, part) } catch (_: Exception) {}
        }

        @SuppressLint("MissingPermission")
        override fun onDescriptorWriteRequest(
            device: BluetoothDevice, requestId: Int, descriptor: BluetoothGattDescriptor,
            preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray?
        ) {
            val on = value != null && value.isNotEmpty() && value[0].toInt() != 0
            IosDiagnostics.log("GATT subscribe ${descriptor.characteristic.uuid} ${if (on) "ON" else "off"} from ${device.address}")
            if (descriptor.uuid == CCC) {
                if (on) subscribed.add(device) else subscribed.remove(device)
            }
            if (responseNeeded) {
                try { server?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, value) } catch (_: Exception) {}
            }
        }

        @SuppressLint("MissingPermission")
        override fun onDescriptorReadRequest(
            device: BluetoothDevice, requestId: Int, offset: Int, descriptor: BluetoothGattDescriptor
        ) {
            try { server?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, byteArrayOf(0, 0)) } catch (_: Exception) {}
        }
    }

    @SuppressLint("MissingPermission")
    fun start(ctx: Context): Boolean {
        if (running) return true
        if (!IosBridge.hasPermission(ctx) || !hasAdvertisePermission(ctx)) return false
        val mgr = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager ?: return false
        val ad = mgr.adapter ?: return false
        val adv = ad.bluetoothLeAdvertiser
        if (adv == null) {
            IosDiagnostics.log("This phone cannot advertise over BLE")
            return false
        }
        return try {
            val srv = mgr.openGattServer(ctx, gattCb) ?: return false
            val svc = BluetoothGattService(LNS, BluetoothGattService.SERVICE_TYPE_PRIMARY)
            svc.addCharacteristic(
                BluetoothGattCharacteristic(
                    LN_FEATURE, BluetoothGattCharacteristic.PROPERTY_READ, BluetoothGattCharacteristic.PERMISSION_READ
                )
            )
            val loc = BluetoothGattCharacteristic(LN_LOC_SPEED, BluetoothGattCharacteristic.PROPERTY_NOTIFY, 0)
            loc.addDescriptor(
                BluetoothGattDescriptor(
                    CCC, BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE
                )
            )
            svc.addCharacteristic(loc)
            srv.addService(svc)
            server = srv
            locChar = loc
            advertiser = adv
            val settings = AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                .setConnectable(true)
                .setTimeout(0)
                .build()
            val data = AdvertiseData.Builder()
                .setIncludeDeviceName(false)
                .addServiceUuid(ParcelUuid(LNS))
                .build()
            val scanResp = AdvertiseData.Builder().setIncludeDeviceName(true).build()
            adv.startAdvertising(settings, data, scanResp, advCb)
            running = true
            true
        } catch (e: Exception) {
            IosDiagnostics.log("BLE test failed to start: ${e.message}")
            stop()
            false
        }
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        try { advertiser?.stopAdvertising(advCb) } catch (_: Exception) {}
        try { server?.close() } catch (_: Exception) {}
        advertiser = null
        server = null
        locChar = null
        subscribed.clear()
        if (running) IosDiagnostics.log("BLE test stopped")
        running = false
    }

    private fun le16(b: ByteArray, o: Int, v: Int) {
        b[o] = (v and 0xFF).toByte()
        b[o + 1] = ((v shr 8) and 0xFF).toByte()
    }

    private fun le32(b: ByteArray, o: Int, v: Int) {
        for (k in 0 until 4) b[o + k] = ((v shr (8 * k)) and 0xFF).toByte()
    }

    /** Location and Speed characteristic: flags, speed (0.01 m/s), location (1e-7 deg), heading (0.01 deg). */
    private fun encode(lat: Double, lon: Double, speed: Float, bearing: Float): ByteArray {
        val b = ByteArray(14)
        le16(b, 0, 0x0001 or 0x0004 or 0x0010)
        le16(b, 2, (speed * 100f).toInt().coerceIn(0, 0xFFFF))
        le32(b, 4, (lat * 1e7).toInt())
        le32(b, 8, (lon * 1e7).toInt())
        le16(b, 12, ((((bearing % 360f) + 360f) % 360f) * 100f).toInt().coerceIn(0, 35999))
        return b
    }

    @SuppressLint("MissingPermission")
    fun onLocation(lat: Double, lon: Double, speed: Float, bearing: Float) {
        if (!running) return
        val g = server ?: return
        val ch = locChar ?: return
        val data = encode(lat, lon, speed, bearing)
        for (d in subscribed.toList()) {
            try {
                if (Build.VERSION.SDK_INT >= 33) {
                    g.notifyCharacteristicChanged(d, ch, false, data)
                } else {
                    @Suppress("DEPRECATION")
                    ch.value = data
                    @Suppress("DEPRECATION")
                    g.notifyCharacteristicChanged(d, ch, false)
                }
            } catch (_: Exception) {}
        }
    }
}
