package dev.fakegeo.app

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Apple's signing server (TSS) client for the personalized Developer Disk Image (iOS 17+).
 * Protocol re-implemented in Kotlin from the public description in pymobiledevice3 (GPL-3.0).
 */
object Tss {

    private const val URL_TSS = "http://gs.apple.com/TSS/controller?action=2"
    private const val CLIENT_VERSION = "libauthinstall-1104.0.9"

    private fun num(v: Any?): Long? = when (v) {
        is Long -> v
        is Int -> v.toLong()
        is Boolean -> if (v) 1L else 0L
        is String -> try { java.lang.Long.decode(v.trim()) } catch (_: Exception) { null }
        else -> null
    }

    private fun truthy(v: Any?): Boolean = when (v) {
        null -> false
        is Boolean -> v
        is Long -> v != 0L
        is String -> v.isNotEmpty()
        is ByteArray -> v.isNotEmpty()
        else -> true
    }

    /** Python-like equality where True == 1. */
    private fun same(a: Any?, b: Any?): Boolean {
        val x = num(a); val y = num(b)
        return if (x != null && y != null && a !is String && b !is String) x == y else a == b
    }

    @Suppress("UNCHECKED_CAST")
    private fun applyRules(entry: MutableMap<String, Any?>, params: Map<String, Any?>, rules: List<*>) {
        for (rule in rules) {
            val r = rule as? Map<String, Any?> ?: continue
            val cond = r["Conditions"] as? Map<String, Any?> ?: emptyMap()
            var ok = true
            for ((k, v) in cond) {
                if (!ok) break
                val v2: Any? = when (k) {
                    "ApRawProductionMode", "ApCurrentProductionMode" -> params["ApProductionMode"]
                    "ApRawSecurityMode" -> params["ApSecurityMode"]
                    "ApRequiresImage4" -> params["ApSupportsImg4"]
                    "ApDemotionPolicyOverride" -> params["DemotionPolicy"]
                    "ApInRomDFU" -> params["ApInRomDFU"]
                    else -> null
                }
                ok = truthy(v2) && same(v, v2)
            }
            if (!ok) continue
            val actions = r["Actions"] as? Map<String, Any?> ?: continue
            for ((k, v) in actions) {
                if (num(v) != 255L || v is Boolean) {
                    entry.remove(k)
                    entry[k] = v
                }
            }
        }
    }

    @Suppress("UNCHECKED_CAST")
    fun personalize(
        buildManifest: Map<String, Any?>, ids: Map<String, Any?>, ecid: Long, apNonce: ByteArray, log: (String) -> Unit
    ): ByteArray {
        val boardId = num(ids["BoardId"]) ?: throw IOException("device sent no BoardId")
        val chipId = num(ids["ChipID"]) ?: throw IOException("device sent no ChipID")

        val identity = (buildManifest["BuildIdentities"] as? List<*>)?.firstNotNullOfOrNull { bi ->
            val m = bi as? Map<String, Any?> ?: return@firstNotNullOfOrNull null
            if (!m.containsKey("ApBoardID") || !m.containsKey("ApChipID")) return@firstNotNullOfOrNull null
            if (num(m["ApBoardID"]) == boardId && num(m["ApChipID"]) == chipId) m else null
        } ?: throw IOException("The image's BuildManifest has no entry for this iPhone (board $boardId, chip $chipId)")
        val manifest = identity["Manifest"] as? Map<String, Any?> ?: throw IOException("BuildManifest has no Manifest")

        val req = LinkedHashMap<String, Any?>()
        req["@HostPlatformInfo"] = "mac"
        req["@VersionInfo"] = CLIENT_VERSION
        req["@UUID"] = UUID.randomUUID().toString().uppercase()
        for ((k, v) in ids) if (k.startsWith("Ap,")) req[k] = v

        val params = mapOf<String, Any?>(
            "ApProductionMode" to true, "ApSecurityDomain" to 1L, "ApSecurityMode" to true, "ApSupportsImg4" to true
        )
        req["@ApImg4Ticket"] = true
        req["@BBTicket"] = true
        req["ApBoardID"] = boardId
        req["ApChipID"] = chipId
        req["ApECID"] = ecid
        req["ApNonce"] = apNonce
        req["ApProductionMode"] = true
        req["ApSecurityDomain"] = 1L
        req["ApSecurityMode"] = true
        req["SepNonce"] = ByteArray(20)
        req["UID_MODE"] = false

        val rules = ((manifest["LoadableTrustCache"] as? Map<String, Any?>)?.get("Info") as? Map<String, Any?>)
            ?.get("RestoreRequestRules") as? List<*>

        for ((key, e) in manifest) {
            val entry = e as? Map<String, Any?> ?: continue
            if (entry["Info"] == null) continue
            if (entry["Trusted"] != true) { log("skip $key (not trusted)"); continue }
            val tssEntry = LinkedHashMap(entry)
            tssEntry.remove("Info")
            if (!rules.isNullOrEmpty()) applyRules(tssEntry, params, rules)
            if (entry["Digest"] == null) tssEntry["Digest"] = ByteArray(0)
            req[key] = tssEntry
        }

        val body = Plist.encode(req)
        log("Sending the signing request to Apple (${body.size} bytes)…")
        val c = URL(URL_TSS).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("Cache-Control", "no-cache")
        c.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"")
        c.setRequestProperty("User-Agent", "InetURL/1.0")
        val content: ByteArray = try {
            c.outputStream.use { it.write(body) }
            val st = if (c.responseCode in 200..299) c.inputStream else (c.errorStream ?: c.inputStream)
            st.use { it.readBytes() }
        } finally { c.disconnect() }

        val text = String(content, Charsets.UTF_8)
        val msg = text.substringAfter("MESSAGE=", "").substringBefore("&")
        if (msg != "SUCCESS") throw IOException("Apple's signing server refused the request: ${msg.ifEmpty { text.take(200) }}")
        val plist = Plist.decode(text.substringAfter("REQUEST_STRING=").toByteArray(Charsets.UTF_8))
        return plist["ApImg4Ticket"] as? ByteArray ?: throw IOException("TSS reply has no ApImg4Ticket")
    }
}
