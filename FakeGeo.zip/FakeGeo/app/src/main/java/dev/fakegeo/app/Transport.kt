package dev.fakegeo.app

import android.os.SystemClock
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException

/** Where the connections to the iPhone come from: the USB cable (usbmux) or Wi-Fi (plain TCP sockets). */
interface Transport {
    /** Opens a TCP connection to [port] on the iPhone, or returns null. */
    fun connect(port: Int): UsbMux.Stream?
    fun close()
}

/** No cable: lockdownd and the services are reached directly at the iPhone's Wi-Fi address. */
class WifiLink(private val host: String, private val log: (String) -> Unit) : Transport {
    override fun connect(port: Int): UsbMux.Stream? {
        return try {
            val s = Socket()
            s.tcpNoDelay = true
            s.keepAlive = true
            s.connect(InetSocketAddress(host, port), 6000)
            SocketStream(s)
        } catch (e: Exception) {
            log("Wi-Fi: cannot reach $host:$port (${e.javaClass.simpleName}: ${e.message})")
            null
        }
    }

    override fun close() {}
}

/** A java.net.Socket as a [UsbMux.Stream]. Bytes read before a timeout are kept for the next call. */
class SocketStream(private val s: Socket) : UsbMux.Stream {
    private val inp = s.getInputStream()
    private val out = s.getOutputStream()
    private var buf = ByteArray(0)
    private val tmp = ByteArray(16384)

    override fun write(data: ByteArray) {
        try {
            out.write(data)
            out.flush()
        } catch (e: IOException) {
            throw IOException("connection reset by the iPhone (Wi-Fi): ${e.message}")
        }
    }

    private fun fill(deadline: Long) {
        val left = (deadline - SystemClock.elapsedRealtime()).toInt()
        if (left <= 0) throw IOException("timeout waiting for the iPhone")
        s.soTimeout = left
        val r = try {
            inp.read(tmp)
        } catch (e: SocketTimeoutException) {
            throw IOException("timeout waiting for the iPhone")
        } catch (e: IOException) {
            throw IOException("connection reset by the iPhone (Wi-Fi): ${e.message}")
        }
        if (r < 0) throw IOException("connection closed by the iPhone (Wi-Fi)")
        buf += tmp.copyOf(r)
    }

    override fun read(n: Int, timeoutMs: Int): ByteArray {
        val deadline = SystemClock.elapsedRealtime() + timeoutMs.coerceAtLeast(1)
        while (buf.size < n) fill(deadline)
        val r = buf.copyOfRange(0, n)
        buf = buf.copyOfRange(n, buf.size)
        return r
    }

    override fun readSome(timeoutMs: Int): ByteArray {
        val deadline = SystemClock.elapsedRealtime() + timeoutMs.coerceAtLeast(1)
        while (buf.isEmpty()) fill(deadline)
        val r = buf
        buf = ByteArray(0)
        return r
    }

    override fun close() {
        try { s.close() } catch (_: Exception) {}
    }
}
