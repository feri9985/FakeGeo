package dev.fakegeo.app

/** Where the connections to the iPhone come from (today: the USB cable through usbmux). */
interface Transport {
    /** Opens a TCP connection to [port] on the iPhone, or returns null. */
    fun connect(port: Int): UsbMux.Stream?
    fun close()
}
