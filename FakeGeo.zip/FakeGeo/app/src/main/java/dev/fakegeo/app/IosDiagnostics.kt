package dev.fakegeo.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothServerSocket
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Diagnostics for iOS Mode. Goal: see what the iPhone actually does with this phone after
 * "Connected" (which profiles/services it uses, whether it opens a data channel), so the
 * missing location delivery method can be identified. It only observes; it sends nothing.
 */
object IosDiagnostics {

    private val buf = ArrayList<String>()

    @Synchronized
    fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        buf.add(0, "$t  $msg")
        while (buf.size > 150) buf.removeAt(buf.size - 1)
    }

    @Synchronized
    fun lines(): List<String> = ArrayList(buf)

    @Synchronized
    fun clear() = buf.clear()

    private val KNOWN = mapOf(
        "00001101" to "SPP (serial)",
        "00001105" to "OPP (file push)",
        "00001108" to "Headset",
        "0000110a" to "A2DP source",
        "0000110b" to "A2DP sink",
        "0000110c" to "AVRCP target",
        "0000110e" to "AVRCP controller",
        "00001112" to "Headset AG",
        "00001115" to "PAN user",
        "00001116" to "NAP",
        "0000111e" to "Handsfree",
        "0000111f" to "Handsfree AG",
        "00001124" to "HID",
        "0000112f" to "PBAP server",
        "00001132" to "MAP server",
        "00001800" to "GAP",
        "00001801" to "GATT",
        "0000180a" to "Device info",
        "00000000-deca-fade-deca-deafdecacafe" to "Apple iAP2"
    )

    private fun uuidName(u: String): String {
        val l = u.lowercase(Locale.US)
        val named = KNOWN.entries.firstOrNull { l.startsWith(it.key) || l == it.key }?.value
        return if (named != null) "$l ($named)" else l
    }

    fun deviceOf(i: Intent): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33)
            i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        else @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

    /** Logs any Bluetooth broadcast we registered for. */
    @SuppressLint("MissingPermission")
    fun logIntent(i: Intent) {
        val act = i.action ?: return
        val dev = deviceOf(i)
        val who = try {
            if (dev != null) "${dev.name ?: "?"} ${dev.address}" else "-"
        } catch (_: SecurityException) {
            dev?.address ?: "-"
        }
        val sb = StringBuilder()
        if (i.hasExtra("android.bluetooth.profile.extra.STATE")) {
            sb.append("  state=").append(i.getIntExtra("android.bluetooth.profile.extra.STATE", -1))
        }
        if (i.hasExtra(BluetoothDevice.EXTRA_BOND_STATE)) {
            sb.append("  bond=").append(i.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, -1))
        }
        if (i.hasExtra(BluetoothAdapter.EXTRA_STATE)) {
            sb.append("  adapter=").append(i.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1))
        }
        if (act == BluetoothDevice.ACTION_UUID) {
            @Suppress("DEPRECATION")
            val arr = i.getParcelableArrayExtra(BluetoothDevice.EXTRA_UUID)
            if (arr != null) sb.append("\n    uuids: ").append(arr.joinToString(", ") { uuidName(it.toString()) })
        }
        log(act.removePrefix("android.bluetooth.") + "  " + who + sb)
    }

    private inline fun safe(sb: StringBuilder, label: String, block: () -> String) {
        try {
            sb.append(label).append(block()).append('\n')
        } catch (_: SecurityException) {
            sb.append(label).append("(no permission)\n")
        } catch (e: Exception) {
            sb.append(label).append("error: ").append(e.message).append('\n')
        }
    }

    private fun stateName(s: Int) = when (s) {
        BluetoothProfile.STATE_DISCONNECTED -> "disconnected"
        BluetoothProfile.STATE_CONNECTING -> "connecting"
        BluetoothProfile.STATE_CONNECTED -> "CONNECTED"
        BluetoothProfile.STATE_DISCONNECTING -> "disconnecting"
        else -> "?($s)"
    }

    /** Snapshot of this phone and the selected device. Also asks Android to re-read the device services. */
    @SuppressLint("MissingPermission")
    fun report(ctx: Context, address: String?): String {
        val sb = StringBuilder()
        sb.append("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}\n")
        val ad = IosBridge.adapter(ctx)
        if (ad == null) return sb.append("No Bluetooth adapter\n").toString()
        if (!IosBridge.hasPermission(ctx)) return sb.append("Bluetooth permission not granted\n").toString()

        safe(sb, "Bluetooth: ") { if (ad.isEnabled) "on" else "off" }
        safe(sb, "This phone name: ") { ad.name ?: "?" }
        safe(sb, "BLE advertising supported: ") { ad.isMultipleAdvertisementSupported.toString() }
        sb.append("Profiles on this phone:\n")
        listOf(
            "A2DP" to BluetoothProfile.A2DP,
            "HEADSET" to BluetoothProfile.HEADSET,
            "GATT (client)" to BluetoothProfile.GATT,
            "GATT_SERVER" to BluetoothProfile.GATT_SERVER
        ).forEach { (n, p) ->
            safe(sb, "  $n: ") { stateName(ad.getProfileConnectionState(p)) }
        }

        sb.append("\nSelected device:\n")
        if (address == null) {
            sb.append("  none selected\n")
        } else {
            try {
                val d = ad.getRemoteDevice(address)
                safe(sb, "  name: ") { d.name ?: "?" }
                sb.append("  address: ").append(address).append('\n')
                safe(sb, "  type: ") {
                    when (d.type) {
                        BluetoothDevice.DEVICE_TYPE_CLASSIC -> "classic"
                        BluetoothDevice.DEVICE_TYPE_LE -> "LE only"
                        BluetoothDevice.DEVICE_TYPE_DUAL -> "dual (classic + LE)"
                        else -> "unknown"
                    }
                }
                safe(sb, "  bond: ") {
                    when (d.bondState) {
                        BluetoothDevice.BOND_BONDED -> "bonded"
                        BluetoothDevice.BOND_BONDING -> "bonding"
                        else -> "none"
                    }
                }
                sb.append("  link up now: ").append(IosBridge.isLinked(address)).append('\n')
                safe(sb, "  class: ") {
                    d.bluetoothClass?.let { "major=0x%x device=0x%x".format(it.majorDeviceClass, it.deviceClass) } ?: "?"
                }
                safe(sb, "  services: ") {
                    val u = d.uuids
                    if (u.isNullOrEmpty()) "none known yet (a UUID update will appear in the log)"
                    else "\n    " + u.joinToString("\n    ") { uuidName(it.uuid.toString()) }
                }
                try { d.fetchUuidsWithSdp() } catch (_: Exception) {}
            } catch (e: Exception) {
                sb.append("  error: ").append(e.message).append('\n')
            }
        }

        sb.append("\nPaired devices:\n")
        safe(sb, "") {
            val l = ad.bondedDevices.orEmpty()
            if (l.isEmpty()) "  none" else l.joinToString("\n") { "  ${it.name ?: "?"}  ${it.address}" }
        }
        sb.append("\nListening for incoming serial data: ").append(listening).append('\n')
        return sb.toString()
    }

    // ---------------- Optional listener for a serial (SPP) channel ----------------

    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var server: BluetoothServerSocket? = null
    @Volatile var listening: Boolean = false
        private set

    private fun hex(b: ByteArray, n: Int): String {
        val m = minOf(n, 48)
        val s = StringBuilder()
        for (k in 0 until m) s.append("%02x ".format(b[k]))
        if (n > m) s.append("...")
        return s.toString().trim()
    }

    /** Opens a serial channel and logs whoever connects and the first bytes they send. */
    @SuppressLint("MissingPermission")
    fun startListening(ctx: Context): Boolean {
        if (listening) return true
        val ad = IosBridge.adapter(ctx) ?: return false
        if (!IosBridge.hasPermission(ctx)) return false
        return try {
            val ss = ad.listenUsingRfcommWithServiceRecord("FakeGeo iOS", SPP)
            server = ss
            listening = true
            log("Listening on SPP")
            Thread {
                while (listening) {
                    val sock = try { ss.accept() } catch (e: Exception) {
                        if (listening) log("accept stopped: ${e.message}")
                        break
                    }
                    try {
                        val dev = sock.remoteDevice
                        log("RFCOMM connection from ${dev.name ?: "?"} ${dev.address}")
                        val input = sock.inputStream
                        val b = ByteArray(256)
                        while (listening) {
                            val n = input.read(b)
                            if (n <= 0) break
                            log("RX $n bytes: ${hex(b, n)}")
                        }
                    } catch (e: Exception) {
                        log("RFCOMM closed: ${e.message}")
                    }
                    try { sock.close() } catch (_: Exception) {}
                }
            }.start()
            true
        } catch (e: Exception) {
            log("Listen failed: ${e.message}")
            false
        }
    }

    fun stopListening() {
        if (!listening) return
        listening = false
        try { server?.close() } catch (_: Exception) {}
        server = null
        log("Listening stopped")
    }
}
