package dev.fakegeo.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

/**
 * iOS Mode: the Android phone acts as the "controller" for an iPhone over Bluetooth.
 *
 * What is implemented here:
 *  - mode switch + saved state
 *  - Bluetooth availability / permission checks
 *  - listing paired devices and choosing the target iPhone
 *  - a single hook (publish) that receives every location the app produces
 *
 * What is NOT implemented yet: the actual transport that delivers the location to the iPhone.
 * iOS does not accept location from an arbitrary Bluetooth device, so the delivery method has to
 * be chosen first. Put it in a class that implements [Transport] and assign it to [transport].
 * Until then [publish] only counts the updates and nothing reaches the iPhone.
 */
object IosBridge {

    /** Delivery channel to the iPhone. Implement this once the method is decided. */
    interface Transport {
        val name: String
        fun connect(device: BluetoothDevice): Boolean
        fun send(lat: Double, lon: Double, accuracy: Float, speed: Float, bearing: Float)
        fun disconnect()
    }

    @Volatile var transport: Transport? = null

    @Volatile var enabled: Boolean = false
    @Volatile var deviceName: String? = null
    @Volatile var deviceAddress: String? = null
    @Volatile var connected: Boolean = false
    @Volatile var updatesSeen: Long = 0L
    @Volatile var lastError: String? = null

    /** Addresses with an active Bluetooth (ACL) link to this phone, updated by broadcasts. */
    private val linked = java.util.Collections.synchronizedSet(HashSet<String>())
    fun setLinked(address: String, up: Boolean) { if (up) linked.add(address) else linked.remove(address) }
    fun isLinked(address: String?): Boolean = address != null && linked.contains(address)

    private const val PREFS = "fakegeo"

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        enabled = p.getBoolean("ios_enabled", false)
        deviceName = p.getString("ios_dev_name", null)
        deviceAddress = p.getString("ios_dev_addr", null)
    }

    fun setEnabled(ctx: Context, on: Boolean) {
        enabled = on
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("ios_enabled", on).apply()
        if (!on) disconnect()
        MockState.log(if (on) "iOS Mode on" else "iOS Mode off")
    }

    fun chooseDevice(ctx: Context, name: String?, address: String?) {
        deviceName = name
        deviceAddress = address
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("ios_dev_name", name)
            .putString("ios_dev_addr", address)
            .apply()
    }

    // ---------------- Bluetooth helpers ----------------

    fun adapter(ctx: Context): BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    fun hasHardware(ctx: Context): Boolean =
        ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH)

    fun isBluetoothOn(ctx: Context): Boolean = adapter(ctx)?.isEnabled == true

    /** Android 12+ needs BLUETOOTH_CONNECT at runtime to read the paired list. */
    fun needsRuntimePermission(): Boolean = Build.VERSION.SDK_INT >= 31

    fun hasPermission(ctx: Context): Boolean =
        !needsRuntimePermission() ||
            ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    fun requestPermission(a: Activity, code: Int) {
        if (needsRuntimePermission()) {
            a.requestPermissions(
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE), code
            )
        }
    }

    data class Dev(val name: String, val address: String)

    @SuppressLint("MissingPermission")
    fun pairedDevices(ctx: Context): List<Dev> {
        if (!hasPermission(ctx)) return emptyList()
        val ad = adapter(ctx) ?: return emptyList()
        return try {
            ad.bondedDevices.orEmpty()
                .map { Dev(it.name ?: it.address, it.address) }
                .sortedBy { it.name.lowercase() }
        } catch (_: SecurityException) {
            emptyList()
        }
    }

    // ---------------- Connection + location feed ----------------

    @SuppressLint("MissingPermission")
    fun connect(ctx: Context): Boolean {
        val t = transport
        if (t == null) {
            lastError = "No transport yet: the delivery method to the iPhone is not implemented."
            connected = false
            return false
        }
        val addr = deviceAddress ?: run {
            lastError = "Choose a device first."
            return false
        }
        val dev = try { adapter(ctx)?.getRemoteDevice(addr) } catch (_: Exception) { null }
        if (dev == null) {
            lastError = "Device not found."
            return false
        }
        connected = try { t.connect(dev) } catch (e: Exception) {
            lastError = e.message
            false
        }
        MockState.log(if (connected) "iOS connected: ${t.name}" else "iOS connect failed")
        return connected
    }

    fun disconnect() {
        try { transport?.disconnect() } catch (_: Exception) {}
        connected = false
    }

    /** Called by MockLocationService on every push with the same values sent to Android. */
    fun publish(lat: Double, lon: Double, accuracy: Float, speed: Float, bearing: Float) {
        IosBleTest.onLocation(lat, lon, speed, bearing)
        if (!enabled) return
        updatesSeen++
        if (!connected) return
        try {
            transport?.send(lat, lon, accuracy, speed, bearing)
        } catch (e: Exception) {
            lastError = e.message
            connected = false
        }
    }

    fun statusLine(): String = when {
        !enabled -> "Off"
        deviceName == null -> "On. Waiting for the iPhone to pair or be selected"
        isLinked(deviceAddress) && transport == null ->
            "Bluetooth linked to $deviceName. Sending the location is not implemented yet"
        isLinked(deviceAddress) -> "Linked to $deviceName"
        else -> "Selected: $deviceName (not connected right now)"
    }
}
