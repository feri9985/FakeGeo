package dev.fakegeo.app

import android.content.Context
import android.content.Intent

/**
 * Kill switch: وقتی فیک GPS قطع شد، اینترنت اپ‌های انتخاب‌شده رو (با یک VPN محلی که همه‌ی ترافیک رو دور می‌ریزه)
 * قطع می‌کنه تا لوکیشن واقعی به سرور اپ نرسه.
 */
object KillSwitch {
    const val ACTION_BLOCK = "dev.fakegeo.KS_BLOCK"
    const val ACTION_UNBLOCK = "dev.fakegeo.KS_UNBLOCK"

    @Volatile var blocking: Boolean = false

    fun enabled(c: Context): Boolean =
        c.getSharedPreferences("fakegeo", Context.MODE_PRIVATE).getBoolean("ks_enabled", false)

    fun block(c: Context) = send(c, ACTION_BLOCK)
    fun unblock(c: Context) = send(c, ACTION_UNBLOCK)

    private fun send(c: Context, action: String) {
        try {
            c.applicationContext.startService(
                Intent(c.applicationContext, KillSwitchService::class.java).setAction(action)
            )
        } catch (e: Exception) {
            MockState.log("Kill switch error: ${e.message}")
        }
    }
}
