package dev.fakegeo.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * After a reboot: if the fake GPS was active, post a notification to resume it with one tap.
 * (Android 14+ does not allow starting a location foreground service from boot, so a tap is required.)
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED && i.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val p = c.getSharedPreferences("fakegeo", Context.MODE_PRIVATE)
        if (!p.getBoolean("active", false)) return
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("fakegeo_alert", "Alerts", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java).putExtra("resume", true),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = android.app.Notification.Builder(c, "fakegeo_alert")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Fake GPS is not running")
            .setContentText("Phone restarted. Tap to resume the saved pin.")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(3, n)
    }
}
