package dev.fakegeo.app

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.SystemClock
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Step 1 of "Remote Pairing" (no cable, iOS 17+): does the iPhone advertise the services that Apple's own
 * wireless tools use? Browses Bonjour for a few seconds and lists what it finds. Nothing is changed on the iPhone.
 */
object Bonjour {

    private val TYPES = listOf(
        "_remotepairing._tcp",
        "_remotepairing-manual-pairing._tcp",
        "_remoted._tcp",
        "_apple-mobdev2._tcp"
    )

    private fun text(b: ByteArray?): String {
        if (b == null) return ""
        val s = String(b, Charsets.UTF_8).filter { it.code in 32..126 }
        return if (s.length > 60) s.take(60) + "…" else s
    }

    @Suppress("DEPRECATION")
    fun scan(ctx: Context, seconds: Int): String {
        val out = StringBuilder()
        fun p(s: String) { out.appendLine(s); MockState.log("Bonjour: $s") }

        val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val lock = try { wm?.createMulticastLock("fakegeo-nsd")?.apply { setReferenceCounted(false); acquire() } } catch (_: Exception) { null }

        val found = ConcurrentLinkedQueue<NsdServiceInfo>()
        val listeners = ArrayList<NsdManager.DiscoveryListener>()
        val counts = HashMap<String, Int>()
        for (t in TYPES) {
            val l = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(s: String) {}
                override fun onServiceFound(i: NsdServiceInfo) { counts[t] = (counts[t] ?: 0) + 1; found.add(i) }
                override fun onServiceLost(i: NsdServiceInfo) {}
                override fun onDiscoveryStopped(s: String) {}
                override fun onStartDiscoveryFailed(s: String, e: Int) { p("$t: could not start the scan (error $e)") }
                override fun onStopDiscoveryFailed(s: String, e: Int) {}
            }
            try {
                nsd.discoverServices(t, NsdManager.PROTOCOL_DNS_SD, l)
                listeners.add(l)
            } catch (e: Exception) {
                p("$t: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
        p("Scanning the local network for $seconds s… (the iPhone should be unlocked and on this Wi-Fi)")

        var resolving = false
        val lines = ArrayList<String>()
        val end = SystemClock.elapsedRealtime() + seconds * 1000L
        try {
            while (SystemClock.elapsedRealtime() < end) {
                if (!resolving) {
                    val info = found.poll()
                    if (info != null) {
                        resolving = true
                        try {
                            nsd.resolveService(info, object : NsdManager.ResolveListener {
                                override fun onResolveFailed(i: NsdServiceInfo, e: Int) {
                                    lines.add("• ${i.serviceName} [${i.serviceType}] could not be resolved (error $e)")
                                    resolving = false
                                }
                                override fun onServiceResolved(r: NsdServiceInfo) {
                                    val attrs = r.attributes.entries.joinToString(", ") { "${it.key}=${text(it.value)}" }
                                    lines.add("• ${r.serviceName} [${r.serviceType.trim('.')}]  ${r.host?.hostAddress}:${r.port}" +
                                        if (attrs.isNotEmpty()) "\n    $attrs" else "")
                                    resolving = false
                                }
                            })
                        } catch (e: Exception) {
                            lines.add("• ${info.serviceName}: resolve failed (${e.message})")
                            resolving = false
                        }
                    }
                }
                Thread.sleep(100)
            }
        } finally {
            for (l in listeners) try { nsd.stopServiceDiscovery(l) } catch (_: Exception) {}
            try { lock?.release() } catch (_: Exception) {}
        }

        p("")
        for (t in TYPES) p("$t: ${counts[t] ?: 0} found")
        p("")
        if (lines.isEmpty()) {
            p("Nothing was found. Either the iPhone does not advertise these services over Wi-Fi, " +
                "or this network does not carry Bonjour between the two phones (a hotspot often does not).")
        } else {
            lines.forEach { p(it) }
        }
        return out.toString()
    }
}
