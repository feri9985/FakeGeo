package dev.fakegeo.app

import android.location.Location
import android.provider.Settings
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * Instagram-only compatibility hook for Location mock-status and the
 * legacy Developer Options settings queried through Settings.getInt().
 *
 * This changes values visible to the Instagram process only; it does not
 * make a mock GPS feed indistinguishable from a genuine GNSS/network fix.
 */
class LocationHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != TARGET_PACKAGE) return

        hookLocationMockFlags()
        hookSettingsFlags()
    }

    private fun hookLocationMockFlags() {
        hookAll(Location::class.java, "isFromMockProvider")
        // Location.isMock() is available on newer Android releases.
        hookAll(Location::class.java, "isMock")
    }

    private fun hookSettingsFlags() {
        // Legacy mock-location setting. Some Android versions no longer use it.
        hookIntSetting(Settings.Secure::class.java, "mock_location")

        // Developer Options enabled flag.
        hookIntSetting(Settings.Global::class.java, "development_settings_enabled")
        // Older Android releases exposed this flag through Secure.
        hookIntSetting(Settings.Secure::class.java, "development_settings_enabled")
    }

    private fun hookAll(clazz: Class<*>, methodName: String) {
        try {
            XposedBridge.hookAllMethods(clazz, methodName, object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    param.result = false
                }
            })
            XposedBridge.log("FakeGeo: hooked ${clazz.name}.$methodName for Instagram")
        } catch (t: Throwable) {
            XposedBridge.log("FakeGeo: unable to hook ${clazz.name}.$methodName: $t")
        }
    }

    private fun hookIntSetting(clazz: Class<*>, key: String) {
        try {
            XposedBridge.hookAllMethods(clazz, "getInt", object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val requestedKey = param.args.getOrNull(1) as? String
                    if (requestedKey == key) {
                        param.result = 0
                    }
                }
            })
            XposedBridge.log("FakeGeo: hooked ${clazz.name}.getInt($key) for Instagram")
        } catch (t: Throwable) {
            XposedBridge.log("FakeGeo: unable to hook ${clazz.name}.getInt: $t")
        }
    }

    private companion object {
        const val TARGET_PACKAGE = "com.instagram.android"
    }
}
