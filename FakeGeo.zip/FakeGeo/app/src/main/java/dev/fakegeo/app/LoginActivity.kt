package dev.fakegeo.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.concurrent.thread

/** Login screen. MainActivity sends you here when you are not logged in (or the 6 h check expired). */
class LoginActivity : Activity() {

    private lateinit var etUser: EditText
    private lateinit var etPass: EditText
    private lateinit var btn: Button
    private lateinit var tv: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(28), dp(28), dp(28))
            setBackgroundColor(Color.parseColor("#0B1020"))
        }
        box.addView(TextView(this).apply {
            text = "FakeGeo"
            textSize = 28f
            setTextColor(Color.parseColor("#E5E7EB"))
            gravity = Gravity.CENTER
        })
        box.addView(TextView(this).apply {
            text = "برای ورود، یوزر و رمزی که ادمین داده رو بزن"
            textSize = 13f
            setTextColor(Color.parseColor("#94A3B8"))
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(20))
        })
        etUser = field("یوزر", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        etPass = field("رمز", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        box.addView(etUser)
        box.addView(etPass)
        btn = Button(this).apply {
            text = "ورود"
            setOnClickListener { onButton() }
        }
        box.addView(btn)
        tv = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#FBBF24"))
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        }
        box.addView(tv)
        setContentView(box)

        val saved = Gate.savedUser(this)
        if (saved.isNotEmpty()) etUser.setText(saved.removeSuffix("@fakegeo.app"))
        // Already logged in earlier: check silently, no typing needed
        if (Gate.hasSession(this)) runCheck { Gate.verify(this) }
    }

    private fun field(hintText: String, type: Int) = EditText(this).apply {
        hint = hintText
        inputType = type
        setSingleLine(true)
        setTextColor(Color.parseColor("#E5E7EB"))
        setHintTextColor(Color.parseColor("#64748B"))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10) }
    }

    private fun onButton() {
        val u = etUser.text.toString().trim()
        val p = etPass.text.toString()
        if (u.isEmpty() || p.isEmpty()) {
            if (Gate.hasSession(this)) runCheck { Gate.verify(this) }
            else tv.text = "یوزر و رمز رو وارد کن"
            return
        }
        runCheck { Gate.login(this, u, p) }
    }

    private fun runCheck(work: () -> Gate.Res) {
        btn.isEnabled = false
        tv.setTextColor(Color.parseColor("#94A3B8"))
        tv.text = "در حال بررسی…"
        thread {
            val r = work()
            runOnUiThread { handle(r) }
        }
    }

    private fun handle(r: Gate.Res) {
        btn.isEnabled = true
        when (r) {
            is Gate.Res.Ok -> openMain()
            is Gate.Res.Denied -> show(r.msg)
            is Gate.Res.NetError ->
                // No internet: let the user in if the last good check was less than 3 days ago
                if (Gate.allowOfflineIfGrace(this)) openMain() else show(r.msg)
        }
    }

    private fun show(msg: String) {
        tv.setTextColor(Color.parseColor("#FBBF24"))
        tv.text = msg
    }

    private fun openMain() {
        val i = Intent(this, MainActivity::class.java)
        intent?.getStringExtra("next_action")?.let { i.action = it }
        startActivity(i)
        finish()
    }
}
