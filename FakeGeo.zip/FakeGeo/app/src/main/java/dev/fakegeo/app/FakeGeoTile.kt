package dev.fakegeo.app

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile: toggles the fake GPS using the last saved pin. */
class FakeGeoTile : TileService() {

    override fun onStartListening() = refresh()

    override fun onClick() {
        val p = getSharedPreferences("fakegeo", MODE_PRIVATE)
        if (p.getBoolean("active", false)) {
            p.edit().putBoolean("active", false).apply()
            stopService(Intent(this, MockLocationService::class.java))
            MockState.running = false
        } else {
            if (p.getString("pin_lat", null) == null) {
                // No pin saved yet: open the app so the user can pick one
                val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (android.os.Build.VERSION.SDK_INT >= 34) {
                    startActivityAndCollapse(
                        android.app.PendingIntent.getActivity(this, 0, i, android.app.PendingIntent.FLAG_IMMUTABLE)
                    )
                } else {
                    legacyCollapse(i)
                }
                return
            }
            p.edit().putBoolean("active", true).apply()
            startForegroundService(
                Intent(this, MockLocationService::class.java).setAction(MockLocationService.ACTION_START)
            )
        }
        refresh()
    }

    @Suppress("DEPRECATION")
    private fun legacyCollapse(i: Intent) {
        startActivityAndCollapse(i)
    }

    private fun refresh() {
        val t = qsTile ?: return
        val on = getSharedPreferences("fakegeo", MODE_PRIVATE).getBoolean("active", false)
        t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Fake GPS"
        t.updateTile()
    }
}
