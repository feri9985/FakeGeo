package dev.fakegeo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.usb.UsbDevice
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/** Foreground service that keeps the iPhone location session running while the app is in the background. */
class IosService : Service() {

    companion object {
        const val ACTION_START = "dev.fakegeo.IOS_START"
        const val ACTION_STOP = "dev.fakegeo.IOS_STOP"
        const val EXTRA_DEVICE = "device"
        private const val CHANNEL = "fakegeo_ios"
        private const val NOTIF_ID = 3
    }

    private val h = Handler(Looper.getMainLooper())
    private var wl: PowerManager.WakeLock? = null

    private val refresh = object : Runnable {
        override fun run() {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, build(IosState.status.ifEmpty { "Starting…" }))
            h.postDelayed(this, 3000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "iPhone location", NotificationManager.IMPORTANCE_LOW))
    }

    @Suppress("DEPRECATION")
    private fun build(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, IosService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("FakeGeo – iPhone location")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .build()
    }

    /** Android 14+ wants a declared type: "connected device" first, "location" as a fallback. */
    private fun goForeground(): Boolean {
        val n = build("Starting…")
        val types = if (Build.VERSION.SDK_INT >= 29)
            listOf(ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        else listOf(0)
        var err: Exception? = null
        for (t in types) {
            try {
                if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, t) else startForeground(NOTIF_ID, n)
                return true
            } catch (e: Exception) {
                err = e
            }
        }
        IosState.lastError = "Cannot run in the foreground: ${err?.message}"
        return false
    }

    private fun device(i: Intent?): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra(EXTRA_DEVICE, UsbDevice::class.java)
        else @Suppress("DEPRECATION") i?.getParcelableExtra(EXTRA_DEVICE)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            if (IosState.running) IosSession.stop() else stopSelf()
            return START_NOT_STICKY
        }
        if (!goForeground()) {
            IosState.status = IosState.lastError
            stopSelf()
            return START_NOT_STICKY
        }
        val dev = device(intent)
        if (dev == null) {
            IosState.status = "No iPhone was handed to the service."
            stopSelf()
            return START_NOT_STICKY
        }
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "fakegeo:ios").also { it.acquire(12 * 60 * 60 * 1000L) }
        IosFeed.active = true
        IosSession.start(applicationContext, dev) { h.post { stopSelf() } }
        h.removeCallbacks(refresh)
        h.post(refresh)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(refresh)
        IosSession.stop()
        try { wl?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
