package dev.fakegeo.app

/** وضعیت ساده‌ی مشترک بین سرویس و صفحه‌ی اصلی */
object MockState {
    @Volatile var running: Boolean = false
    @Volatile var error: String? = null
}
