package dev.fakegeo.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** وضعیت مشترک بین سرویس و صفحه‌ی اصلی */
object MockState {
    @Volatile var running: Boolean = false
    @Volatile var error: String? = null
    @Volatile var startedAt: Long = 0L   // SystemClock.elapsedRealtime()
    @Volatile var interruptions: Int = 0

    fun summary(now: Long): String {
        if (!running || startedAt == 0L) return ""
        val min = (now - startedAt) / 60000
        val up = if (min >= 60) "${min / 60} h ${min % 60} min" else "$min min"
        return "Uptime: $up  |  Interruptions: $interruptions"
    }

    private val events = ArrayList<String>()

    @Synchronized
    fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        events.add(0, "$t  $msg")
        while (events.size > 8) events.removeAt(events.size - 1)
    }

    @Synchronized
    fun recent(): List<String> = ArrayList(events)
}
