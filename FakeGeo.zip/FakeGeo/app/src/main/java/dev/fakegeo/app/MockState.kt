package dev.fakegeo.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** وضعیت مشترک بین سرویس و صفحه‌ی اصلی */
object MockState {
    @Volatile var running: Boolean = false
    @Volatile var error: String? = null

    private val events = ArrayList<String>()

    @Synchronized
    fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        events.add(0, "$t  $msg")
        while (events.size > 8) events.removeAt(events.size - 1)
    }

    @Synchronized
    fun recent(): List<String> = ArrayList(events)
}
