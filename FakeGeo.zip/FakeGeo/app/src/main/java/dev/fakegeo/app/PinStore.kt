package dev.fakegeo.app

import android.content.Context
import android.location.Location
import org.json.JSONArray
import org.json.JSONObject

data class Pin(val lat: Double, val lon: Double, val time: Long)

/** تاریخچه‌ی پین‌ها (جدیدترین اول). حداکثر ۵۰ مورد. */
object PinStore {
    private const val KEY = "history"

    private fun prefs(c: Context) = c.getSharedPreferences("fakegeo", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Pin> {
        val out = mutableListOf<Pin>()
        try {
            val arr = JSONArray(prefs(c).getString(KEY, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Pin(o.getDouble("lat"), o.getDouble("lon"), o.getLong("t")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun save(c: Context, list: List<Pin>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("lat", it.lat).put("lon", it.lon).put("t", it.time)) }
        prefs(c).edit().putString(KEY, arr.toString()).apply()
    }

    private fun dist(a: Pin, b: Pin): Float {
        val r = FloatArray(1)
        Location.distanceBetween(a.lat, a.lon, b.lat, b.lon, r)
        return r[0]
    }

    fun add(c: Context, pin: Pin) {
        val l = load(c)
        l.removeAll { dist(it, pin) < 5f } // پین تکراری (کمتر از ۵ متر) جایگزین می‌شه
        l.add(0, pin)
        while (l.size > 50) l.removeAt(l.size - 1)
        save(c, l)
    }

    fun remove(c: Context, index: Int) {
        val l = load(c)
        if (index in l.indices) {
            l.removeAt(index)
            save(c, l)
        }
    }

    fun clear(c: Context) = save(c, emptyList())
}
