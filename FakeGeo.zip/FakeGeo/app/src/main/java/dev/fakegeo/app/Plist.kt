package dev.fakegeo.app

import android.util.Base64
import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import javax.xml.parsers.DocumentBuilderFactory

/**
 * Minimal XML property-list reader/writer (what lockdownd speaks).
 * Types: String, Boolean, Int/Long, ByteArray (<data>), Map<String, Any?> (<dict>), List<Any?> (<array>).
 */
object Plist {

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    fun encode(root: Map<String, Any?>): ByteArray {
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
        sb.append("<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">")
        sb.append("<plist version=\"1.0\">")
        value(sb, root)
        sb.append("</plist>")
        return sb.toString().toByteArray(Charsets.UTF_8)
    }

    private fun value(sb: StringBuilder, v: Any?) {
        when (v) {
            is String -> sb.append("<string>").append(esc(v)).append("</string>")
            is Boolean -> sb.append(if (v) "<true/>" else "<false/>")
            is Int -> sb.append("<integer>").append(v).append("</integer>")
            is Long -> sb.append("<integer>").append(v).append("</integer>")
            is Double -> sb.append("<real>").append(v).append("</real>")
            is ByteArray -> sb.append("<data>").append(Base64.encodeToString(v, Base64.NO_WRAP)).append("</data>")
            is Map<*, *> -> {
                sb.append("<dict>")
                for ((k, x) in v) {
                    sb.append("<key>").append(esc(k.toString())).append("</key>")
                    value(sb, x)
                }
                sb.append("</dict>")
            }
            is List<*> -> {
                sb.append("<array>")
                for (x in v) value(sb, x)
                sb.append("</array>")
            }
            else -> sb.append("<string>").append(esc(v.toString())).append("</string>")
        }
    }

    @Suppress("UNCHECKED_CAST")
    fun decode(xml: ByteArray): Map<String, Any?> {
        // Drop the DOCTYPE so the parser never tries to fetch the external DTD.
        val text = String(xml, Charsets.UTF_8).replace(Regex("<!DOCTYPE[^>]*>"), "")
        val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
            .parse(ByteArrayInputStream(text.toByteArray(Charsets.UTF_8)))
        val root = doc.documentElement
        val first = children(root).firstOrNull() ?: return emptyMap()
        return (parse(first) as? Map<String, Any?>) ?: emptyMap()
    }

    private fun children(e: Element): List<Element> {
        val out = ArrayList<Element>()
        val n = e.childNodes
        for (i in 0 until n.length) (n.item(i) as? Element)?.let { out.add(it) }
        return out
    }

    private fun parse(e: Element): Any? = when (e.tagName) {
        "string", "date" -> e.textContent ?: ""
        "integer" -> e.textContent.trim().toLongOrNull() ?: 0L
        "real" -> e.textContent.trim().toDoubleOrNull() ?: 0.0
        "true" -> true
        "false" -> false
        "data" -> Base64.decode(e.textContent.trim(), Base64.DEFAULT)
        "array" -> children(e).map { parse(it) }
        "dict" -> {
            val m = LinkedHashMap<String, Any?>()
            val kids = children(e)
            var i = 0
            while (i + 1 < kids.size) {
                if (kids[i].tagName == "key") m[kids[i].textContent] = parse(kids[i + 1])
                i += 2
            }
            m
        }
        else -> null
    }
}
