package dev.fakegeo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import java.util.Random

/**
 * فیک GPS پایدار:
 *  - هر ثانیه مختصات جدید می‌فرسته (با نوسان طبیعی اختیاری)
 *  - اگه ارسال خطا بده، همون لحظه Provider رو دوباره می‌سازه و هشدار می‌ده
 *  - هر ۱ دقیقه وضعیت رو بررسی می‌کنه (اگه نقطه با پین فرق داشت: اصلاح + هشدار)
 *  - با وصل/قطع شارژ، روشن/خاموش شدن صفحه و تغییر Providerها فوراً نقطه رو دوباره تثبیت می‌کنه
 *  - WakeLock + سرویس Foreground برای جلوگیری از متوقف شدن
 */
class MockLocationService : Service() {

    companion object {
        const val ACTION_START = "dev.fakegeo.START"
        const val ACTION_STOP = "dev.fakegeo.STOP"
        private const val CHANNEL_ID = "fakegeo"
        private const val ALERT_CHANNEL = "fakegeo_alert"
        private const val NOTIF_ID = 1
        private const val ALERT_ID = 2
        private const val WATCHDOG_MS = 60_000L
    }

    private lateinit var lm: LocationManager
    private val handler = Handler(Looper.getMainLooper())
    private val rnd = Random()
    private val providers = arrayOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)

    private var lat = 0.0
    private var lon = 0.0
    private var baseAcc = 5f
    private var realism = true
    private var watchdogOn = true

    private var providersAdded = false
    private var receiverRegistered = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastReassert = 0L
    private var lastAlert = 0L

    // وضعیت نوسان طبیعی (متر نسبت به پین)
    private var ox = 0.0
    private var oy = 0.0
    private var alt = 12.0
    private var bearing = 0f

    private val tick = object : Runnable {
        override fun run() {
            if (!push()) {
                if (reassert()) {
                    push()
                    alert("اتصال قطع شد و دوباره به نقطه‌ی پین‌شده وصل شد ✅")
                }
            }
            handler.postDelayed(this, 1000)
        }
    }

    private val watchdog = object : Runnable {
        override fun run() {
            healthCheck()
            handler.postDelayed(this, WATCHDOG_MS)
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            MockState.log("رویداد سیستم: ${i?.action?.substringAfterLast('.')}")
            quickCheck()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Fake GPS", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(ALERT_CHANNEL, "هشدارها", NotificationManager.IMPORTANCE_HIGH).apply {
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400)
            }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences("fakegeo", MODE_PRIVATE)

        if (intent?.action == ACTION_STOP) {
            prefs.edit().putBoolean("active", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        // ری‌استارت خودکار توسط سیستم (intent خالی): فقط اگه قبلاً فعال بوده ادامه بده
        if (!prefs.getBoolean("active", false)) {
            stopSelf()
            return START_NOT_STICKY
        }

        lat = prefs.getString("pin_lat", "0")!!.toDoubleOrNull() ?: 0.0
        lon = prefs.getString("pin_lon", "0")!!.toDoubleOrNull() ?: 0.0
        baseAcc = prefs.getString("acc", "5")!!.toFloatOrNull() ?: 5f
        realism = prefs.getBoolean("realism", true)
        watchdogOn = prefs.getBoolean("watchdog", true)

        try {
            showForeground()
            acquireWakeLock()
            registerReceivers()
            setupProviders()
            MockState.error = null
            MockState.running = true
            MockState.log("فیک GPS شروع شد")
            handler.removeCallbacks(tick)
            handler.removeCallbacks(watchdog)
            handler.post(tick)
            if (watchdogOn) handler.postDelayed(watchdog, WATCHDOG_MS)
        } catch (e: SecurityException) {
            MockState.error = "FakeGeo به‌عنوان Mock location app انتخاب نشده.\n" +
                "تنظیمات ▸ گزینه‌های توسعه‌دهنده ▸ Select mock location app ▸ FakeGeo"
            MockState.running = false
            stopSelf()
        } catch (e: Exception) {
            MockState.error = "خطا: ${e.message}"
            MockState.running = false
            stopSelf()
        }
        return START_STICKY
    }

    // ---------------- Foreground / WakeLock / Receivers ----------------

    private fun openAppIntent() = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
    )

    private fun showForeground() {
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, MockLocationService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Stop", stopIntent
        ).build()
        val n = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Fake GPS فعاله")
            .setContentText(String.format(java.util.Locale.US, "%.5f , %.5f", lat, lon))
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(openAppIntent())
            .addAction(stopAction)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FakeGeo:mock").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun registerReceivers() {
        if (receiverRegistered) return
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction("android.location.PROVIDERS_CHANGED")
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, f)
        }
        receiverRegistered = true
    }

    // ---------------- Providers ----------------

    private fun setupProviders() {
        for (p in providers) {
            try { lm.removeTestProvider(p) } catch (_: Exception) {}
            lm.addTestProvider(
                p, false, false, false, false, true, true, true,
                Criteria.POWER_LOW, Criteria.ACCURACY_FINE
            )
            lm.setTestProviderEnabled(p, true)
        }
        providersAdded = true
    }

    /** ساخت دوباره‌ی Providerها (حداکثر هر ۱.۵ ثانیه یک‌بار) */
    private fun reassert(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (now - lastReassert < 1500) return true
        lastReassert = now
        return try {
            setupProviders()
            true
        } catch (e: SecurityException) {
            MockState.error = "FakeGeo دیگه Mock location app نیست! لوکیشن واقعی ممکنه لو بره."
            alert("⚠️ FakeGeo دیگه Mock location app نیست. فوراً دوباره انتخابش کن.")
            false
        } catch (e: Exception) {
            false
        }
    }

    /** با رویدادهای سیستم (شارژ، صفحه...) فوراً نقطه رو دوباره می‌فرسته */
    private fun quickCheck() {
        var needFix = false
        for (p in providers) {
            val enabled = try { lm.isProviderEnabled(p) } catch (_: Exception) { false }
            if (!enabled) needFix = true
        }
        if (needFix) {
            if (reassert()) alert("Provider غیرفعال شده بود و دوباره وصل شد ✅")
        }
        push()
    }

    @Suppress("DEPRECATION")
    private fun isMockLoc(l: Location): Boolean =
        if (Build.VERSION.SDK_INT >= 31) l.isMock else l.isFromMockProvider

    /** هر ۱ دقیقه: آیا واقعاً نقطه‌ی پین‌شده فعاله؟ */
    private fun healthCheck() {
        var problem: String? = null
        if (Build.VERSION.SDK_INT >= 28 && !lm.isLocationEnabled) {
            problem = "Location گوشی خاموش شده بود"
        } else {
            for (p in providers) {
                val l = try { lm.getLastKnownLocation(p) } catch (_: Exception) { null }
                if (l == null) { problem = "موقعیت $p خالی بود"; break }
                val d = FloatArray(1)
                Location.distanceBetween(lat, lon, l.latitude, l.longitude, d)
                if (!isMockLoc(l) || d[0] > 150f) {
                    problem = "موقعیت $p با پین فرق داشت (احتمال اتصال به لوکیشن واقعی)"
                    break
                }
            }
        }
        if (problem != null) {
            val ok = reassert()
            push()
            if (ok) alert("$problem؛ دوباره به نقطه‌ی پین‌شده وصل شد ✅")
        } else {
            MockState.log("بررسی ۱ دقیقه‌ای: همه‌چیز درسته")
        }
    }

    // ---------------- ارسال مختصات ----------------

    private fun position(): Pair<Double, Double> {
        if (!realism) return Pair(lat, lon)
        ox = (ox * 0.92 + rnd.nextGaussian() * 0.5).coerceIn(-5.0, 5.0)
        oy = (oy * 0.92 + rnd.nextGaussian() * 0.5).coerceIn(-5.0, 5.0)
        val dLat = oy / 111_320.0
        val dLon = ox / (111_320.0 * Math.cos(Math.toRadians(lat)))
        return Pair(lat + dLat, lon + dLon)
    }

    private fun push(): Boolean {
        val (la, lo) = position()
        if (realism) {
            alt = (alt + rnd.nextGaussian() * 0.05).coerceIn(10.0, 14.0)
            bearing = ((bearing + rnd.nextGaussian() * 15f + 360f) % 360f).toFloat()
        }
        val now = System.currentTimeMillis()
        var ok = true
        for (p in providers) {
            val gps = p == LocationManager.GPS_PROVIDER
            val loc = Location(p)
            loc.latitude = la
            loc.longitude = lo
            loc.altitude = alt
            loc.accuracy = if (gps) baseAcc + (if (realism) rnd.nextFloat() * 2f else 0f)
            else maxOf(baseAcc, 20f) + (if (realism) rnd.nextFloat() * 10f else 0f)
            loc.speed = if (realism) Math.abs(rnd.nextGaussian() * 0.08).toFloat() else 0f
            loc.bearing = if (realism) bearing else 0f
            loc.time = now
            loc.elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
            if (Build.VERSION.SDK_INT >= 26) {
                loc.verticalAccuracyMeters = 3f
                loc.speedAccuracyMetersPerSecond = 0.5f
                loc.bearingAccuracyDegrees = 10f
            }
            if (gps) {
                loc.extras = Bundle().apply { putInt("satellites", 8 + rnd.nextInt(5)) }
            }
            try {
                lm.setTestProviderLocation(p, loc)
            } catch (e: Exception) {
                ok = false
            }
        }
        return ok
    }

    // ---------------- هشدار ----------------

    private fun alert(msg: String) {
        MockState.log(msg)
        val now = SystemClock.elapsedRealtime()
        if (now - lastAlert < 30_000) return
        lastAlert = now
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val n = Notification.Builder(this, ALERT_CHANNEL)
            .setContentTitle("FakeGeo ⚠️")
            .setContentText(msg)
            .setStyle(Notification.BigTextStyle().bigText(msg))
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setCategory(Notification.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        nm.notify(ALERT_ID, n)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        handler.removeCallbacks(watchdog)
        if (receiverRegistered) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        if (providersAdded) {
            for (p in providers) {
                try { lm.setTestProviderEnabled(p, false) } catch (_: Exception) {}
                try { lm.removeTestProvider(p) } catch (_: Exception) {}
            }
        }
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
        MockState.running = false
        MockState.log("فیک GPS متوقف شد")
        super.onDestroy()
    }
}
