package dev.fakegeo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import java.util.Random

/**
 * Stable fake GPS:
 *  - sends a fresh location every second (optional natural drift)
 *  - if sending fails it rebuilds the providers immediately and raises an alarm
 *  - every 1 minute it verifies the active location matches the pin
 *  - reacts to charger / screen / provider changes by re-sending at once
 *  - kill switch: when the feed is lost it blocks the internet of the protected apps (local VPN blackhole)
 *    until the feed has been healthy again for a few seconds
 *  - WakeLock + foreground service so Android is less likely to stop it
 */
class MockLocationService : Service() {

    companion object {
        const val ACTION_START = "dev.fakegeo.START"
        const val ACTION_STOP = "dev.fakegeo.STOP"
        private const val CHANNEL_ID = "fakegeo"
        private const val ALERT_CHANNEL = "fakegeo_alert"
        private const val NOTIF_ID = 1
        private const val ALERT_ID = 2
        private const val WATCHDOG_MS = 60_000L
        private const val GOOD_TICKS_TO_UNBLOCK = 6
    }

    private lateinit var lm: LocationManager
    private val handler = Handler(Looper.getMainLooper())
    private val rnd = Random()
    private val core = arrayOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
    private var providers: List<String> = core.toList()

    private var lat = 0.0
    private var lon = 0.0
    private var baseAcc = 5f
    private var realism = true
    private var watchdogOn = true

    private var providersAdded = false
    private var receiverRegistered = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var ringtone: Ringtone? = null
    private var lastReassert = 0L
    private var lastAlert = 0L
    private var okStreak = 0
    private var lastBadAt = 0L
    private var warmup = 0

    // natural drift state (meters relative to the pin)
    private var ox = 0.0
    private var oy = 0.0
    private var alt = 12.0
    private var bearing = 0f

    private val tick = object : Runnable {
        override fun run() {
            if (push()) {
                onGood()
            } else if (reassert()) {
                if (push()) onBad("Feed dropped and was restored to the pin", true)
                else onBad("Feed dropped and could not be restored", true)
            } else {
                onBad("Feed lost: could not rebuild the mock providers", true)
            }
            // After start or after a problem: a short burst of 1-second updates, then the chosen interval
            val delay = if (warmup > 0) { warmup--; 1000L } else intervalMs()
            handler.postDelayed(this, delay)
        }
    }

    private val watchdog = object : Runnable {
        override fun run() {
            healthCheck()
            handler.postDelayed(this, WATCHDOG_MS)
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            MockState.log("System event: ${i?.action?.substringAfterLast('.')}")
            quickCheck()
        }
    }

    private fun prefs() = getSharedPreferences("fakegeo", MODE_PRIVATE)
    private fun ksEnabled() = prefs().getBoolean("ks_enabled", false)
    private fun soundEnabled() = prefs().getBoolean("ks_sound", true)

    /** Update interval: 1 s unless the user turned on the custom interval (Protect tab). */
    private fun intervalMs(): Long {
        val p = prefs()
        if (!p.getBoolean("iv_enabled", false)) return 1000L
        return p.getInt("iv_sec", 10).coerceIn(1, 120) * 1000L
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Fake GPS", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(ALERT_CHANNEL, "Alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400)
            }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val p = prefs()

        if (intent?.action == ACTION_STOP) {
            p.edit().putBoolean("active", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        // Restart by the system (null intent): continue only if it was active before
        if (!p.getBoolean("active", false)) {
            stopSelf()
            return START_NOT_STICKY
        }

        lat = p.getString("pin_lat", "0")!!.toDoubleOrNull() ?: 0.0
        lon = p.getString("pin_lon", "0")!!.toDoubleOrNull() ?: 0.0
        baseAcc = p.getString("acc", "5")!!.toFloatOrNull() ?: 5f
        realism = p.getBoolean("realism", true)
        watchdogOn = p.getBoolean("watchdog", true)
        okStreak = 0
        lastBadAt = SystemClock.elapsedRealtime()
        warmup = GOOD_TICKS_TO_UNBLOCK

        try {
            showForeground()
            acquireWakeLock()
            registerReceivers()
            if (ksEnabled()) KillSwitch.block(this) // protect the apps while we start
            setupProviders()
            MockState.error = null
            MockState.running = true
            MockState.log("Fake GPS started")
            handler.removeCallbacks(tick)
            handler.removeCallbacks(watchdog)
            handler.post(tick)
            if (watchdogOn) handler.postDelayed(watchdog, WATCHDOG_MS)
        } catch (e: SecurityException) {
            MockState.error = "FakeGeo is not selected as the mock location app.\n" +
                "Settings > Developer options > Select mock location app > FakeGeo"
            failStart()
        } catch (e: Exception) {
            MockState.error = "Error: ${e.message}"
            failStart()
        }
        return START_STICKY
    }

    private fun failStart() {
        prefs().edit().putBoolean("active", false).apply()
        MockState.running = false
        if (KillSwitch.blocking) KillSwitch.unblock(this)
        stopSelf()
    }

    // ---------------- Foreground / WakeLock / Receivers ----------------

    private fun openAppIntent() = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
    )

    private fun showForeground() {
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, MockLocationService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Stop", stopIntent
        ).build()
        val n = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Fake GPS is active")
            .setContentText(String.format(java.util.Locale.US, "%.5f , %.5f", lat, lon))
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(openAppIntent())
            .addAction(stopAction)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FakeGeo:mock").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun registerReceivers() {
        if (receiverRegistered) return
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction("android.location.PROVIDERS_CHANGED")
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, f)
        }
        receiverRegistered = true
    }

    // ---------------- Providers ----------------

    private fun addOne(p: String) {
        try { lm.removeTestProvider(p) } catch (_: Exception) {}
        lm.addTestProvider(
            p, false, false, false, false, true, true, true,
            Criteria.POWER_LOW, Criteria.ACCURACY_FINE
        )
        lm.setTestProviderEnabled(p, true)
    }

    /** Experimental provider mode (Protect tab): 0 = GPS+Network+Fused, 1 = GPS+Network, 2 = GPS only. */
    private fun provMode() = prefs().getInt("prov_mode", 0)

    private fun activeCore(): List<String> =
        if (provMode() == 2) listOf(LocationManager.GPS_PROVIDER) else core.toList()

    private fun setupProviders() {
        val act = activeCore()
        for (p in act) addOne(p)
        val list = act.toMutableList()
        if (Build.VERSION.SDK_INT >= 31 && provMode() == 0) {
            // Android 12+: also mock the platform "fused" provider (apps that ask for it directly)
            try {
                addOne(LocationManager.FUSED_PROVIDER)
                list.add(LocationManager.FUSED_PROVIDER)
            } catch (_: Exception) {
            }
        }
        providers = list
        providersAdded = true
    }

    /** Rebuild the providers (at most once every 1.5 s). */
    private fun reassert(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (now - lastReassert < 1500) return true
        lastReassert = now
        return try {
            setupProviders()
            true
        } catch (e: SecurityException) {
            MockState.error = "FakeGeo is no longer the mock location app! Your real location may be exposed."
            false
        } catch (e: Exception) {
            false
        }
    }

    private fun quickCheck() {
        var needFix = false
        for (p in activeCore()) {
            val enabled = try { lm.isProviderEnabled(p) } catch (_: Exception) { false }
            if (!enabled) needFix = true
        }
        if (needFix) {
            if (reassert()) onBad("A location provider was disabled and has been restored", true)
            else onBad("A location provider was disabled and could not be restored", true)
        }
        push()
    }

    @Suppress("DEPRECATION")
    private fun isMockLoc(l: Location): Boolean =
        if (Build.VERSION.SDK_INT >= 31) l.isMock else l.isFromMockProvider

    /** Every 1 minute: is the pinned location really the active one? */
    private fun healthCheck() {
        var problem: String? = null
        if (Build.VERSION.SDK_INT >= 28 && !lm.isLocationEnabled) {
            problem = "Device location was turned off"
        } else {
            for (p in core) {
                val l = try { lm.getLastKnownLocation(p) } catch (_: Exception) { null }
                if (l == null) { problem = "Provider $p had no location"; break }
                val d = FloatArray(1)
                Location.distanceBetween(lat, lon, l.latitude, l.longitude, d)
                if (!isMockLoc(l) || d[0] > 150f) {
                    problem = "Provider $p did not match the pin (possible real location)"
                    break
                }
            }
        }
        if (problem != null) {
            reassert()
            push()
            onBad(problem, true)
        } else {
            MockState.log("1-minute check: all good")
        }
    }

    // ---------------- Sending ----------------

    private fun position(): Pair<Double, Double> {
        if (!realism) return Pair(lat, lon)
        ox = (ox * 0.92 + rnd.nextGaussian() * 0.5).coerceIn(-5.0, 5.0)
        oy = (oy * 0.92 + rnd.nextGaussian() * 0.5).coerceIn(-5.0, 5.0)
        val dLat = oy / 111_320.0
        val dLon = ox / (111_320.0 * Math.cos(Math.toRadians(lat)))
        return Pair(lat + dLat, lon + dLon)
    }

    private fun push(): Boolean {
        val (la, lo) = position()
        if (realism) {
            alt = (alt + rnd.nextGaussian() * 0.05).coerceIn(10.0, 14.0)
            bearing = ((bearing + rnd.nextGaussian() * 15f + 360f) % 360f).toFloat()
        }
        val now = System.currentTimeMillis()
        var ok = true
        for (p in providers) {
            val gps = p == LocationManager.GPS_PROVIDER
            val loc = Location(p)
            loc.latitude = la
            loc.longitude = lo
            loc.altitude = alt
            loc.accuracy = if (gps) baseAcc + (if (realism) rnd.nextFloat() * 2f else 0f)
            else maxOf(baseAcc, 20f) + (if (realism) rnd.nextFloat() * 10f else 0f)
            loc.speed = if (realism) Math.abs(rnd.nextGaussian() * 0.08).toFloat() else 0f
            loc.bearing = if (realism) bearing else 0f
            loc.time = now
            loc.elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
            if (Build.VERSION.SDK_INT >= 26) {
                loc.verticalAccuracyMeters = 3f
                loc.speedAccuracyMetersPerSecond = 0.5f
                loc.bearingAccuracyDegrees = 10f
            }
            if (gps) {
                loc.extras = Bundle().apply { putInt("satellites", 8 + rnd.nextInt(5)) }
            }
            try {
                lm.setTestProviderLocation(p, loc)
            } catch (e: Exception) {
                // the optional "fused" provider must not make the whole feed look broken
                if (p != LocationManager.FUSED_PROVIDER) ok = false
            }
        }
        return ok
    }

    // ---------------- Good / bad state + kill switch ----------------

    private fun onGood() {
        okStreak++
        if (KillSwitch.blocking && okStreak >= 2 &&
            SystemClock.elapsedRealtime() - lastBadAt >= 6000
        ) {
            KillSwitch.unblock(this)
        }
    }

    private fun onBad(reason: String, critical: Boolean) {
        okStreak = 0
        lastBadAt = SystemClock.elapsedRealtime()
        warmup = GOOD_TICKS_TO_UNBLOCK
        if (ksEnabled() && !KillSwitch.blocking) KillSwitch.block(this)
        alert(
            reason + if (ksEnabled()) ". Kill switch engaged." else ".",
            critical
        )
    }

    // ---------------- Alerts ----------------

    private fun soundAlarm() {
        if (!soundEnabled()) return
        try {
            if (ringtone?.isPlaying == true) return
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val r = RingtoneManager.getRingtone(applicationContext, uri)
            r.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            r.play()
            ringtone = r
            handler.postDelayed({ try { r.stop() } catch (_: Exception) {} }, 8000)
        } catch (_: Exception) {
        }
    }

    private fun alert(msg: String, critical: Boolean = false) {
        MockState.log(msg)
        if (critical) soundAlarm()
        val now = SystemClock.elapsedRealtime()
        if (now - lastAlert < 30_000) return
        lastAlert = now
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val n = Notification.Builder(this, ALERT_CHANNEL)
            .setContentTitle("FakeGeo ⚠️")
            .setContentText(msg)
            .setStyle(Notification.BigTextStyle().bigText(msg))
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setCategory(Notification.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        nm.notify(ALERT_ID, n)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        handler.removeCallbacks(watchdog)
        val userStopped = !prefs().getBoolean("active", false)
        if (receiverRegistered) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        if (providersAdded) {
            for (p in providers) {
                try { lm.setTestProviderEnabled(p, false) } catch (_: Exception) {}
                try { lm.removeTestProvider(p) } catch (_: Exception) {}
            }
        }
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
        MockState.running = false

        if (userStopped) {
            // Deliberate stop: lift the block
            if (KillSwitch.blocking) KillSwitch.unblock(this)
            MockState.log("Fake GPS stopped")
        } else {
            // Stopped by the system while it should have been running
            if (ksEnabled()) KillSwitch.block(this)
            alert("Fake GPS was stopped by the system! Real location may be exposed.", true)
        }
        super.onDestroy()
    }
}
