package dev.fakegeo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import java.util.Random

/**
 * هر ثانیه یک مختصات جعلی به GPS_PROVIDER و NETWORK_PROVIDER می‌فرسته.
 * شرط کار کردن: اپ باید در Developer options به‌عنوان "Mock location app" انتخاب شده باشه.
 */
class MockLocationService : Service() {

    companion object {
        const val ACTION_START = "dev.fakegeo.START"
        const val ACTION_STOP = "dev.fakegeo.STOP"
        const val EXTRA_LAT = "lat"
        const val EXTRA_LON = "lon"
        const val EXTRA_ACC = "acc"
        const val EXTRA_JITTER = "jitter"
        private const val CHANNEL_ID = "fakegeo"
        private const val NOTIF_ID = 1
    }

    private lateinit var lm: LocationManager
    private val handler = Handler(Looper.getMainLooper())
    private val rnd = Random()
    private val providers = arrayOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)

    private var lat = 0.0
    private var lon = 0.0
    private var acc = 5f
    private var jitter = false
    private var providersAdded = false

    private val tick = object : Runnable {
        override fun run() {
            push()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        lat = intent.getDoubleExtra(EXTRA_LAT, 0.0)
        lon = intent.getDoubleExtra(EXTRA_LON, 0.0)
        acc = intent.getFloatExtra(EXTRA_ACC, 5f)
        jitter = intent.getBooleanExtra(EXTRA_JITTER, false)

        try {
            showForeground()
            setupProviders()
            MockState.error = null
            MockState.running = true
            handler.removeCallbacks(tick)
            handler.post(tick)
        } catch (e: SecurityException) {
            MockState.error = "FakeGeo به‌عنوان Mock location app انتخاب نشده.\n" +
                "تنظیمات ▸ گزینه‌های توسعه‌دهنده ▸ Select mock location app ▸ FakeGeo"
            MockState.running = false
            stopSelf()
        } catch (e: Exception) {
            MockState.error = "خطا: ${e.message}"
            MockState.running = false
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun showForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Fake GPS", NotificationManager.IMPORTANCE_LOW)
        )
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, MockLocationService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Stop", stopIntent
        ).build()
        val n = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Fake GPS فعاله")
            .setContentText("%.5f , %.5f".format(lat, lon))
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(openIntent)
            .addAction(stopAction)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun setupProviders() {
        for (p in providers) {
            try { lm.removeTestProvider(p) } catch (_: Exception) {}
            lm.addTestProvider(
                p, false, false, false, false, true, true, true,
                Criteria.POWER_LOW, Criteria.ACCURACY_FINE
            )
            lm.setTestProviderEnabled(p, true)
        }
        providersAdded = true
    }

    private fun j(): Double = if (jitter) (rnd.nextDouble() - 0.5) * 0.00002 else 0.0 // حدود ±1 متر

    private fun push() {
        val now = System.currentTimeMillis()
        for (p in providers) {
            val loc = Location(p)
            loc.latitude = lat + j()
            loc.longitude = lon + j()
            loc.altitude = 10.0
            loc.accuracy = acc
            loc.speed = 0f
            loc.bearing = 0f
            loc.time = now
            loc.elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
            if (Build.VERSION.SDK_INT >= 26) {
                loc.verticalAccuracyMeters = acc
                loc.speedAccuracyMetersPerSecond = 0.5f
                loc.bearingAccuracyDegrees = 1f
            }
            try { lm.setTestProviderLocation(p, loc) } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        if (providersAdded) {
            for (p in providers) {
                try { lm.setTestProviderEnabled(p, false) } catch (_: Exception) {}
                try { lm.removeTestProvider(p) } catch (_: Exception) {}
            }
        }
        MockState.running = false
        super.onDestroy()
    }
}
