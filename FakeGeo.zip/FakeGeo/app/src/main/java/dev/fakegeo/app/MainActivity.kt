package dev.fakegeo.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.hardware.usb.UsbDevice
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonSource
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var mapView: MapView
    private var maplibre: MapLibreMap? = null
    private var style: Style? = null
    private var layerIdx = 0
    private var savedBundle: Bundle? = null

    private var pinLat: Double? = null
    private var pinLon: Double? = null
    private var pinName: String? = null

    private lateinit var tvCoords: TextView
    private lateinit var etSearch: EditText
    private lateinit var suggestBox: LinearLayout
    private lateinit var swRealism: Switch
    private lateinit var swWatch: Switch
    private lateinit var swKill: Switch
    private lateinit var swSound: Switch
    private lateinit var tvKsApps: TextView
    private val REQ_VPN = 77
    private val REQ_DDI = 78
    private lateinit var tvStatus: TextView
    private lateinit var tvEvents: TextView
    private lateinit var historyBox: LinearLayout
    private lateinit var tvIpInfo: TextView
    private lateinit var tvIpCompare: TextView
    private lateinit var tvCheck: TextView

    private val tabs = mutableListOf<View>()
    private val tabButtons = mutableListOf<Button>()
    private var ipLoaded = false
    private val ui = Handler(Looper.getMainLooper())

    private var suppressWatch = false
    private var searchGen = 0
    private var suggestRunnable: Runnable = Runnable {}

    private val refresh = object : Runnable {
        override fun run() {
            updateStatus()
            ui.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- design system (dark) ----------
    private val BG = Color.parseColor("#0B1020")
    private val SURFACE = Color.parseColor("#151B2E")
    private val SURFACE2 = Color.parseColor("#1E2742")
    private val STROKE = Color.parseColor("#2A3556")
    private val ACCENT = Color.parseColor("#3B82F6")
    private val TEXT = Color.parseColor("#E5E7EB")
    private val MUTED = Color.parseColor("#94A3B8")
    private val DANGER = Color.parseColor("#EF4444")
    private val SUCCESS = Color.parseColor("#22C55E")
    private val AMBER = Color.parseColor("#F59E0B")

    private fun rounded(color: Int, r: Int = 14, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun label(s: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = if (size >= 18f && size < 20f) 17f else size
        val heading = size >= 18f && bold
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setTextColor(if (heading) Color.WHITE else if (size <= 13f) MUTED else TEXT)
        if (heading) tag = "h"
        setPadding(0, dp(8), 0, dp(4))
    }

    /** kind: 0 = primary (blue), 1 = ghost, 2 = danger (red), 3 = success (green) */
    private fun btn(s: String, kind: Int = 0, onClick: () -> Unit) = Button(this).apply {
        text = s
        isAllCaps = false
        textSize = 14f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(if (kind == 1) TEXT else Color.WHITE)
        val bg = when (kind) {
            1 -> rounded(SURFACE2, 14, STROKE)
            2 -> rounded(DANGER)
            3 -> rounded(SUCCESS)
            else -> rounded(ACCENT)
        }
        background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), bg, null)
        stateListAnimator = null
        minHeight = dp(46)
        minimumHeight = dp(46)
        setPadding(dp(16), dp(10), dp(16), dp(10))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, dp(8), 0, 0) }
        setOnClickListener { onClick() }
    }

    private fun styleSwitch(sw: Switch) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Color.parseColor("#94A3B8")))
        sw.trackTintList = ColorStateList(states, intArrayOf(ACCENT, Color.parseColor("#334155")))
        sw.setTextColor(TEXT)
        sw.textSize = 14f
        sw.setPadding(0, dp(10), 0, dp(10))
    }

    /** Group each tab's content into rounded cards, one per heading. */
    private fun cardify(c: LinearLayout) {
        val kids = ArrayList<View>()
        for (i in 0 until c.childCount) kids.add(c.getChildAt(i))
        c.removeAllViews()
        var card: LinearLayout? = null
        for (v in kids) {
            if (v.tag == "h") {
                val cd = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = rounded(SURFACE, 18, STROKE)
                    setPadding(dp(16), dp(8), dp(16), dp(16))
                }
                c.addView(cd, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, dp(16), 0, 0) })
                cd.addView(v)
                card = cd
            } else if (card != null) {
                card.addView(v)
            } else {
                c.addView(v)
            }
        }
    }

    private fun vbox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    // ======================= onCreate =======================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        savedBundle = savedInstanceState
        prefs = getSharedPreferences("fakegeo", MODE_PRIVATE)
        MapLibre.getInstance(applicationContext)
        // Launcher shortcuts
        when (intent?.action) {
            "dev.fakegeo.HOME" -> {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    val hl = prefs.getString("home_lat", null)?.toDoubleOrNull() ?: 25.2048
                    val ho = prefs.getString("home_lon", null)?.toDoubleOrNull() ?: 55.2708
                    prefs.edit().putString("pin_lat", hl.toString()).putString("pin_lon", ho.toString())
                        .putBoolean("active", true).apply()
                    startForegroundService(
                        Intent(this, MockLocationService::class.java).setAction(MockLocationService.ACTION_START)
                    )
                }
            }
            "dev.fakegeo.STOP_ALL" -> {
                prefs.edit().putBoolean("active", false).apply()
                stopService(Intent(this, MockLocationService::class.java))
                MockState.running = false
            }
        }
        // Tapped the "phone restarted" notification: resume the saved pin
        if (intent?.getBooleanExtra("resume", false) == true &&
            prefs.getBoolean("active", false) && prefs.getString("pin_lat", null) != null
        ) {
            startForegroundService(
                Intent(this, MockLocationService::class.java).setAction(MockLocationService.ACTION_START)
            )
        }

        val rootFrame = FrameLayout(this).apply {
            setBackgroundColor(BG)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        setContentView(rootFrame)
        buildMapScreen(rootFrame)
        buildPages(rootFrame)
        listOf(swRealism, swWatch, swKill, swSound).forEach { styleSwitch(it) }

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    private fun showTab(i: Int) {
        tabs.forEachIndexed { idx, v -> v.visibility = if (idx == i) View.VISIBLE else View.GONE }
        tabButtons.forEachIndexed { idx, b ->
            if (idx == i) {
                b.background = rounded(ACCENT, 12)
                b.setTextColor(Color.WHITE)
            } else {
                b.setBackgroundColor(Color.TRANSPARENT)
                b.setTextColor(MUTED)
            }
        }
        prefs.edit().putInt("tab", i).apply()
        if (i == 1 && !ipLoaded) fetchIp()
    }

    // ======================= Map =======================

    private fun fab(iconRes: Int, onClick: (View) -> Unit) = ImageButton(this).apply {
        setImageResource(iconRes)
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.WHITE)
            setStroke(dp(1), Color.parseColor("#22000000"))
        }
        elevation = dp(4).toFloat()
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setOnClickListener { onClick(it) }
    }

    /** Raster style from Esri (used for Satellite / Hybrid / Terrain / Dark). */
    private fun rasterStyle(base: String, baseMax: Int, labels: String?, labelsMax: Int): String {
        fun src(path: String, max: Int) =
            "{\"type\":\"raster\",\"tiles\":[\"https://server.arcgisonline.com/ArcGIS/rest/services/" +
                path + "/MapServer/tile/{z}/{y}/{x}\"],\"tileSize\":256,\"maxzoom\":" + max +
                ",\"attribution\":\"Tiles © Esri\"}"
        val sources = StringBuilder("\"base\":" + src(base, baseMax))
        val layers = StringBuilder("{\"id\":\"base\",\"type\":\"raster\",\"source\":\"base\"}")
        if (labels != null) {
            sources.append(",\"labels\":").append(src(labels, labelsMax))
            layers.append(",{\"id\":\"labels\",\"type\":\"raster\",\"source\":\"labels\"}")
        }
        return "{\"version\":8,\"sources\":{" + sources + "},\"layers\":[" + layers + "]}"
    }

    private fun styleBuilder(i: Int): Style.Builder = when (i) {
        1 -> Style.Builder().fromUri("https://tiles.openfreemap.org/styles/positron")
        2 -> Style.Builder().fromJson(rasterStyle("World_Imagery", 19, "Reference/World_Boundaries_and_Places", 19))
        3 -> Style.Builder().fromJson(rasterStyle("World_Imagery", 19, null, 19))
        4 -> Style.Builder().fromJson(rasterStyle("World_Topo_Map", 19, null, 19))
        5 -> Style.Builder().fromJson(
            rasterStyle("Canvas/World_Dark_Gray_Base", 16, "Canvas/World_Dark_Gray_Reference", 16)
        )
        else -> Style.Builder().fromUri("https://tiles.openfreemap.org/styles/liberty")
    }

    private fun applyLayer(i: Int) {
        layerIdx = i
        prefs.edit().putInt("layer", i).apply()
        val m = maplibre ?: return
        style = null
        m.setStyle(styleBuilder(i)) { st ->
            style = st
            setupStyle(st, i == 0 || i == 1)
        }
    }

    private fun setupStyle(st: Style, vector: Boolean) {
        try {
            st.addImage("pin", getDrawable(R.drawable.ic_pin)!!)
            st.addImage("dot", getDrawable(R.drawable.ic_dot)!!)
            st.addSource(GeoJsonSource("route-src"))
            st.addLayer(
                LineLayer("route-layer", "route-src").withProperties(
                    PropertyFactory.lineColor(Color.parseColor("#3B82F6")),
                    PropertyFactory.lineWidth(5f),
                    PropertyFactory.lineOpacity(0.85f),
                    PropertyFactory.lineCap(Property.LINE_CAP_ROUND),
                    PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND)
                )
            )
            st.addSource(GeoJsonSource("pin-src"))
            st.addSource(GeoJsonSource("dot-src"))
            st.addLayer(
                SymbolLayer("pin-layer", "pin-src").withProperties(
                    PropertyFactory.iconImage("pin"),
                    PropertyFactory.iconAnchor(Property.ICON_ANCHOR_BOTTOM),
                    PropertyFactory.iconAllowOverlap(true),
                    PropertyFactory.iconIgnorePlacement(true)
                )
            )
            st.addLayer(
                SymbolLayer("dot-layer", "dot-src").withProperties(
                    PropertyFactory.iconImage("dot"),
                    PropertyFactory.iconAnchor(Property.ICON_ANCHOR_CENTER),
                    PropertyFactory.iconAllowOverlap(true),
                    PropertyFactory.iconIgnorePlacement(true)
                )
            )
        } catch (e: Exception) {
            toast("Map markers failed: ${e.message}")
        }
        if (vector) englishLabels(st)
        renderMarkers()
        renderRoute()
    }

    /** Prefer English (name:en / Latin) for place labels on vector maps. */
    private fun englishLabels(st: Style) {
        try {
            val expr = Expression.coalesce(
                Expression.get("name:en"), Expression.get("name:latin"), Expression.get("name")
            )
            for (l in st.layers) {
                if (l is SymbolLayer && (l.id.startsWith("label") || l.id.startsWith("poi") || l.id.contains("name"))) {
                    l.setProperties(PropertyFactory.textField(expr))
                }
            }
        } catch (_: Throwable) {
        }
    }

    private val emptyJson = "{\"type\":\"FeatureCollection\",\"features\":[]}"

    private fun pointJson(lat: Double, lon: Double) =
        String.format(Locale.US, "{\"type\":\"Point\",\"coordinates\":[%.7f,%.7f]}", lon, lat)

    private fun activePoint(): Pair<Double, Double>? {
        if (!MockState.running) return null
        val ml = Motion.curLat
        val mo = Motion.curLon
        if (ml != null && mo != null) return Pair(ml, mo)
        val la = prefs.getString("pin_lat", null)?.toDoubleOrNull()
        val lo = prefs.getString("pin_lon", null)?.toDoubleOrNull()
        return if (la != null && lo != null) Pair(la, lo) else null
    }

    private var lastDotKey = "?"

    /** Red pin = selected point. Blue dot = where fake GPS is active right now. */
    private fun renderMarkers() {
        val st = style ?: return
        try {
            val pin: GeoJsonSource? = st.getSourceAs("pin-src")
            val la = pinLat
            val lo = pinLon
            pin?.setGeoJson(if (la != null && lo != null) pointJson(la, lo) else emptyJson)
            val dot: GeoJsonSource? = st.getSourceAs("dot-src")
            val a = activePoint()
            dot?.setGeoJson(if (a != null) pointJson(a.first, a.second) else emptyJson)
        } catch (_: Exception) {
        }
    }

    private fun updateDot() {
        val a = activePoint()
        val key = if (a != null) "${a.first},${a.second}" else ""
        if (key != lastDotKey) {
            lastDotKey = key
            renderMarkers()
        }
    }

    private fun onMapTap(ll: LatLng) {
        var lat = ll.latitude
        var lon = ll.longitude
        var name: String? = null
        val m = maplibre
        if (m != null) {
            try {
                // If the tap is on a named place (POI), snap to that place.
                val pt = m.projection.toScreenLocation(ll)
                val r = dp(22).toFloat()
                val feats = m.queryRenderedFeatures(RectF(pt.x - r, pt.y - r, pt.x + r, pt.y + r))
                for (f in feats) {
                    val n = when {
                        f.hasProperty("name:en") -> f.getStringProperty("name:en")
                        f.hasProperty("name") -> f.getStringProperty("name")
                        else -> null
                    }
                    val gj = f.geometry()?.toJson()?.let { JSONObject(it) }
                    if (!n.isNullOrBlank() && gj != null && gj.optString("type") == "Point") {
                        val co = gj.getJSONArray("coordinates")
                        lon = co.getDouble(0)
                        lat = co.getDouble(1)
                        name = n
                        break
                    }
                }
            } catch (_: Exception) {
            }
        }
        setPin(lat, lon, false, name, 0.0)
    }

    // ======================= Map-first UI =======================

    private lateinit var pagesLayer: LinearLayout
    private lateinit var pageTitle: TextView
    private lateinit var pageHost: LinearLayout
    private lateinit var pageScroll: ScrollView
    private val pageViews = LinkedHashMap<String, LinearLayout>()
    private var openPage: String? = null
    private var pageParent: String? = null

    private lateinit var pinCard: LinearLayout
    private lateinit var tvPinCoord: TextView
    private lateinit var tvPinDist: TextView
    private lateinit var pill: LinearLayout
    private lateinit var tvPill: TextView
    private lateinit var multiBar: LinearLayout
    private lateinit var tvMulti: TextView
    private var multiMode = false

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun fabEmoji(e: String, onClick: () -> Unit) = TextView(this).apply {
        text = e
        textSize = 20f
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(SURFACE)
            setStroke(dp(1), STROKE)
        }
        elevation = dp(4).toFloat()
        setOnClickListener { onClick() }
    }

    private fun stopAll() {
        prefs.edit().putBoolean("active", false).apply()
        stopService(Intent(this, MockLocationService::class.java))
        MockState.running = false
        Motion.stop()
    }

    private fun buildMapScreen(root: FrameLayout) {
        mapView = MapView(this)
        mapView.onCreate(savedBundle)
        root.addView(mapView, FrameLayout.LayoutParams(MATCH, MATCH))
        tvCoords = label("No pin yet", 15f, true)

        // ---- search + suggestions ----
        etSearch = EditText(this).apply {
            hint = "Search place (e.g. Burj Khalifa)"
            setHintTextColor(MUTED)
            setTextColor(TEXT)
            background = rounded(SURFACE2, 14, STROKE)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            inputType = InputType.TYPE_CLASS_TEXT
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_SEARCH) {
                    doSearch()
                    true
                } else false
            }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {}
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                    if (suppressWatch) return
                    ui.removeCallbacks(suggestRunnable)
                    val q = s?.toString()?.trim().orEmpty()
                    if (q.length < 3) {
                        searchGen++
                        suggestBox.removeAllViews()
                        return
                    }
                    suggestRunnable = Runnable { loadSuggestions(q) }
                    ui.postDelayed(suggestRunnable, 400)
                }
            })
        }

        val top = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(etSearch)
        val profileBtn = fabEmoji("👤") { showPage("profile", null) }
        profileBtn.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(ACCENT)
        }
        row.addView(profileBtn, LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(dp(8), 0, 0, 0) })
        top.addView(row)
        suggestBox = vbox()
        top.addView(suggestBox)

        pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(SURFACE, 22, SUCCESS)
            setPadding(dp(14), dp(6), dp(6), dp(6))
            visibility = View.GONE
        }
        tvPill = TextView(this).apply {
            textSize = 12f
            setTextColor(TEXT)
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        val stopB = Button(this).apply {
            text = "Stop"
            isAllCaps = false
            textSize = 12f
            setTextColor(Color.WHITE)
            background = rounded(DANGER, 16)
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(14), dp(4), dp(14), dp(4))
            setOnClickListener { stopAll() }
        }
        pill.addView(tvPill)
        pill.addView(stopB, LinearLayout.LayoutParams(WRAP, dp(34)))
        top.addView(pill, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, dp(8), 0, 0) })
        root.addView(top, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP).apply { setMargins(dp(12), dp(10), dp(12), 0) })

        // right column: layers, my location, joystick
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val fl = fab(R.drawable.ic_layers) { anchor ->
            PopupMenu(this, anchor).apply {
                menu.add(0, 0, 0, "Street")
                menu.add(0, 1, 1, "Light")
                menu.add(0, 2, 2, "Hybrid")
                menu.add(0, 3, 3, "Satellite")
                menu.add(0, 4, 4, "Terrain")
                menu.add(0, 5, 5, "Dark")
                setOnMenuItemClickListener { applyLayer(it.itemId); true }
                show()
            }
        }
        right.addView(fl, LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(0, dp(8), 0, 0) })
        right.addView(fab(R.drawable.ic_my_location) { recenter() },
            LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(0, dp(8), 0, 0) })
        right.addView(fabEmoji("🕹") { showJoystick() },
            LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(0, dp(8), 0, 0) })
        right.addView(iosFab(),
            LinearLayout.LayoutParams(dp(46), dp(50)).apply { setMargins(0, dp(8), 0, 0) })
        root.addView(right, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.RIGHT or Gravity.CENTER_VERTICAL).apply {
            setMargins(0, 0, dp(10), 0)
        })

        // left column: favorites, history, route
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(fabEmoji("⭐") { showPage("favorites", null) },
            LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(0, dp(8), 0, 0) })
        left.addView(fabEmoji("🕘") { showPage("history", null) },
            LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(0, dp(8), 0, 0) })
        left.addView(fabEmoji("🧭") { showPage("route", null) },
            LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(0, dp(8), 0, 0) })
        root.addView(left, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.LEFT or Gravity.CENTER_VERTICAL).apply {
            setMargins(dp(10), 0, 0, 0)
        })

        // bottom: multi-point bar + pin card
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        multiBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(SURFACE, 18, STROKE)
            setPadding(dp(14), dp(8), dp(8), dp(8))
            visibility = View.GONE
        }
        tvMulti = TextView(this).apply {
            textSize = 13f
            setTextColor(TEXT)
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        val bGo = Button(this).apply {
            text = "Go"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(SUCCESS, 14)
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { multiGo() }
        }
        val bClr = Button(this).apply {
            text = "Clear"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(DANGER, 14)
            minHeight = 0
            minimumHeight = 0
            setOnClickListener {
                wps.clear()
                multiMode = false
                refreshWps()
                updateMultiBar()
            }
        }
        multiBar.addView(tvMulti)
        multiBar.addView(bGo, LinearLayout.LayoutParams(WRAP, dp(40)).apply { setMargins(dp(4), 0, dp(4), 0) })
        multiBar.addView(bClr, LinearLayout.LayoutParams(WRAP, dp(40)))
        bottom.addView(multiBar, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, 0, 0, dp(8)) })

        pinCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(SURFACE, 20, STROKE)
            setPadding(dp(16), dp(10), dp(16), dp(14))
            visibility = View.GONE
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(TextView(this).apply {
            text = "☆"
            textSize = 24f
            setTextColor(AMBER)
            setPadding(0, 0, dp(12), 0)
            setOnClickListener { saveFavDialog() }
        })
        head.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        head.addView(TextView(this).apply {
            text = "✕"
            textSize = 20f
            setTextColor(MUTED)
            setPadding(dp(12), 0, 0, 0)
            setOnClickListener { pinCard.visibility = View.GONE }
        })
        pinCard.addView(head)
        fun kv(name: String): TextView {
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(4), 0, dp(4))
            }
            r.addView(TextView(this).apply {
                text = name
                textSize = 15f
                setTextColor(MUTED)
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            })
            val v = TextView(this).apply {
                textSize = 15f
                setTextColor(TEXT)
                gravity = Gravity.RIGHT
            }
            r.addView(v)
            pinCard.addView(r)
            return v
        }
        tvPinCoord = kv("Coordinate")
        tvPinDist = kv("Distance")
        pinCard.addView(btn("Teleport", 0) { startMock() })
        val two = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val bTwo = btn("Two point", 0) { twoPoint() }
        val bMulti = btn("Multi-point", 0) { addMulti() }
        bTwo.layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(0, dp(8), dp(4), 0) }
        bMulti.layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(4), dp(8), 0, 0) }
        two.addView(bTwo)
        two.addView(bMulti)
        pinCard.addView(two)
        bottom.addView(pinCard, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(bottom, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply {
            setMargins(dp(12), 0, dp(12), dp(12))
        })

        layerIdx = prefs.getInt("layer", 0)
        val sLat = prefs.getString("pin_lat", null)?.toDoubleOrNull()
        val sLon = prefs.getString("pin_lon", null)?.toDoubleOrNull()
        if (sLat != null && sLon != null) {
            pinLat = sLat
            pinLon = sLon
            tvCoords.text = String.format(Locale.US, "📌 %.6f , %.6f", sLat, sLon)
        }

        mapView.getMapAsync { m ->
            maplibre = m
            m.uiSettings.isRotateGesturesEnabled = true
            m.uiSettings.isTiltGesturesEnabled = false
            val la = pinLat
            val lo = pinLon
            m.cameraPosition = CameraPosition.Builder()
                .target(if (la != null && lo != null) LatLng(la, lo) else LatLng(25.2048, 55.2708)) // Dubai
                .zoom(if (la != null) 15.0 else 10.5)
                .build()
            m.addOnMapClickListener { ll ->
                onMapTap(ll)
                true
            }
            applyLayer(layerIdx)
        }

    }

    private fun lastSaved(): Pair<Double, Double>? {
        val la = prefs.getString("pin_lat", null)?.toDoubleOrNull()
        val lo = prefs.getString("pin_lon", null)?.toDoubleOrNull()
        return if (la != null && lo != null) Pair(la, lo) else null
    }

    private fun updatePinCard() {
        if (!::pinCard.isInitialized) return
        val la = pinLat
        val lo = pinLon
        if (la == null || lo == null) {
            pinCard.visibility = View.GONE
            return
        }
        pinCard.visibility = View.VISIBLE
        tvPinCoord.text = String.format(Locale.US, "%.6f, %.6f", la, lo)
        val ref = activePoint() ?: lastSaved()
        tvPinDist.text = if (ref == null) "—" else {
            val r = FloatArray(1)
            android.location.Location.distanceBetween(ref.first, ref.second, la, lo, r)
            if (r[0] >= 1000f) String.format(Locale.US, "%.2f km", r[0] / 1000f) else String.format(Locale.US, "%.2f m", r[0])
        }
    }

    private fun updateMultiBar() {
        if (!::multiBar.isInitialized) return
        multiBar.visibility = if (multiMode && wps.isNotEmpty()) View.VISIBLE else View.GONE
        tvMulti.text = "Multi-point: ${wps.size} point(s) — tap the map to add more"
    }

    private fun saveFavDialog() {
        val la = pinLat
        val lo = pinLon
        if (la == null || lo == null) {
            toast("Drop a pin first")
            return
        }
        val et = EditText(this).apply {
            hint = "Name (e.g. Office)"
            setText(pinName ?: "")
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        AlertDialog.Builder(this).setTitle("Favorite name").setView(et)
            .setPositiveButton("Save") { _, _ ->
                FavStore.add(this, Fav(et.text.toString().trim().ifEmpty { "Place" }, la, lo))
                refreshFavs()
                toast("Saved to Favorites")
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun chooseProfile(onChosen: () -> Unit) {
        val items = arrayOf("🚶 Walk (5 km/h)", "🚲 Bike (16 km/h)", "🚗 Car (50 km/h)")
        AlertDialog.Builder(this).setTitle("How do you travel?").setItems(items) { _, i ->
            moveProfile = i
            val kmh = intArrayOf(5, 16, 50)[i]
            Motion.speedMps = kmh / 3.6
            if (::seekSpeed.isInitialized) seekSpeed.progress = kmh
            onChosen()
        }.show()
    }

    /** Current position -> the pin, along roads. */
    private fun twoPoint() {
        val la = pinLat
        val lo = pinLon
        if (la == null || lo == null) {
            toast("Drop a pin first")
            return
        }
        val from = activePoint() ?: lastSaved()
        if (from == null) {
            toast("Teleport somewhere first, then use Two point")
            return
        }
        chooseProfile {
            wps.clear()
            wps.add(doubleArrayOf(from.first, from.second))
            wps.add(doubleArrayOf(la, lo))
            multiMode = false
            refreshWps()
            updateMultiBar()
            startRoute()
            pinCard.visibility = View.GONE
        }
    }

    private fun addMulti() {
        val la = pinLat
        val lo = pinLon
        if (la == null || lo == null) {
            toast("Drop a pin first")
            return
        }
        if (!multiMode) {
            wps.clear()
            val from = activePoint() ?: lastSaved()
            if (from != null) wps.add(doubleArrayOf(from.first, from.second))
            multiMode = true
        }
        wps.add(doubleArrayOf(la, lo))
        refreshWps()
        updateMultiBar()
        pinCard.visibility = View.GONE
        toast("Point added. Tap the map for the next point, then press Go.")
    }

    private fun multiGo() {
        if (wps.size < 2) {
            toast("Add at least one more point")
            return
        }
        chooseProfile {
            multiMode = false
            updateMultiBar()
            startRoute()
        }
    }

    private fun showJoystick() {
        if (!MockState.running) {
            toast("Teleport somewhere first")
        } else if (!Settings.canDrawOverlays(this)) {
            toast("Allow 'Display over other apps' for FakeGeo, then tap the joystick again")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            startService(Intent(this, JoystickService::class.java))
            toast("Joystick shown. Drag the thin bar to move it.")
        }
    }

    private fun menuRow(icon: String, title: String, sub: String, onClick: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = rounded(SURFACE, 16, STROKE)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, dp(10), 0, 0) }
        addView(TextView(context).apply {
            text = icon
            textSize = 22f
            setPadding(0, 0, dp(14), 0)
        })
        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        col.addView(TextView(context).apply {
            text = title
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(TEXT)
        })
        col.addView(TextView(context).apply {
            text = sub
            textSize = 12f
            setTextColor(MUTED)
        })
        addView(col)
        addView(TextView(context).apply {
            text = "›"
            textSize = 24f
            setTextColor(MUTED)
        })
        setOnClickListener { onClick() }
    }

    private fun buildPages(root: FrameLayout) {
        pagesLayer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            visibility = View.GONE
            isClickable = true
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(SURFACE)
            setPadding(dp(8), dp(8), dp(16), dp(8))
        }
        header.addView(TextView(this).apply {
            text = "←"
            textSize = 26f
            setTextColor(TEXT)
            setPadding(dp(12), 0, dp(16), 0)
            setOnClickListener { onBackPressed() }
        })
        pageTitle = TextView(this).apply {
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(TEXT)
        }
        header.addView(pageTitle)
        pagesLayer.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))
        pageScroll = ScrollView(this)
        pageHost = vbox().apply { setPadding(dp(16), dp(8), dp(16), dp(24)) }
        pageScroll.addView(pageHost)
        pagesLayer.addView(pageScroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(pagesLayer, FrameLayout.LayoutParams(MATCH, MATCH))

        fun add(key: String, builder: (LinearLayout) -> Unit, card: Boolean = true) {
            val v = vbox()
            builder(v)
            if (card) cardify(v)
            v.visibility = View.GONE
            pageViews[key] = v
            pageHost.addView(v)
        }

        add("profile", { p ->
            p.addView(label("FakeGeo", 26f, false))
            p.addView(label("Fake GPS  ·  SIM  ·  IP  ·  Protection", 12f))
            p.addView(menuRow("🌐", "IP info & consistency", "What websites see, and whether it all matches") { showPage("ip", "profile") })
            p.addView(menuRow("📶", "SIM", "Fake SIM values for LSPatch apps") { showPage("sim", "profile") })
            p.addView(menuRow("🛡", "Protect", "Kill switch for the apps you choose") { showPage("protect", "profile") })
            p.addView(menuRow("⭐", "Favorites", "Named places, import / export") { showPage("favorites", "profile") })
            p.addView(menuRow("🕘", "History", "Places you used before") { showPage("history", "profile") })
            p.addView(menuRow("🧭", "Route & Joystick", "Walk, bike or drive between points") { showPage("route", "profile") })
            p.addView(menuRow("🍎", "iOS (USB)", "Experimental: connect and pair an iPhone over USB") { showPage("ios", "profile") })
            p.addView(menuRow("⚙️", "Settings & checks", "Realism, watchdog, home, diagnostics") { showPage("settings", "profile") })
            val year = Calendar.getInstance().get(Calendar.YEAR)
            p.addView(TextView(this).apply {
                text = "© $year Farhad rgb — All rights reserved\nCreated by Farhad rgb"
                textSize = 12f
                setTextColor(MUTED)
                gravity = Gravity.CENTER
                setPadding(0, dp(28), 0, 0)
            })
        }, false)
        add("ip", { buildIpTab(it) })
        add("sim", { buildSimTab(it) })
        add("protect", { buildProtectTab(it) })
        add("settings", { buildSettingsPage(it) })
        add("favorites", { buildFavCard(it) })
        add("history", { buildHistoryPage(it) })
        add("route", { buildMoveCard(it) })
        add("ios", { buildIosPage(it) })
    }

    private fun showPage(key: String, parent: String?) {
        openPage = key
        pageParent = parent
        pageViews.forEach { (k, v) -> v.visibility = if (k == key) View.VISIBLE else View.GONE }
        pageTitle.text = when (key) {
            "profile" -> "Me"
            "ip" -> "IP info"
            "sim" -> "SIM"
            "protect" -> "Protect"
            "settings" -> "Settings & checks"
            "favorites" -> "Favorites"
            "history" -> "History"
            "route" -> "Route & Joystick"
            "ios" -> "iOS (USB)"
            else -> ""
        }
        pagesLayer.visibility = View.VISIBLE
        pageScroll.scrollTo(0, 0)
        when (key) {
            "ip" -> if (!ipLoaded) fetchIp()
            "history" -> refreshHistory()
            "favorites" -> refreshFavs()
        }
        hideKeyboard()
    }

    private fun hidePages() {
        openPage = null
        pageParent = null
        pagesLayer.visibility = View.GONE
    }

    override fun onBackPressed() {
        if (openPage != null) {
            val p = pageParent
            if (p != null) showPage(p, null) else hidePages()
        } else if (::pinCard.isInitialized && pinCard.visibility == View.VISIBLE) {
            pinCard.visibility = View.GONE
        } else {
            super.onBackPressed()
        }
    }

    private fun buildSettingsPage(c: LinearLayout) {
        c.addView(label("⚙️ Behavior", 18f, true))
        swRealism = Switch(this).apply {
            text = "Realistic mode (natural few-meter drift, varying accuracy and altitude)"
            isChecked = prefs.getBoolean("realism", true)
        }
        swWatch = Switch(this).apply {
            text = "Watchdog: check every 1 minute + alarm and auto-reconnect"
            isChecked = prefs.getBoolean("watchdog", true)
        }
        c.addView(swRealism)
        c.addView(swWatch)


        c.addView(label("🏠 Home", 18f, true))
        c.addView(btn("🏠 Home (Dubai)", 1) {
            val hl = prefs.getString("home_lat", null)?.toDoubleOrNull() ?: 25.2048
            val ho = prefs.getString("home_lon", null)?.toDoubleOrNull() ?: 55.2708
            setPin(hl, ho, true, "Home", 15.0)
            startMock()
        })
        c.addView(btn("⭐ Save current pin as Home", 1) {
            val la = pinLat
            val lo = pinLon
            if (la == null || lo == null) toast("Drop a pin first")
            else {
                prefs.edit().putString("home_lat", la.toString()).putString("home_lon", lo.toString()).apply()
                toast("Home saved")
            }
        })


        c.addView(label("📊 Status", 18f, true))
        tvStatus = label("")
        c.addView(tvStatus)
        tvEvents = label("", 12f)
        c.addView(tvEvents)

        c.addView(label("🔒 Keep it from being stopped", 18f, true))
        c.addView(label(
            "1) FakeGeo must be selected as the mock location app.\n" +
                "2) Turn off battery optimization for FakeGeo (button below).\n" +
                "3) Lock the app in Recents and exclude it from task killers / cleaners.\n" +
                "4) Settings > Location > turn off Wi-Fi scanning and Bluetooth scanning.\n" +
                "5) Settings > Location > Location services > turn off Google Location Accuracy."
        ))
        c.addView(btn("🔍 Diagnostics", 1) { Diagnostics.show(this, pinLat, pinLon) })
        c.addView(btn("Open Developer options", 1) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            } catch (e: Exception) {
                toast("Developer options are off. Settings > About phone > tap Build number 7 times.")
            }
        })
        c.addView(btn("Turn off battery optimization", 1) { batterySettings() })
    }

    private fun buildHistoryPage(c: LinearLayout) {
        c.addView(label("🕘 Pin history", 18f, true))
        historyBox = vbox()
        c.addView(historyBox)
        c.addView(btn("Delete all history", 2) {
            AlertDialog.Builder(this)
                .setMessage("Delete all pin history?")
                .setPositiveButton("Delete") { _, _ ->
                    PinStore.clear(this)
                    refreshHistory()
                }
                .setNegativeButton("Cancel", null)
                .show()
        })
        refreshHistory()
        }



    private fun buildProtectTab(c: LinearLayout) {
        c.addView(label("Both features are optional. Each one has its own on/off switch.", 13f))

        // ---- Kill switch ----
        c.addView(label("🛑 Kill switch", 18f, true))
        c.addView(label(
            "If the fake location drops, FakeGeo instantly cuts the internet of the apps you choose " +
                "(using a local VPN that drops all their traffic), so they cannot send your real location. " +
                "The internet comes back automatically once the fake location is stable again.\n" +
                "Note: Android allows only one VPN at a time. While the kill switch is blocking, " +
                "another VPN app you use will be disconnected."
        ))
        swKill = Switch(this).apply {
            text = "Enable kill switch"
            isChecked = prefs.getBoolean("ks_enabled", false)
        }
        swSound = Switch(this).apply {
            text = "Loud alarm when the location fails"
            isChecked = prefs.getBoolean("ks_sound", true)
        }
        tvKsApps = label("")
        c.addView(swKill)
        c.addView(swSound)
        c.addView(tvKsApps)
        c.addView(btn("Choose apps to protect", 1) { pickApps() })
        c.addView(btn("Test kill switch (5 s)", 1) {
            if (VpnService.prepare(this) != null) {
                ensureVpn()
                return@btn
            }
            KillSwitch.block(this)
            toast("Protected apps are blocked for 5 seconds…")
            ui.postDelayed({ if (!MockState.running) KillSwitch.unblock(this) }, 5000)
        })
        swKill.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("ks_enabled", on).apply()
            if (on) {
                ensureVpn()
                if (savedApps().isEmpty()) pickApps()
            }
        }
        swSound.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("ks_sound", on).apply()
        }
        refreshKsApps()
    }

    // ======================= Search =======================

    private data class Place(val title: String, val subtitle: String, val lat: Double, val lon: Double)

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(etSearch.windowToken, 0)
    }

    /** Photon (OpenStreetMap data, made for search-as-you-type, no API key). */
    private fun photon(q: String, limit: Int, biasLat: Double?, biasLon: Double?): List<Place>? {
        return try {
            var url = "https://photon.komoot.io/api/?lang=en&limit=$limit&q=" + URLEncoder.encode(q, "UTF-8")
            if (biasLat != null && biasLon != null) url += "&lat=$biasLat&lon=$biasLon"
            val arr = JSONObject(httpGet(url)).getJSONArray("features")
            val out = ArrayList<Place>()
            for (i in 0 until arr.length()) {
                val f = arr.getJSONObject(i)
                val p = f.getJSONObject("properties")
                val co = f.getJSONObject("geometry").getJSONArray("coordinates")
                val name = p.optString("name")
                val street = listOf(p.optString("street"), p.optString("housenumber"))
                    .filter { it.isNotBlank() }.joinToString(" ")
                val title = if (name.isNotBlank()) name else street.ifBlank { p.optString("city") }
                val sub = listOf(
                    if (name.isNotBlank()) street else "",
                    p.optString("district"), p.optString("city"), p.optString("state"), p.optString("country")
                ).filter { it.isNotBlank() && it != title }.distinct().joinToString(", ")
                if (title.isNotBlank()) out.add(Place(title, sub, co.getDouble(1), co.getDouble(0)))
            }
            out
        } catch (e: Exception) {
            null
        }
    }

    private fun nominatim(q: String): Place? {
        return try {
            val url = "https://nominatim.openstreetmap.org/search?format=json&limit=1&accept-language=en&q=" +
                URLEncoder.encode(q, "UTF-8")
            val arr = JSONArray(httpGet(url))
            if (arr.length() > 0) {
                val o = arr.getJSONObject(0)
                val dn = o.optString("display_name")
                Place(
                    dn.substringBefore(","), dn.substringAfter(",", "").trim(),
                    o.getString("lat").toDouble(), o.getString("lon").toDouble()
                )
            } else null
        } catch (e: Exception) {
            null
        }
    }

    private fun mapCenter(): LatLng? = try { maplibre?.cameraPosition?.target } catch (_: Exception) { null }

    private fun loadSuggestions(q: String) {
        val gen = ++searchGen
        val c = mapCenter()
        Thread {
            val list = photon(q, 6, c?.latitude, c?.longitude)
            runOnUiThread { if (gen == searchGen) showSuggestions(list) }
        }.start()
    }

    private fun showSuggestions(list: List<Place>?) {
        suggestBox.removeAllViews()
        if (list == null) {
            suggestBox.addView(label("Search is unavailable. Check your internet connection.", 12f))
            return
        }
        if (list.isEmpty()) {
            suggestBox.addView(label("No results", 12f))
            return
        }
        for (p in list) {
            val tv = TextView(this).apply {
                text = if (p.subtitle.isBlank()) p.title else p.title + "\n" + p.subtitle
                textSize = 14f
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = rounded(SURFACE2, 12, STROKE)
                setTextColor(TEXT)
                setOnClickListener { selectPlace(p) }
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, 0, dp(2))
            suggestBox.addView(tv, lp)
        }
    }

    private fun selectPlace(p: Place) {
        suppressWatch = true
        etSearch.setText(p.title)
        etSearch.setSelection(etSearch.text.length)
        suppressWatch = false
        searchGen++
        suggestBox.removeAllViews()
        hideKeyboard()
        setPin(p.lat, p.lon, true, p.title, 17.0)
    }

    private fun doSearch() {
        val q = etSearch.text.toString().trim()
        if (q.isEmpty()) return
        ui.removeCallbacks(suggestRunnable)
        hideKeyboard()
        val c = mapCenter()
        Thread {
            val place = photon(q, 1, c?.latitude, c?.longitude)?.firstOrNull() ?: nominatim(q)
            runOnUiThread {
                if (place == null) toast("Place not found (or no internet).") else selectPlace(place)
            }
        }.start()
    }

    // ======================= Pin / camera =======================

    private fun setPin(lat: Double, lon: Double, center: Boolean, name: String?, zoom: Double) {
        pinLat = lat
        pinLon = lon
        pinName = name
        val coords = String.format(Locale.US, "%.6f , %.6f", lat, lon)
        tvCoords.text = if (name.isNullOrBlank()) "📌 $coords" else "📌 $name\n$coords"
        renderMarkers()
        updatePinCard()
        val m = maplibre
        if (center && m != null) {
            val ll = LatLng(lat, lon)
            m.animateCamera(
                if (zoom > 0.0) CameraUpdateFactory.newLatLngZoom(ll, zoom) else CameraUpdateFactory.newLatLng(ll)
            )
        }
    }

    private fun recenter() {
        val m = maplibre ?: return
        val a = activePoint()
        val t: Pair<Double, Double>? = when {
            a != null -> a
            pinLat != null && pinLon != null -> Pair(pinLat!!, pinLon!!)
            else -> null
        }
        if (t == null) {
            toast("No location selected yet")
            return
        }
        val z = maxOf(m.cameraPosition.zoom, 16.0)
        m.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(t.first, t.second), z))
    }

    private fun startMock() {
        val la = pinLat
        val lo = pinLon
        if (la == null || lo == null) {
            toast("Drop a pin on the map first")
            return
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
            return
        }
        prefs.edit()
            .putString("pin_lat", la.toString())
            .putString("pin_lon", lo.toString())
            .putString("acc", "5")
            .putBoolean("realism", swRealism.isChecked)
            .putBoolean("watchdog", swWatch.isChecked)
            .putBoolean("active", true)
            .apply()
        PinStore.add(this, Pin(la, lo, System.currentTimeMillis()))
        refreshHistory()
        MockState.error = null
        startForegroundService(
            Intent(this, MockLocationService::class.java).setAction(MockLocationService.ACTION_START)
        )
    }

    private fun refreshHistory() {
        historyBox.removeAllViews()
        val list = PinStore.load(this)
        if (list.isEmpty()) {
            historyBox.addView(label("Nothing saved yet"))
            return
        }
        val fmt = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US)
        list.forEachIndexed { idx, pin ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tv = TextView(this).apply {
                text = String.format(Locale.US, "📍 %.5f , %.5f\n%s", pin.lat, pin.lon, fmt.format(Date(pin.time)))
                textSize = 13f
                setTextColor(TEXT)
                setPadding(0, dp(6), 0, dp(6))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    setPin(pin.lat, pin.lon, true, null, 16.0)
                    toast("Pin placed on the map. Press Start.")
                }
            }
            val del = Button(this).apply {
                text = "🗑 Delete"
                isAllCaps = false
                textSize = 12f
                setTextColor(Color.WHITE)
                background = rounded(DANGER, 10)
                stateListAnimator = null
                minWidth = 0
                minimumWidth = 0
                minHeight = dp(36)
                minimumHeight = dp(36)
                setPadding(dp(12), dp(6), dp(12), dp(6))
                setOnClickListener {
                    PinStore.remove(this@MainActivity, idx)
                    refreshHistory()
                }
            }
            row.addView(tv)
            row.addView(del)
            historyBox.addView(row)
        }
    }

    private fun batterySettings() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (pm.isIgnoringBatteryOptimizations(packageName)) {
                toast("Battery optimization is already off ✅")
                return
            }
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                toast("In battery settings, set FakeGeo to Unrestricted")
            }
        }
    }

    // ======================= IP tab =======================

    private data class IpInfo(
        val ip: String, val country: String, val code: String, val region: String,
        val city: String, val isp: String, val tz: String, val lat: Double?, val lon: Double?
    )

    private data class Usage(val type: String, val flags: String)

    private fun buildIpTab(c: LinearLayout) {
        c.addView(label("The internet IP you are connected through (what websites and apps see)"))
        tvIpInfo = TextView(this).apply {
            textSize = 14f
            typeface = Typeface.MONOSPACE
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            textDirection = View.TEXT_DIRECTION_LTR
            gravity = Gravity.LEFT
            background = rounded(SURFACE, 16, STROKE)
            setTextColor(TEXT)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            text = "—"
        }
        c.addView(tvIpInfo)
        tvIpCompare = label("")
        c.addView(tvIpCompare)
        c.addView(btn("🔄 Refresh IP") { fetchIp() })
        c.addView(label("🧭 Consistency check", 18f, true))
        c.addView(label("Compares what apps and websites can see: IP country, pin country, fake SIM, time zone and language."))
        tvCheck = label("Press Refresh IP to run the check.", 13f)
        c.addView(tvCheck)
        c.addView(label(
            "Note: fake GPS and fake SIM do not change your IP. If the IP country differs " +
                "from the SIM country, use a VPN with an IP from the same country."
        ))
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "FakeGeo/1.4 (personal use)")
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun dbl(o: JSONObject, k: String): Double? =
        o.optDouble(k, Double.NaN).takeIf { !it.isNaN() }

    private fun lookupIp(): IpInfo? {
        try {
            val o = JSONObject(httpGet("https://ipwho.is/"))
            if (o.optBoolean("success", false)) {
                return IpInfo(
                    o.optString("ip"), o.optString("country"), o.optString("country_code"),
                    o.optString("region"), o.optString("city"),
                    o.optJSONObject("connection")?.optString("isp") ?: "",
                    o.optJSONObject("timezone")?.optString("id") ?: "",
                    dbl(o, "latitude"), dbl(o, "longitude")
                )
            }
        } catch (_: Exception) {
        }
        try {
            val o = JSONObject(httpGet("https://ipapi.co/json/"))
            if (o.has("ip") && !o.has("error")) {
                return IpInfo(
                    o.optString("ip"), o.optString("country_name"), o.optString("country_code"),
                    o.optString("region"), o.optString("city"), o.optString("org"),
                    o.optString("timezone"), dbl(o, "latitude"), dbl(o, "longitude")
                )
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun yn(b: Boolean) = if (b) "Yes" else "No"

    private fun usageFromIpapiIs(): Usage? {
        val o = JSONObject(httpGet("https://api.ipapi.is/"))
        if (!o.has("ip")) return null
        val ct = o.optJSONObject("company")?.optString("type").orEmpty()
        val at = o.optJSONObject("asn")?.optString("type").orEmpty()
        val t = (if (ct.isNotEmpty()) ct else at).lowercase(Locale.US)
        val type = when {
            o.optBoolean("is_mobile", false) -> "Mobile (Cellular)"
            o.optBoolean("is_datacenter", false) -> "Data Center / Hosting"
            t == "isp" -> "ISP (Residential / Broadband)"
            t == "hosting" -> "Data Center / Hosting"
            t == "business" -> "Business"
            t == "education" -> "Education"
            t == "government" -> "Government"
            t == "banking" -> "Banking"
            t.isNotEmpty() -> t.replaceFirstChar { it.uppercase() }
            else -> return null
        }
        return Usage(
            type,
            "VPN: ${yn(o.optBoolean("is_vpn", false))} | Proxy: ${yn(o.optBoolean("is_proxy", false))} | " +
                "Tor: ${yn(o.optBoolean("is_tor", false))}"
        )
    }

    private fun usageFromIpApi(): Usage? {
        val o = JSONObject(httpGet("http://ip-api.com/json/?fields=status,mobile,proxy,hosting"))
        if (o.optString("status") != "success") return null
        val type = when {
            o.optBoolean("mobile", false) -> "Mobile (Cellular)"
            o.optBoolean("hosting", false) -> "Data Center / Hosting"
            else -> "ISP / Residential / Business"
        }
        return Usage(type, "Proxy/VPN: ${yn(o.optBoolean("proxy", false))} | Hosting: ${yn(o.optBoolean("hosting", false))}")
    }

    /** Last resort: guess from the ISP name. */
    private fun usageGuess(isp: String): Usage {
        val s = isp.lowercase(Locale.US)
        if (s.isBlank()) return Usage("Unknown", "—")
        val hosting = listOf(
            "hosting", "cloud", "datacenter", "data center", "server", "vps", "amazon", "aws", "google",
            "microsoft", "azure", "digitalocean", "ovh", "hetzner", "linode", "vultr", "oracle", "contabo",
            "leaseweb", "cdn", "choopa", "m247"
        )
        val mobile = listOf("mobile", "cellular", "wireless", "lte")
        val type = when {
            hosting.any { s.contains(it) } -> "Data Center / Hosting (guess)"
            mobile.any { s.contains(it) } -> "Mobile (Cellular) (guess)"
            else -> "ISP (guess)"
        }
        return Usage(type, "—")
    }

    private fun lookupUsage(isp: String): Usage {
        try { usageFromIpapiIs()?.let { return it } } catch (_: Exception) {}
        try { usageFromIpApi()?.let { return it } } catch (_: Exception) {}
        return usageGuess(isp)
    }

    private fun flag(code: String): String {
        if (code.length != 2) return "🏳"
        val up = code.uppercase(Locale.US)
        if (up.any { it !in 'A'..'Z' }) return "🏳"
        return String(Character.toChars(0x1F1E6 + (up[0] - 'A'))) +
            String(Character.toChars(0x1F1E6 + (up[1] - 'A')))
    }

    private fun fetchIp() {
        tvIpInfo.text = "Loading…"
        tvIpCompare.text = ""
        if (::tvCheck.isInitialized) tvCheck.text = "Checking…"
        val pl = Motion.curLat ?: pinLat
        val po = Motion.curLon ?: pinLon
        Thread {
            val r = try { lookupIp() } catch (e: Exception) { null }
            val u = lookupUsage(r?.isp.orEmpty())
            val pc = if (pl != null && po != null) pinCountry(pl, po) else null
            runOnUiThread { showIp(r, u); showCheck(r, u, pc) }
        }.start()
    }

    /** Country code of the pin (reverse geocoding), or null. */
    private fun pinCountry(lat: Double, lon: Double): String? = try {
        val o = JSONObject(
            httpGet(String.format(Locale.US,
                "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=3&accept-language=en&lat=%.5f&lon=%.5f", lat, lon))
        )
        o.optJSONObject("address")?.optString("country_code")?.uppercase(Locale.US)?.ifEmpty { null }
    } catch (_: Exception) {
        null
    }

    private fun showCheck(r: IpInfo?, u: Usage, pinCode: String?) {
        if (!::tvCheck.isInitialized) return
        if (r == null) { tvCheck.text = "Could not run the check (no IP info)."; return }
        var bad = 0
        val sb = StringBuilder()
        val sim = BuildConfig.SIM_COUNTRY.uppercase(Locale.US)
        val ip = r.code.uppercase(Locale.US)
        fun row(ok: Boolean?, text: String) {
            val icon = if (ok == null) "ℹ️ " else if (ok) "✅ " else "⚠️ "
            if (ok == false) bad++
            sb.append(icon).append(text).append('\n')
        }
        row(ip == sim, "IP country $ip vs fake SIM $sim")
        if (pinCode != null) row(ip == pinCode, "IP country $ip vs pin country $pinCode")
        else row(null, "Pin country: no pin yet or lookup failed")
        if (pinCode != null) row(pinCode == sim, "Pin country $pinCode vs fake SIM $sim")
        if (r.tz.isNotBlank()) {
            val now = System.currentTimeMillis()
            val dev = java.util.TimeZone.getDefault()
            val ipTz = java.util.TimeZone.getTimeZone(r.tz)
            val same = dev.getOffset(now) == ipTz.getOffset(now)
            val fmt = SimpleDateFormat("HH:mm", Locale.US).apply { timeZone = ipTz }
            row(same, "Device time zone ${dev.id} vs IP time zone ${r.tz} (time at IP: ${fmt.format(Date(now))})")
        }
        val lc = Locale.getDefault().country.uppercase(Locale.US)
        if (lc.isNotEmpty()) row(null, "Phone language region: $lc")
        val flagged = u.flags.contains("VPN: Yes") || u.flags.contains("Proxy: Yes") ||
            u.flags.contains("Tor: Yes") || u.flags.contains("Proxy/VPN: Yes")
        row(!flagged, if (flagged) "This IP is flagged as VPN/proxy/Tor" else "IP is not flagged as VPN/proxy")
        sb.append(if (bad == 0) "\nAll checks are consistent." else "\n$bad mismatch(es). Apps may notice the difference.")
        tvCheck.text = sb.toString()
        tvCheck.setTextColor(if (bad == 0) SUCCESS else AMBER)
    }

    private fun showIp(r: IpInfo?, u: Usage) {
        if (r == null) {
            tvIpInfo.text = "Could not get IP info.\nCheck your internet connection."
            tvIpCompare.text = ""
            return
        }
        ipLoaded = true
        val sb = StringBuilder()
        sb.append("IP         : ${r.ip}\n")
        sb.append("Country    : ${flag(r.code)} ${r.country} (${r.code})\n")
        sb.append("City       : ${r.city}\n")
        sb.append("Region     : ${r.region}\n")
        sb.append("ISP        : ${r.isp}\n")
        sb.append("Usage type : ${u.type}\n")
        sb.append("Flags      : ${u.flags}\n")
        sb.append("Timezone   : ${r.tz}\n")
        if (r.lat != null && r.lon != null) {
            sb.append(String.format(Locale.US, "Lat/Lon    : %.4f , %.4f", r.lat, r.lon))
        }
        tvIpInfo.text = sb.toString()

        val sim = BuildConfig.SIM_COUNTRY.uppercase(Locale.US)
        tvIpCompare.text = if (r.code.equals(sim, ignoreCase = true)) {
            "✅ IP country ($sim) matches the fake SIM country"
        } else {
            "⚠️ IP country (${r.code}) differs from the fake SIM country ($sim)"
        }
    }

    // ======================= SIM tab =======================

    private fun buildSimTab(c: LinearLayout) {
        c.addView(label("📶 SIM module for LSPatch", 18f, true))
        val number = if (BuildConfig.SIM_NUMBER.isBlank()) "(not set — real number is visible)" else BuildConfig.SIM_NUMBER
        c.addView(label(
            "What patched apps will see (set at build time):\n" +
                "• Country: ${BuildConfig.SIM_COUNTRY.uppercase()}\n" +
                "• MCC+MNC: ${BuildConfig.SIM_MCCMNC}\n" +
                "• Operator: ${BuildConfig.SIM_OPERATOR_NAME}\n" +
                "• Number: $number\n\n" +
                "These values only apply inside apps patched with LSPatch using this module. " +
                "After every new build, patch the target app again."
        ))
    }

    // ======================= general =======================

    // ======================= Kill switch helpers =======================

    private fun savedApps(): Set<String> =
        prefs.getStringSet("ks_apps", emptySet())?.toSet().orEmpty()

    private fun refreshKsApps() {
        val n = savedApps().size
        tvKsApps.text = if (n == 0) {
            "Protected apps: none selected (the kill switch will block ALL apps except FakeGeo)"
        } else {
            "Protected apps: $n selected"
        }
    }

    private fun ensureVpn() {
        val i = VpnService.prepare(this)
        if (i != null) startActivityForResult(i, REQ_VPN)
    }

    private fun pickApps() {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase(Locale.US) }
        if (apps.isEmpty()) {
            toast("Could not list installed apps")
            return
        }
        val saved = savedApps()
        val checked = BooleanArray(apps.size) { apps[it].second in saved }
        AlertDialog.Builder(this)
            .setTitle("Apps to protect")
            .setMultiChoiceItems(apps.map { it.first }.toTypedArray(), checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton("Save") { _, _ ->
                val set = HashSet<String>()
                for (i in apps.indices) if (checked[i]) set.add(apps[i].second)
                prefs.edit().putStringSet("ks_apps", set).apply()
                refreshKsApps()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_DDI) {
            val uris = ArrayList<Uri>()
            data?.clipData?.let { cd -> for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri) }
            data?.data?.let { uris.add(it) }
            if (resultCode == Activity.RESULT_OK && uris.isNotEmpty()) {
                runIosJob("Mounting the Developer Disk Image… (needs internet, may take a minute)") { dev ->
                    IosPairing.pairAndTest(this, dev, ddiUris = uris)
                }
            }
            return
        }
        if (requestCode == REQ_VPN) {
            if (resultCode == RESULT_OK) {
                toast("Kill switch is ready ✅")
            } else {
                swKill.isChecked = false
                toast("VPN permission is required for the kill switch")
            }
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == 1) {
            if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startMock()
            else toast("Location permission is required for fake GPS")
        }
    }



    // ======================= iOS (USB) =======================

    private lateinit var tvIosReport: TextView
    private lateinit var tvIosLive: TextView

    /** Map button: opens the iOS (USB) page. */
    private fun iosFab(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.parseColor("#22000000"))
            }
            elevation = dp(4).toFloat()
            setOnClickListener { showPage("ios", null) }
        }
        box.addView(TextView(this).apply {
            text = "iOS"
            textSize = 16f
            setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC), Typeface.BOLD_ITALIC)
            setTextColor(Color.parseColor("#7C3AED"))
            paint.shader = android.graphics.LinearGradient(
                0f, 0f, dp(34).toFloat(), 0f,
                intArrayOf(Color.parseColor("#3B82F6"), Color.parseColor("#8B5CF6"), Color.parseColor("#EC4899")),
                null, android.graphics.Shader.TileMode.CLAMP
            )
            gravity = Gravity.CENTER
        })
        return box
    }

    private fun buildIosPage(c: LinearLayout) {
        c.addView(label("🔌 iPhone over USB (OTG)", 18f, true))
        c.addView(label(
            "Plug the iPhone into this phone with a cable (+ OTG adapter if needed) and unlock it. " +
                "Work in progress: the steps below only check the connection and pair with the iPhone. " +
                "The iPhone location is NOT changed yet.",
            12f
        ))
        c.addView(btn("1) Probe iPhone over USB", 0) {
            runIosJob("Probing…") { dev -> UsbMux.probe(this, dev) }
        })
        c.addView(btn("2) Pair (Trust) + secure session test", 1) {
            runIosJob("Pairing… tap Trust on the iPhone and enter its passcode if asked.") { dev ->
                IosPairing.pairAndTest(this, dev)
            }
        })
        c.addView(btn("3) Enable Developer Mode (needed on iOS 16+)", 1) {
            runIosJob("Asking the iPhone to show/enable Developer Mode…") { dev ->
                IosPairing.pairAndTest(this, dev, enableDevMode = true)
            }
        })
        c.addView(btn("4) Mount Developer Disk Image (pick 3 files)", 1) {
            tvIosReport.text = "Pick the three files: Image.dmg, BuildManifest.plist and the trustcache file (select all three together)."
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }
            try { startActivityForResult(i, REQ_DDI) } catch (e: Exception) { toast("No file picker: ${e.message}") }
        })
        c.addView(btn("5) CoreDevice tunnel test (iOS 17+)", 1) {
            runIosJob("Opening the CoreDevice tunnel…") { dev ->
                IosPairing.pairAndTest(this, dev, tunnelTest = true)
            }
        })
        c.addView(btn("6) Set iPhone location to the current pin (75 s test)", 1) {
            val la = pinLat
            val lo = pinLon
            if (la == null || lo == null) {
                toast("Drop a pin on the map first")
            } else {
                runIosJob("Sending the pin to the iPhone… it stays for about 75 s. Open Maps on the iPhone and watch the blue dot. The report appears when it ends.") { dev ->
                    IosPairing.pairAndTest(this, dev, simLat = la, simLon = lo)
                }
            }
        })
        tvIosLive = TextView(this).apply {
            textSize = 13f
            setTextColor(TEXT)
            setPadding(0, dp(10), 0, dp(4))
        }
        c.addView(btn("▶ iPhone: start / move to the current pin", 1) { startIosLive() })
        c.addView(btn("■ iPhone: stop (back to the real location)", 1) {
            if (IosState.running) {
                IosSession.stop()
                toast("Stopping… the iPhone returns to its real location")
            } else {
                toast("The iPhone session is not running")
            }
        })
        c.addView(tvIosLive)
        c.addView(btn("Forget saved pairing", 1) {
            IosPairing.forget(this)
            toast("Saved pairing removed from this phone")
        })
        c.addView(btn("Copy report", 1) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("FakeGeo iOS report", tvIosReport.text.toString()))
            toast("Copied")
        })
        tvIosReport = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextColor(TEXT)
            setTextIsSelectable(true)
            setPadding(0, dp(10), 0, dp(6))
        }
        c.addView(tvIosReport)
    }

    /** Starts (or, if already running, just moves) the permanent iPhone location session. */
    private fun startIosLive() {
        val la = pinLat
        val lo = pinLon
        if (la == null || lo == null) {
            toast("Drop a pin on the map first")
            return
        }
        if (IosState.running) {
            IosFeed.set(la, lo)
            toast("Moving the iPhone to the pin…")
            return
        }
        val dev = UsbMux.findIphone(this)
        if (dev == null) {
            tvIosReport.text = "No iPhone found on USB. Check the cable/OTG adapter and unlock the iPhone."
            return
        }
        UsbMux.requestPermission(this, dev) { granted ->
            if (granted) {
                IosFeed.set(la, lo)
                val i = Intent(this, IosService::class.java)
                    .setAction(IosService.ACTION_START)
                    .putExtra(IosService.EXTRA_DEVICE, dev)
                try {
                    startForegroundService(i)
                    tvIosReport.text = "Starting the iPhone location session…"
                } catch (e: Exception) {
                    tvIosReport.text = "Could not start the iPhone service: ${e.message}"
                }
            } else {
                tvIosReport.text = "USB permission denied."
            }
        }
    }

    private fun iosLiveText(): String {
        if (IosState.status.isEmpty()) return ""
        val sb = StringBuilder("📱 ${IosState.status}")
        if (IosState.running) sb.append("\nPositions sent: ${IosState.updates}   Reconnects: ${IosState.reconnects}")
        if (IosState.lastError.isNotEmpty() && !IosState.running) sb.append("\n${IosState.lastError}")
        return sb.toString()
    }

    /** Finds the iPhone, gets USB permission, then runs [work] on a background thread and shows its report. */
    private fun runIosJob(startMsg: String, work: (UsbDevice) -> String) {
        val dev = UsbMux.findIphone(this)
        if (dev == null) {
            tvIosReport.text = "No iPhone found on USB. Check the cable/OTG adapter and unlock the iPhone."
            return
        }
        tvIosReport.text = "Asking for USB permission…"
        UsbMux.requestPermission(this, dev) { granted ->
            if (!granted) {
                tvIosReport.text = "USB permission denied."
            } else {
                tvIosReport.text = startMsg
                Thread {
                    val rep = try { work(dev) } catch (e: Throwable) { "ERROR: $e" }
                    runOnUiThread { if (!isDestroyed) tvIosReport.text = rep }
                }.start()
            }
        }
    }

    // ======================= Favorites =======================

    private lateinit var favBox: LinearLayout

    private fun buildFavCard(c: LinearLayout) {
        c.addView(label("⭐ Favorites", 18f, true))
        c.addView(btn("Save current pin as favorite", 1) {
            val la = pinLat
            val lo = pinLon
            if (la == null || lo == null) {
                toast("Drop a pin first")
            } else {
                val et = EditText(this).apply {
                    hint = "Name (e.g. Office)"
                    setText(pinName ?: "")
                    setPadding(dp(16), dp(12), dp(16), dp(12))
                }
                AlertDialog.Builder(this).setTitle("Favorite name").setView(et)
                    .setPositiveButton("Save") { _, _ ->
                        val n = et.text.toString().trim().ifEmpty { "Place" }
                        FavStore.add(this, Fav(n, la, lo))
                        refreshFavs()
                    }
                    .setNegativeButton("Cancel", null).show()
            }
        })
        favBox = vbox()
        c.addView(favBox)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val bExp = btn("Export", 1) {
            val json = FavStore.toJson(FavStore.load(this))
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("favorites", json))
            toast("Favorites copied to the clipboard. Paste them anywhere to keep a backup.")
            try {
                startActivity(Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, json), "Share favorites"
                ))
            } catch (_: Exception) {
            }
        }
        val bImp = btn("Import", 1) {
            val et = EditText(this).apply {
                hint = "Paste exported favorites here"
                setPadding(dp(16), dp(12), dp(16), dp(12))
            }
            AlertDialog.Builder(this).setTitle("Import favorites").setView(et)
                .setPositiveButton("Import") { _, _ ->
                    val n = FavStore.importJson(this, et.text.toString().trim())
                    toast(if (n > 0) "Imported $n place(s)" else "Nothing imported (invalid text)")
                    refreshFavs()
                }
                .setNegativeButton("Cancel", null).show()
        }
        bExp.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, dp(6), dp(4), 0) }
        bImp.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), dp(6), 0, 0) }
        row.addView(bExp)
        row.addView(bImp)
        c.addView(row)
        refreshFavs()
    }

    private fun refreshFavs() {
        if (!::favBox.isInitialized) return
        favBox.removeAllViews()
        val list = FavStore.load(this)
        if (list.isEmpty()) {
            favBox.addView(label("No favorites yet", 13f))
            return
        }
        list.forEachIndexed { idx, f ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tv = TextView(this).apply {
                text = String.format(Locale.US, "⭐ %s\n%.5f , %.5f", f.name, f.lat, f.lon)
                textSize = 13f
                setTextColor(TEXT)
                setPadding(0, dp(6), 0, dp(6))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    setPin(f.lat, f.lon, true, f.name, 16.0)
                    toast("Pin placed. Press Start.")
                }
            }
            val del = Button(this).apply {
                text = "🗑"
                isAllCaps = false
                textSize = 12f
                setTextColor(Color.WHITE)
                background = rounded(DANGER, 10)
                setOnClickListener {
                    FavStore.remove(this@MainActivity, idx)
                    refreshFavs()
                }
            }
            row.addView(tv)
            row.addView(del, LinearLayout.LayoutParams(dp(52), dp(40)))
            favBox.addView(row)
        }
    }

    // ======================= Route & Joystick =======================

    private val wps = mutableListOf<DoubleArray>()
    private var moveProfile = 0 // 0 walk, 1 bike, 2 car
    private lateinit var tvWps: TextView
    private lateinit var tvMove: TextView
    private lateinit var seekSpeed: SeekBar
    private lateinit var tvSpeed: TextView
    private var swLoop: Switch? = null

    private fun buildMoveCard(c: LinearLayout) {
        c.addView(label("🚶 Route & Joystick", 18f, true))
        c.addView(label(
            "Route: add 2 or more waypoints (drop a pin, press 'Add pin as waypoint'), choose how you travel " +
                "and press Start route. The location then moves along real roads at that speed.\n" +
                "Joystick: a floating pad over any app to steer manually (fake GPS must be running)."
        ))
        tvWps = label("Waypoints: none", 13f)
        c.addView(tvWps)
        c.addView(btn("➕ Add pin as waypoint", 1) {
            val la = pinLat
            val lo = pinLon
            if (la == null || lo == null) toast("Drop a pin first")
            else {
                wps.add(doubleArrayOf(la, lo))
                refreshWps()
            }
        })
        c.addView(btn("Clear waypoints and route", 1) {
            wps.clear()
            Motion.loadRoute(emptyList())
            refreshWps()
            renderRoute()
        })

        val prof = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val names = arrayOf("🚶 Walk", "🚲 Bike", "🚗 Car")
        val pbs = ArrayList<Button>()
        fun paintProfiles() {
            pbs.forEachIndexed { i, b ->
                b.background = if (i == moveProfile) rounded(ACCENT, 12) else rounded(SURFACE2, 12, STROKE)
            }
        }
        names.forEachIndexed { i, n ->
            val b = btn(n, 1) {
                moveProfile = i
                val kmh = intArrayOf(5, 16, 50)[i]
                seekSpeed.progress = kmh
                paintProfiles()
            }
            b.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { setMargins(dp(3), dp(6), dp(3), 0) }
            pbs.add(b)
            prof.addView(b)
        }
        c.addView(prof)
        tvSpeed = label("Speed: 5 km/h", 13f)
        c.addView(tvSpeed)
        seekSpeed = SeekBar(this).apply {
            max = 120
            progress = 5
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = Math.max(1, p)
                    tvSpeed.text = "Speed: $v km/h"
                    Motion.speedMps = v / 3.6
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        c.addView(seekSpeed)
        paintProfiles()
        Motion.speedMps = 5 / 3.6

        swLoop = Switch(this).apply { text = "Loop (go back and forth)"; isChecked = false }
        c.addView(swLoop)
        styleSwitch(swLoop!!)

        c.addView(btn("▶ Start route", 3) { startRoute() })
        val pr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val bPause = btn("⏸ Pause / Resume", 1) {
            Motion.paused = !Motion.paused
            toast(if (Motion.paused) "Route paused" else "Route resumed")
        }
        val bStopR = btn("⏹ Stop route", 2) {
            Motion.stop()
            toast("Route stopped. The location stays where it is.")
        }
        bPause.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, dp(6), dp(4), 0) }
        bStopR.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), dp(6), 0, 0) }
        pr.addView(bPause)
        pr.addView(bStopR)
        c.addView(pr)
        tvMove = label("", 13f)
        c.addView(tvMove)

        c.addView(btn("🕹 Show joystick", 1) {
            if (!MockState.running) {
                toast("Start the fake GPS first")
            } else if (!Settings.canDrawOverlays(this)) {
                toast("Allow 'Display over other apps' for FakeGeo, then press the button again")
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, JoystickService::class.java))
                toast("Joystick shown. Open any app; drag the thin bar to move it.")
            }
        })
        c.addView(btn("Hide joystick", 1) {
            stopService(Intent(this, JoystickService::class.java))
        })
    }

    private fun refreshWps() {
        tvWps.text = if (wps.isEmpty()) "Waypoints: none" else
            "Waypoints (${wps.size}):\n" + wps.mapIndexed { i, p ->
                String.format(Locale.US, "%d) %.5f , %.5f", i + 1, p[0], p[1])
            }.joinToString("\n")
    }

    private fun renderRoute() {
        val st = style ?: return
        try {
            val src: GeoJsonSource? = st.getSourceAs("route-src")
            val pts = Motion.route
            if (pts.size < 2) {
                src?.setGeoJson(emptyJson)
            } else {
                val sb = StringBuilder("{\"type\":\"LineString\",\"coordinates\":[")
                pts.forEachIndexed { i, p ->
                    if (i > 0) sb.append(',')
                    sb.append(String.format(Locale.US, "[%.6f,%.6f]", p[1], p[0]))
                }
                sb.append("]}")
                src?.setGeoJson(sb.toString())
            }
        } catch (_: Exception) {
        }
    }

    private fun startRoute() {
        if (wps.size < 2) {
            toast("Add at least 2 waypoints")
            return
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
            return
        }
        toast("Building route…")
        val prof = moveProfile
        val list = wps.map { it.clone() }
        Thread {
            var pts: List<DoubleArray>? = null
            var note = ""
            try {
                pts = fetchRoute(list, prof)
            } catch (e: Exception) {
                note = " (road routing unavailable, using straight lines)"
            }
            val res = pts ?: list
            ui.post {
                Motion.loadRoute(res)
                Motion.loop = swLoop?.isChecked == true
                Motion.paused = false
                renderRoute()
                val first = res.first()
                if (!MockState.running) {
                    setPin(first[0], first[1], true, null, 15.0)
                    startMock()
                    if (::pinCard.isInitialized) pinCard.visibility = View.GONE
                } else {
                    Motion.teleportLat = first[0]
                    Motion.teleportLon = first[1]
                }
                Motion.mode = Motion.Mode.ROUTE
                toast(String.format(Locale.US, "Route started: %.1f km%s", Motion.routeLengthM() / 1000.0, note))
            }
        }.start()
    }

    /** OSRM (FOSSGIS) road routing with foot / bike / car profiles. */
    private fun fetchRoute(w: List<DoubleArray>, prof: Int): List<DoubleArray> {
        val name = arrayOf("routed-foot", "routed-bike", "routed-car")[prof]
        val coords = w.joinToString(";") { String.format(Locale.US, "%.6f,%.6f", it[1], it[0]) }
        val url = "https://routing.openstreetmap.de/$name/route/v1/driving/$coords?overview=full&geometries=geojson"
        val con = URL(url).openConnection() as HttpURLConnection
        con.connectTimeout = 10000
        con.readTimeout = 15000
        con.setRequestProperty("User-Agent", "FakeGeo/2.3")
        val body = con.inputStream.bufferedReader().readText()
        val arr = JSONObject(body).getJSONArray("routes").getJSONObject(0)
            .getJSONObject("geometry").getJSONArray("coordinates")
        val out = ArrayList<DoubleArray>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONArray(i)
            out.add(doubleArrayOf(p.getDouble(1), p.getDouble(0)))
        }
        if (out.size < 2) throw IOException("empty route")
        return out
    }

    private fun updateMoveText() {
        if (!::tvMove.isInitialized) return
        tvMove.text = when (Motion.mode) {
            Motion.Mode.ROUTE -> String.format(
                Locale.US, "🚶 Route %.0f%% — %.1f km/h%s",
                Motion.progress * 100, Motion.curSpeed * 3.6, if (Motion.paused) " (paused)" else ""
            )
            Motion.Mode.JOYSTICK -> String.format(Locale.US, "🕹 Joystick — %.1f km/h", Motion.curSpeed * 3.6)
            else -> ""
        }
    }

    private fun updateStatus() {
        updateMoveText()
        if (::tvIosLive.isInitialized) tvIosLive.text = iosLiveText()
        val err = MockState.error
        tvStatus.text = when {
            err != null -> "❌ $err"
            MockState.running -> "✅ Active at ${tvCoords.text.toString().substringAfterLast('\n')}"
            else -> "⏹ Inactive"
        }
        if (KillSwitch.blocking) {
            tvStatus.text = "🛑 KILL SWITCH IS BLOCKING the protected apps' internet\n" + tvStatus.text
        }
        val sum = MockState.summary(android.os.SystemClock.elapsedRealtime())
        if (sum.isNotEmpty()) tvStatus.text = tvStatus.text.toString() + "\n" + sum
        tvEvents.text = MockState.recent().joinToString("\n")
        tvStatus.setTextColor(
            when {
                MockState.error != null -> DANGER
                KillSwitch.blocking -> AMBER
                MockState.running -> SUCCESS
                else -> MUTED
            }
        )
        if (::pill.isInitialized) {
            pill.visibility = if (MockState.running) View.VISIBLE else View.GONE
            val mv = tvMove.text.toString()
            tvPill.text = "● Fake GPS active" + (if (sum.isNotEmpty()) "\n$sum" else "") + (if (mv.isNotEmpty()) "\n$mv" else "")
            if (pinCard.visibility == View.VISIBLE) updatePinCard()
            updateMultiBar()
        }
        updateDot()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---- lifecycle (MapView needs all of these) ----
    override fun onStart() { super.onStart(); mapView.onStart() }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
        ui.post(refresh)
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
        ui.removeCallbacks(refresh)
    }

    override fun onStop() { super.onStop(); mapView.onStop() }

    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mapView.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        mapView.onDestroy()
        super.onDestroy()
    }
}
