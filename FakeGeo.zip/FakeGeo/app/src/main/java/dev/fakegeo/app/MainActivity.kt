package dev.fakegeo.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonSource
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var mapView: MapView
    private var maplibre: MapLibreMap? = null
    private var style: Style? = null
    private var layerIdx = 0
    private var savedBundle: Bundle? = null

    private var pinLat: Double? = null
    private var pinLon: Double? = null
    private var pinName: String? = null

    private lateinit var tvCoords: TextView
    private lateinit var etSearch: EditText
    private lateinit var suggestBox: LinearLayout
    private lateinit var swRealism: Switch
    private lateinit var swWatch: Switch
    private lateinit var swKill: Switch
    private lateinit var swSound: Switch
    private lateinit var tvKsApps: TextView
    private val REQ_VPN = 77
    private lateinit var tvStatus: TextView
    private lateinit var tvEvents: TextView
    private lateinit var historyBox: LinearLayout
    private lateinit var tvIpInfo: TextView
    private lateinit var tvIpCompare: TextView

    private val tabs = mutableListOf<View>()
    private val tabButtons = mutableListOf<Button>()
    private var ipLoaded = false
    private val ui = Handler(Looper.getMainLooper())

    private var suppressWatch = false
    private var searchGen = 0
    private var suggestRunnable: Runnable = Runnable {}

    private val refresh = object : Runnable {
        override fun run() {
            updateStatus()
            ui.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(s: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(8), 0, dp(4))
    }

    private fun actionButton(s: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        text = s
        isAllCaps = false
        textSize = 14f
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(color)
        }
        minHeight = dp(46)
        elevation = dp(1).toFloat()
        setPadding(dp(14), dp(7), dp(14), dp(7))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(6)
            bottomMargin = dp(6)
        }
        setOnClickListener { onClick() }
    }

    private fun btn(s: String, onClick: () -> Unit) =
        actionButton(s, Color.rgb(21, 101, 192), onClick)

    private fun secondaryBtn(s: String, onClick: () -> Unit) =
        actionButton(s, Color.rgb(84, 101, 120), onClick)

    private fun dangerBtn(s: String, onClick: () -> Unit) =
        actionButton(s, Color.rgb(190, 58, 66), onClick)

    private fun vbox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    // ======================= onCreate =======================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        savedBundle = savedInstanceState
        prefs = getSharedPreferences("fakegeo", MODE_PRIVATE)
        MapLibre.getInstance(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(label("FakeGeo", 22f, true))

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("📍 GPS", "🌐 IP", "📶 SIM").forEachIndexed { i, n ->
            val b = Button(this).apply {
                text = n
                isAllCaps = false
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { showTab(i) }
            }
            tabButtons.add(b)
            bar.addView(b)
        }
        root.addView(bar)

        val tabGps = vbox()
        val tabIp = vbox()
        val tabSim = vbox()
        tabs.addAll(listOf(tabGps, tabIp, tabSim))
        tabs.forEach { root.addView(it) }

        buildGpsTab(tabGps)
        buildIpTab(tabIp)
        buildSimTab(tabSim)

        val year = Calendar.getInstance().get(Calendar.YEAR)
        root.addView(TextView(this).apply {
            text = "© $year Farhad rgb — All rights reserved\nCreated by Farhad rgb"
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        })

        showTab(prefs.getInt("tab", 0))

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    private fun showTab(i: Int) {
        tabs.forEachIndexed { idx, v -> v.visibility = if (idx == i) View.VISIBLE else View.GONE }
        tabButtons.forEachIndexed { idx, b ->
            if (idx == i) {
                b.setBackgroundColor(Color.parseColor("#1565C0"))
                b.setTextColor(Color.WHITE)
            } else {
                b.setBackgroundColor(Color.parseColor("#E0E0E0"))
                b.setTextColor(Color.BLACK)
            }
        }
        prefs.edit().putInt("tab", i).apply()
        if (i == 1 && !ipLoaded) fetchIp()
    }

    // ======================= Map =======================

    private fun fab(iconRes: Int, onClick: (View) -> Unit) = ImageButton(this).apply {
        setImageResource(iconRes)
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.WHITE)
            setStroke(dp(1), Color.parseColor("#22000000"))
        }
        elevation = dp(4).toFloat()
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setOnClickListener { onClick(it) }
    }

    /** Raster style from Esri (used for Satellite / Hybrid / Terrain / Dark). */
    private fun rasterStyle(base: String, baseMax: Int, labels: String?, labelsMax: Int): String {
        fun src(path: String, max: Int) =
            "{\"type\":\"raster\",\"tiles\":[\"https://server.arcgisonline.com/ArcGIS/rest/services/" +
                path + "/MapServer/tile/{z}/{y}/{x}\"],\"tileSize\":256,\"maxzoom\":" + max +
                ",\"attribution\":\"Tiles © Esri\"}"
        val sources = StringBuilder("\"base\":" + src(base, baseMax))
        val layers = StringBuilder("{\"id\":\"base\",\"type\":\"raster\",\"source\":\"base\"}")
        if (labels != null) {
            sources.append(",\"labels\":").append(src(labels, labelsMax))
            layers.append(",{\"id\":\"labels\",\"type\":\"raster\",\"source\":\"labels\"}")
        }
        return "{\"version\":8,\"sources\":{" + sources + "},\"layers\":[" + layers + "]}"
    }

    private fun styleBuilder(i: Int): Style.Builder = when (i) {
        1 -> Style.Builder().fromUri("https://tiles.openfreemap.org/styles/positron")
        2 -> Style.Builder().fromJson(rasterStyle("World_Imagery", 19, "Reference/World_Boundaries_and_Places", 19))
        3 -> Style.Builder().fromJson(rasterStyle("World_Imagery", 19, null, 19))
        4 -> Style.Builder().fromJson(rasterStyle("World_Topo_Map", 19, null, 19))
        5 -> Style.Builder().fromJson(
            rasterStyle("Canvas/World_Dark_Gray_Base", 16, "Canvas/World_Dark_Gray_Reference", 16)
        )
        else -> Style.Builder().fromUri("https://tiles.openfreemap.org/styles/liberty")
    }

    private fun applyLayer(i: Int) {
        layerIdx = i
        prefs.edit().putInt("layer", i).apply()
        val m = maplibre ?: return
        style = null
        m.setStyle(styleBuilder(i)) { st ->
            style = st
            setupStyle(st, i == 0 || i == 1)
        }
    }

    private fun setupStyle(st: Style, vector: Boolean) {
        try {
            st.addImage("pin", getDrawable(R.drawable.ic_pin)!!)
            st.addImage("dot", getDrawable(R.drawable.ic_dot)!!)
            st.addSource(GeoJsonSource("pin-src"))
            st.addSource(GeoJsonSource("dot-src"))
            st.addLayer(
                SymbolLayer("pin-layer", "pin-src").withProperties(
                    PropertyFactory.iconImage("pin"),
                    PropertyFactory.iconAnchor(Property.ICON_ANCHOR_BOTTOM),
                    PropertyFactory.iconAllowOverlap(true),
                    PropertyFactory.iconIgnorePlacement(true)
                )
            )
            st.addLayer(
                SymbolLayer("dot-layer", "dot-src").withProperties(
                    PropertyFactory.iconImage("dot"),
                    PropertyFactory.iconAnchor(Property.ICON_ANCHOR_CENTER),
                    PropertyFactory.iconAllowOverlap(true),
                    PropertyFactory.iconIgnorePlacement(true)
                )
            )
        } catch (e: Exception) {
            toast("Map markers failed: ${e.message}")
        }
        if (vector) englishLabels(st)
        renderMarkers()
    }

    /** Prefer English (name:en / Latin) for place labels on vector maps. */
    private fun englishLabels(st: Style) {
        try {
            val expr = Expression.coalesce(
                Expression.get("name:en"), Expression.get("name:latin"), Expression.get("name")
            )
            for (l in st.layers) {
                if (l is SymbolLayer && (l.id.startsWith("label") || l.id.startsWith("poi") || l.id.contains("name"))) {
                    l.setProperties(PropertyFactory.textField(expr))
                }
            }
        } catch (_: Throwable) {
        }
    }

    private val emptyJson = "{\"type\":\"FeatureCollection\",\"features\":[]}"

    private fun pointJson(lat: Double, lon: Double) =
        String.format(Locale.US, "{\"type\":\"Point\",\"coordinates\":[%.7f,%.7f]}", lon, lat)

    private fun activePoint(): Pair<Double, Double>? {
        if (!MockState.running) return null
        val la = prefs.getString("pin_lat", null)?.toDoubleOrNull()
        val lo = prefs.getString("pin_lon", null)?.toDoubleOrNull()
        return if (la != null && lo != null) Pair(la, lo) else null
    }

    private var lastDotKey = "?"

    /** Red pin = selected point. Blue dot = where fake GPS is active right now. */
    private fun renderMarkers() {
        val st = style ?: return
        try {
            val pin: GeoJsonSource? = st.getSourceAs("pin-src")
            val la = pinLat
            val lo = pinLon
            pin?.setGeoJson(if (la != null && lo != null) pointJson(la, lo) else emptyJson)
            val dot: GeoJsonSource? = st.getSourceAs("dot-src")
            val a = activePoint()
            dot?.setGeoJson(if (a != null) pointJson(a.first, a.second) else emptyJson)
        } catch (_: Exception) {
        }
    }

    private fun updateDot() {
        val a = activePoint()
        val key = if (a != null) "${a.first},${a.second}" else ""
        if (key != lastDotKey) {
            lastDotKey = key
            renderMarkers()
        }
    }

    private fun onMapTap(ll: LatLng) {
        var lat = ll.latitude
        var lon = ll.longitude
        var name: String? = null
        val m = maplibre
        if (m != null) {
            try {
                // If the tap is on a named place (POI), snap to that place.
                val pt = m.projection.toScreenLocation(ll)
                val r = dp(22).toFloat()
                val feats = m.queryRenderedFeatures(RectF(pt.x - r, pt.y - r, pt.x + r, pt.y + r))
                for (f in feats) {
                    val n = when {
                        f.hasProperty("name:en") -> f.getStringProperty("name:en")
                        f.hasProperty("name") -> f.getStringProperty("name")
                        else -> null
                    }
                    val gj = f.geometry()?.toJson()?.let { JSONObject(it) }
                    if (!n.isNullOrBlank() && gj != null && gj.optString("type") == "Point") {
                        val co = gj.getJSONArray("coordinates")
                        lon = co.getDouble(0)
                        lat = co.getDouble(1)
                        name = n
                        break
                    }
                }
            } catch (_: Exception) {
            }
        }
        setPin(lat, lon, false, name, 0.0)
    }

    private fun buildGpsTab(c: LinearLayout) {
        c.addView(label("Search a place or tap the map to drop a pin, then press Start."))

        // ---- search + suggestions ----
        etSearch = EditText(this).apply {
            hint = "Search place (e.g. Burj Khalifa)"
            inputType = InputType.TYPE_CLASS_TEXT
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_SEARCH) {
                    doSearch()
                    true
                } else false
            }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {}
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                    if (suppressWatch) return
                    ui.removeCallbacks(suggestRunnable)
                    val q = s?.toString()?.trim().orEmpty()
                    if (q.length < 3) {
                        searchGen++
                        suggestBox.removeAllViews()
                        return
                    }
                    suggestRunnable = Runnable { loadSuggestions(q) }
                    ui.postDelayed(suggestRunnable, 400)
                }
            })
        }
        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        searchRow.addView(etSearch)
        searchRow.addView(btn("Search") { doSearch() })
        c.addView(searchRow)
        suggestBox = vbox()
        c.addView(suggestBox)

        // ---- map ----
        mapView = MapView(this)
        mapView.onCreate(savedBundle)
        mapView.setOnTouchListener { v, _ ->
            v.parent.requestDisallowInterceptTouchEvent(true)
            false
        }
        tvCoords = label("No pin yet", 15f, true)

        val frame = FrameLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(420))
        }
        frame.addView(mapView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val fabLayers = fab(R.drawable.ic_layers) { anchor ->
            PopupMenu(this, anchor).apply {
                menu.add(0, 0, 0, "Street")
                menu.add(0, 1, 1, "Light")
                menu.add(0, 2, 2, "Hybrid")
                menu.add(0, 3, 3, "Satellite")
                menu.add(0, 4, 4, "Terrain")
                menu.add(0, 5, 5, "Dark")
                setOnMenuItemClickListener { applyLayer(it.itemId); true }
                show()
            }
        }
        frame.addView(fabLayers, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP or Gravity.RIGHT).apply {
            setMargins(0, dp(10), dp(10), 0)
        })

        val fabLocate = fab(R.drawable.ic_my_location) { recenter() }
        frame.addView(fabLocate, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.BOTTOM or Gravity.RIGHT).apply {
            setMargins(0, 0, dp(10), dp(36))
        })

        c.addView(frame)
        c.addView(tvCoords)

        layerIdx = prefs.getInt("layer", 0)
        val sLat = prefs.getString("pin_lat", null)?.toDoubleOrNull()
        val sLon = prefs.getString("pin_lon", null)?.toDoubleOrNull()
        if (sLat != null && sLon != null) {
            pinLat = sLat
            pinLon = sLon
            tvCoords.text = String.format(Locale.US, "📌 %.6f , %.6f", sLat, sLon)
        }

        mapView.getMapAsync { m ->
            maplibre = m
            m.uiSettings.isRotateGesturesEnabled = true
            m.uiSettings.isTiltGesturesEnabled = false
            val la = pinLat
            val lo = pinLon
            m.cameraPosition = CameraPosition.Builder()
                .target(if (la != null && lo != null) LatLng(la, lo) else LatLng(25.2048, 55.2708)) // Dubai
                .zoom(if (la != null) 15.0 else 10.5)
                .build()
            m.addOnMapClickListener { ll ->
                onMapTap(ll)
                true
            }
            applyLayer(layerIdx)
        }

        swRealism = Switch(this).apply {
            text = "Realistic mode (natural few-meter drift, varying accuracy and altitude)"
            isChecked = prefs.getBoolean("realism", true)
        }
        swWatch = Switch(this).apply {
            text = "Watchdog: check every 1 minute + alarm and auto-reconnect"
            isChecked = prefs.getBoolean("watchdog", true)
        }
        c.addView(swRealism)
        c.addView(swWatch)

        // ---- Kill switch ----
        c.addView(label("🛑 Kill switch", 18f, true))
        c.addView(label(
            "If the location test reports a failure, FakeGeo can temporarily block network traffic " +
                "for apps you explicitly select, using Android's local VPN permission. This can reduce " +
                "network-based disclosure while the test is unhealthy, but it cannot stop an app or the " +
                "operating system from reading location locally and cannot guarantee that real location " +
                "will never be disclosed.\\n" +
                "Choose at least one protected app. Android allows only one VPN at a time; enabling this " +
                "feature may disconnect another VPN."
        ))
        swKill = Switch(this).apply {
            text = "Enable kill switch"
            isChecked = prefs.getBoolean("ks_enabled", false)
        }
        swSound = Switch(this).apply {
            text = "Loud alarm when the location fails"
            isChecked = prefs.getBoolean("ks_sound", true)
        }
        tvKsApps = label("")
        c.addView(swKill)
        c.addView(swSound)
        c.addView(tvKsApps)
        c.addView(secondaryBtn("Choose apps to protect") { pickApps() })
        c.addView(secondaryBtn("Test kill switch (5 s)") {
            if (savedApps().isEmpty()) {
                toast("Choose at least one protected app first")
                return@secondaryBtn
            }
            if (VpnService.prepare(this) != null) {
                ensureVpn()
                return@secondaryBtn
            }
            KillSwitch.block(this)
            toast("Protected apps are blocked for 5 seconds…")
            ui.postDelayed({ if (!MockState.running) KillSwitch.unblock(this) }, 5000)
        })
        swKill.setOnCheckedChangeListener { _, on ->
            if (on && savedApps().isEmpty()) {
                swKill.isChecked = false
                prefs.edit().putBoolean("ks_enabled", false).apply()
                AlertDialog.Builder(this)
                    .setTitle("Choose protected apps")
                    .setMessage("Select one or more apps first. FakeGeo will never block the whole phone by default.")
                    .setPositiveButton("Choose apps") { _, _ -> pickApps() }
                    .setNegativeButton("Cancel", null)
                    .show()
                return@setOnCheckedChangeListener
            }
            prefs.edit().putBoolean("ks_enabled", on).apply()
            if (on) ensureVpn() else if (KillSwitch.blocking) KillSwitch.unblock(this)
        }
        swSound.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("ks_sound", on).apply()
        }
        refreshKsApps()
        if (savedApps().isEmpty() && swKill.isChecked) {
            swKill.isChecked = false
            prefs.edit().putBoolean("ks_enabled", false).apply()
        }

        c.addView(btn("▶ Start location test") { startMock() })
        c.addView(dangerBtn("⏹ Stop test") {
            prefs.edit().putBoolean("active", false).apply()
            stopService(Intent(this, MockLocationService::class.java))
            MockState.running = false
        })
        tvStatus = label("")
        c.addView(tvStatus)
        tvEvents = label("", 12f)
        c.addView(tvEvents)

        c.addView(label("🔒 Keep it from being stopped", 18f, true))
        c.addView(label(
            "1) FakeGeo must be selected as the mock location app.\n" +
                "2) Turn off battery optimization for FakeGeo (button below).\n" +
                "3) Lock the app in Recents and exclude it from task killers / cleaners.\n" +
                "4) Settings > Location > turn off Wi-Fi scanning and Bluetooth scanning.\n" +
                "5) Settings > Location > Location services > turn off Google Location Accuracy."
        ))
        c.addView(secondaryBtn("Open Developer options") {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            } catch (e: Exception) {
                toast("Developer options are off. Settings > About phone > tap Build number 7 times.")
            }
        })
        c.addView(secondaryBtn("Turn off battery optimization") { batterySettings() })

        c.addView(label("🕘 Pin history", 18f, true))
        historyBox = vbox()
        c.addView(historyBox)
        c.addView(dangerBtn("Delete all history") {
            AlertDialog.Builder(this)
                .setMessage("Delete all pin history?")
                .setPositiveButton("Delete") { _, _ ->
                    PinStore.clear(this)
                    refreshHistory()
                }
                .setNegativeButton("Cancel", null)
                .show()
        })
        refreshHistory()
    }

    // ======================= Search =======================

    private data class Place(val title: String, val subtitle: String, val lat: Double, val lon: Double)

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(etSearch.windowToken, 0)
    }

    /** Photon (OpenStreetMap data, made for search-as-you-type, no API key). */
    private fun photon(q: String, limit: Int, biasLat: Double?, biasLon: Double?): List<Place>? {
        return try {
            var url = "https://photon.komoot.io/api/?lang=en&limit=$limit&q=" + URLEncoder.encode(q, "UTF-8")
            if (biasLat != null && biasLon != null) url += "&lat=$biasLat&lon=$biasLon"
            val arr = JSONObject(httpGet(url)).getJSONArray("features")
            val out = ArrayList<Place>()
            for (i in 0 until arr.length()) {
                val f = arr.getJSONObject(i)
                val p = f.getJSONObject("properties")
                val co = f.getJSONObject("geometry").getJSONArray("coordinates")
                val name = p.optString("name")
                val street = listOf(p.optString("street"), p.optString("housenumber"))
                    .filter { it.isNotBlank() }.joinToString(" ")
                val title = if (name.isNotBlank()) name else street.ifBlank { p.optString("city") }
                val sub = listOf(
                    if (name.isNotBlank()) street else "",
                    p.optString("district"), p.optString("city"), p.optString("state"), p.optString("country")
                ).filter { it.isNotBlank() && it != title }.distinct().joinToString(", ")
                if (title.isNotBlank()) out.add(Place(title, sub, co.getDouble(1), co.getDouble(0)))
            }
            out
        } catch (e: Exception) {
            null
        }
    }

    private fun nominatim(q: String): Place? {
        return try {
            val url = "https://nominatim.openstreetmap.org/search?format=json&limit=1&accept-language=en&q=" +
                URLEncoder.encode(q, "UTF-8")
            val arr = JSONArray(httpGet(url))
            if (arr.length() > 0) {
                val o = arr.getJSONObject(0)
                val dn = o.optString("display_name")
                Place(
                    dn.substringBefore(","), dn.substringAfter(",", "").trim(),
                    o.getString("lat").toDouble(), o.getString("lon").toDouble()
                )
            } else null
        } catch (e: Exception) {
            null
        }
    }

    private fun mapCenter(): LatLng? = try { maplibre?.cameraPosition?.target } catch (_: Exception) { null }

    private fun loadSuggestions(q: String) {
        val gen = ++searchGen
        val c = mapCenter()
        Thread {
            val list = photon(q, 6, c?.latitude, c?.longitude)
            runOnUiThread { if (gen == searchGen) showSuggestions(list) }
        }.start()
    }

    private fun showSuggestions(list: List<Place>?) {
        suggestBox.removeAllViews()
        if (list == null) {
            suggestBox.addView(label("Search is unavailable. Check your internet connection.", 12f))
            return
        }
        if (list.isEmpty()) {
            suggestBox.addView(label("No results", 12f))
            return
        }
        for (p in list) {
            val tv = TextView(this).apply {
                text = if (p.subtitle.isBlank()) p.title else p.title + "\n" + p.subtitle
                textSize = 14f
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setBackgroundColor(Color.parseColor("#F1F3F4"))
                setOnClickListener { selectPlace(p) }
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, 0, dp(2))
            suggestBox.addView(tv, lp)
        }
    }

    private fun selectPlace(p: Place) {
        suppressWatch = true
        etSearch.setText(p.title)
        etSearch.setSelection(etSearch.text.length)
        suppressWatch = false
        searchGen++
        suggestBox.removeAllViews()
        hideKeyboard()
        setPin(p.lat, p.lon, true, p.title, 17.0)
    }

    private fun doSearch() {
        val q = etSearch.text.toString().trim()
        if (q.isEmpty()) return
        ui.removeCallbacks(suggestRunnable)
        hideKeyboard()
        val c = mapCenter()
        Thread {
            val place = photon(q, 1, c?.latitude, c?.longitude)?.firstOrNull() ?: nominatim(q)
            runOnUiThread {
                if (place == null) toast("Place not found (or no internet).") else selectPlace(place)
            }
        }.start()
    }

    // ======================= Pin / camera =======================

    private fun setPin(lat: Double, lon: Double, center: Boolean, name: String?, zoom: Double) {
        pinLat = lat
        pinLon = lon
        pinName = name
        val coords = String.format(Locale.US, "%.6f , %.6f", lat, lon)
        tvCoords.text = if (name.isNullOrBlank()) "📌 $coords" else "📌 $name\n$coords"
        renderMarkers()
        val m = maplibre
        if (center && m != null) {
            val ll = LatLng(lat, lon)
            m.animateCamera(
                if (zoom > 0.0) CameraUpdateFactory.newLatLngZoom(ll, zoom) else CameraUpdateFactory.newLatLng(ll)
            )
        }
    }

    private fun recenter() {
        val m = maplibre ?: return
        val a = activePoint()
        val t: Pair<Double, Double>? = when {
            a != null -> a
            pinLat != null && pinLon != null -> Pair(pinLat!!, pinLon!!)
            else -> null
        }
        if (t == null) {
            toast("No location selected yet")
            return
        }
        val z = maxOf(m.cameraPosition.zoom, 16.0)
        m.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(t.first, t.second), z))
    }

    private fun startMock() {
        val la = pinLat
        val lo = pinLon
        if (la == null || lo == null) {
            toast("Drop a pin on the map first")
            return
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
            return
        }
        prefs.edit()
            .putString("pin_lat", la.toString())
            .putString("pin_lon", lo.toString())
            .putString("acc", "5")
            .putBoolean("realism", swRealism.isChecked)
            .putBoolean("watchdog", swWatch.isChecked)
            .putBoolean("active", true)
            .apply()
        PinStore.add(this, Pin(la, lo, System.currentTimeMillis()))
        refreshHistory()
        MockState.error = null
        startForegroundService(
            Intent(this, MockLocationService::class.java).setAction(MockLocationService.ACTION_START)
        )
    }

    private fun refreshHistory() {
        historyBox.removeAllViews()
        val list = PinStore.load(this)
        if (list.isEmpty()) {
            historyBox.addView(label("Nothing saved yet"))
            return
        }
        val fmt = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US)
        list.forEachIndexed { idx, pin ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tv = TextView(this).apply {
                text = String.format(Locale.US, "📍 %.5f , %.5f\n%s", pin.lat, pin.lon, fmt.format(Date(pin.time)))
                textSize = 13f
                setPadding(0, dp(6), 0, dp(6))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    setPin(pin.lat, pin.lon, true, null, 16.0)
                    toast("Pin placed on the map. Press Start.")
                }
            }
            val del = Button(this).apply {
                text = "🗑 Delete"
                isAllCaps = false
                setOnClickListener {
                    PinStore.remove(this@MainActivity, idx)
                    refreshHistory()
                }
            }
            row.addView(tv)
            row.addView(del)
            historyBox.addView(row)
        }
    }

    private fun batterySettings() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (pm.isIgnoringBatteryOptimizations(packageName)) {
                toast("Battery optimization is already off ✅")
                return
            }
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                toast("In battery settings, set FakeGeo to Unrestricted")
            }
        }
    }

    // ======================= IP tab =======================

    private data class IpInfo(
        val ip: String, val country: String, val code: String, val region: String,
        val city: String, val isp: String, val tz: String, val lat: Double?, val lon: Double?
    )

    private data class Usage(val type: String, val flags: String)

    private fun buildIpTab(c: LinearLayout) {
        c.addView(label("The internet IP you are connected through (what websites and apps see)"))
        tvIpInfo = TextView(this).apply {
            textSize = 14f
            typeface = Typeface.MONOSPACE
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            textDirection = View.TEXT_DIRECTION_LTR
            gravity = Gravity.LEFT
            setPadding(dp(4), dp(8), dp(4), dp(8))
            text = "—"
        }
        c.addView(tvIpInfo)
        tvIpCompare = label("")
        c.addView(tvIpCompare)
        c.addView(btn("🔄 Refresh IP") { fetchIp() })
        c.addView(label(
            "Note: fake GPS and fake SIM do not change your IP. If the IP country differs " +
                "from the SIM country, use a VPN with an IP from the same country."
        ))
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "FakeGeo/1.4 (personal use)")
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun dbl(o: JSONObject, k: String): Double? =
        o.optDouble(k, Double.NaN).takeIf { !it.isNaN() }

    private fun lookupIp(): IpInfo? {
        try {
            val o = JSONObject(httpGet("https://ipwho.is/"))
            if (o.optBoolean("success", false)) {
                return IpInfo(
                    o.optString("ip"), o.optString("country"), o.optString("country_code"),
                    o.optString("region"), o.optString("city"),
                    o.optJSONObject("connection")?.optString("isp") ?: "",
                    o.optJSONObject("timezone")?.optString("id") ?: "",
                    dbl(o, "latitude"), dbl(o, "longitude")
                )
            }
        } catch (_: Exception) {
        }
        try {
            val o = JSONObject(httpGet("https://ipapi.co/json/"))
            if (o.has("ip") && !o.has("error")) {
                return IpInfo(
                    o.optString("ip"), o.optString("country_name"), o.optString("country_code"),
                    o.optString("region"), o.optString("city"), o.optString("org"),
                    o.optString("timezone"), dbl(o, "latitude"), dbl(o, "longitude")
                )
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun yn(b: Boolean) = if (b) "Yes" else "No"

    private fun usageFromIpapiIs(): Usage? {
        val o = JSONObject(httpGet("https://api.ipapi.is/"))
        if (!o.has("ip")) return null
        val ct = o.optJSONObject("company")?.optString("type").orEmpty()
        val at = o.optJSONObject("asn")?.optString("type").orEmpty()
        val t = (if (ct.isNotEmpty()) ct else at).lowercase(Locale.US)
        val type = when {
            o.optBoolean("is_mobile", false) -> "Mobile (Cellular)"
            o.optBoolean("is_datacenter", false) -> "Data Center / Hosting"
            t == "isp" -> "ISP (Residential / Broadband)"
            t == "hosting" -> "Data Center / Hosting"
            t == "business" -> "Business"
            t == "education" -> "Education"
            t == "government" -> "Government"
            t == "banking" -> "Banking"
            t.isNotEmpty() -> t.replaceFirstChar { it.uppercase() }
            else -> return null
        }
        return Usage(
            type,
            "VPN: ${yn(o.optBoolean("is_vpn", false))} | Proxy: ${yn(o.optBoolean("is_proxy", false))} | " +
                "Tor: ${yn(o.optBoolean("is_tor", false))}"
        )
    }

    private fun usageFromIpApi(): Usage? {
        val o = JSONObject(httpGet("http://ip-api.com/json/?fields=status,mobile,proxy,hosting"))
        if (o.optString("status") != "success") return null
        val type = when {
            o.optBoolean("mobile", false) -> "Mobile (Cellular)"
            o.optBoolean("hosting", false) -> "Data Center / Hosting"
            else -> "ISP / Residential / Business"
        }
        return Usage(type, "Proxy/VPN: ${yn(o.optBoolean("proxy", false))} | Hosting: ${yn(o.optBoolean("hosting", false))}")
    }

    /** Last resort: guess from the ISP name. */
    private fun usageGuess(isp: String): Usage {
        val s = isp.lowercase(Locale.US)
        if (s.isBlank()) return Usage("Unknown", "—")
        val hosting = listOf(
            "hosting", "cloud", "datacenter", "data center", "server", "vps", "amazon", "aws", "google",
            "microsoft", "azure", "digitalocean", "ovh", "hetzner", "linode", "vultr", "oracle", "contabo",
            "leaseweb", "cdn", "choopa", "m247"
        )
        val mobile = listOf("mobile", "cellular", "wireless", "lte")
        val type = when {
            hosting.any { s.contains(it) } -> "Data Center / Hosting (guess)"
            mobile.any { s.contains(it) } -> "Mobile (Cellular) (guess)"
            else -> "ISP (guess)"
        }
        return Usage(type, "—")
    }

    private fun lookupUsage(isp: String): Usage {
        try { usageFromIpapiIs()?.let { return it } } catch (_: Exception) {}
        try { usageFromIpApi()?.let { return it } } catch (_: Exception) {}
        return usageGuess(isp)
    }

    private fun flag(code: String): String {
        if (code.length != 2) return "🏳"
        val up = code.uppercase(Locale.US)
        if (up.any { it !in 'A'..'Z' }) return "🏳"
        return String(Character.toChars(0x1F1E6 + (up[0] - 'A'))) +
            String(Character.toChars(0x1F1E6 + (up[1] - 'A')))
    }

    private fun fetchIp() {
        tvIpInfo.text = "Loading…"
        tvIpCompare.text = ""
        Thread {
            val r = try { lookupIp() } catch (e: Exception) { null }
            val u = lookupUsage(r?.isp.orEmpty())
            runOnUiThread { showIp(r, u) }
        }.start()
    }

    private fun showIp(r: IpInfo?, u: Usage) {
        if (r == null) {
            tvIpInfo.text = "Could not get IP info.\nCheck your internet connection."
            tvIpCompare.text = ""
            return
        }
        ipLoaded = true
        val sb = StringBuilder()
        sb.append("IP         : ${r.ip}\n")
        sb.append("Country    : ${flag(r.code)} ${r.country} (${r.code})\n")
        sb.append("City       : ${r.city}\n")
        sb.append("Region     : ${r.region}\n")
        sb.append("ISP        : ${r.isp}\n")
        sb.append("Usage type : ${u.type}\n")
        sb.append("Flags      : ${u.flags}\n")
        sb.append("Timezone   : ${r.tz}\n")
        if (r.lat != null && r.lon != null) {
            sb.append(String.format(Locale.US, "Lat/Lon    : %.4f , %.4f", r.lat, r.lon))
        }
        tvIpInfo.text = sb.toString()

        val sim = BuildConfig.SIM_COUNTRY.uppercase(Locale.US)
        tvIpCompare.text = if (r.code.equals(sim, ignoreCase = true)) {
            "✅ IP country ($sim) matches the fake SIM country"
        } else {
            "⚠️ IP country (${r.code}) differs from the fake SIM country ($sim)"
        }
    }

    // ======================= SIM tab =======================

    private fun buildSimTab(c: LinearLayout) {
        c.addView(label("📶 SIM module for LSPatch", 18f, true))
        val number = if (BuildConfig.SIM_NUMBER.isBlank()) "(not set — real number is visible)" else BuildConfig.SIM_NUMBER
        c.addView(label(
            "What patched apps will see (set at build time):\n" +
                "• Country: ${BuildConfig.SIM_COUNTRY.uppercase()}\n" +
                "• MCC+MNC: ${BuildConfig.SIM_MCCMNC}\n" +
                "• Operator: ${BuildConfig.SIM_OPERATOR_NAME}\n" +
                "• Number: $number\n\n" +
                "These values only apply inside apps patched with LSPatch using this module. " +
                "After every new build, patch the target app again."
        ))
    }

    // ======================= general =======================

    // ======================= Kill switch helpers =======================

    private fun savedApps(): Set<String> =
        prefs.getStringSet("ks_apps", emptySet())?.toSet().orEmpty()

    private fun refreshKsApps() {
        val n = savedApps().size
        tvKsApps.text = if (n == 0) {
            "Protected apps: none selected. Kill switch is inactive until you choose apps."
        } else {
            "Protected apps: $n selected"
        }
    }

    private fun ensureVpn() {
        val i = VpnService.prepare(this)
        if (i != null) startActivityForResult(i, REQ_VPN)
    }

    private fun pickApps() {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase(Locale.US) }
        if (apps.isEmpty()) {
            toast("Could not list installed apps")
            return
        }
        val saved = savedApps()
        val checked = BooleanArray(apps.size) { apps[it].second in saved }
        AlertDialog.Builder(this)
            .setTitle("Apps to protect")
            .setMultiChoiceItems(apps.map { it.first }.toTypedArray(), checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton("Save") { _, _ ->
                val set = HashSet<String>()
                for (i in apps.indices) if (checked[i]) set.add(apps[i].second)
                prefs.edit().putStringSet("ks_apps", set).apply()
                if (set.isEmpty()) {
                    prefs.edit().putBoolean("ks_enabled", false).apply()
                    swKill.isChecked = false
                    if (KillSwitch.blocking) KillSwitch.unblock(this)
                }
                refreshKsApps()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN) {
            if (resultCode == RESULT_OK) {
                toast("Kill switch is ready ✅")
            } else {
                swKill.isChecked = false
                toast("VPN permission is required for the kill switch")
            }
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == 1) {
            if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startMock()
            else toast("Location permission is required for fake GPS")
        }
    }

    private fun updateStatus() {
        val err = MockState.error
        tvStatus.text = when {
            err != null -> "❌ $err"
            MockState.running -> "✅ Active at ${tvCoords.text.toString().substringAfterLast('\n')}"
            else -> "⏹ Inactive"
        }
        if (KillSwitch.blocking) {
            tvStatus.text = "🛑 KILL SWITCH IS BLOCKING the protected apps' internet\n" + tvStatus.text
        }
        tvEvents.text = MockState.recent().joinToString("\n")
        updateDot()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---- lifecycle (MapView needs all of these) ----
    override fun onStart() { super.onStart(); mapView.onStart() }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
        ui.post(refresh)
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
        ui.removeCallbacks(refresh)
    }

    override fun onStop() { super.onStop(); mapView.onStop() }

    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mapView.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        mapView.onDestroy()
        super.onDestroy()
    }
}
