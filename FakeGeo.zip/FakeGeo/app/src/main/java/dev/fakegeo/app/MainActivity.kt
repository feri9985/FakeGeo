package dev.fakegeo.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var etLat: EditText
    private lateinit var etLon: EditText
    private lateinit var etAcc: EditText
    private lateinit var swJitter: Switch
    private lateinit var tvStatus: TextView
    private val ui = Handler(Looper.getMainLooper())

    private val presets = listOf(
        Triple("دبی", 25.2048, 55.2708),
        Triple("استانبول", 41.0082, 28.9784),
        Triple("برلین", 52.5200, 13.4050),
        Triple("پاریس", 48.8566, 2.3522),
        Triple("لندن", 51.5074, -0.1278),
        Triple("نیویورک", 40.7128, -74.0060),
        Triple("توکیو", 35.6762, 139.6503)
    )

    private val refresh = object : Runnable {
        override fun run() {
            updateStatus()
            ui.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(s: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(8), 0, dp(4))
    }

    private fun btn(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s
        setOnClickListener { onClick() }
    }

    private fun field(hint: String, value: String) = EditText(this).apply {
        this.hint = hint
        setText(value)
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or
            InputType.TYPE_NUMBER_FLAG_SIGNED
        layoutDirection = View.LAYOUT_DIRECTION_LTR
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("fakegeo", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        setContentView(ScrollView(this).apply { addView(root) })

        // ---------- Fake GPS ----------
        root.addView(label("📍 فیک جی‌پی‌اس", 20f, true))
        root.addView(label("۱) یک‌بار: تنظیمات ▸ گزینه‌های توسعه‌دهنده ▸ Select mock location app ▸ FakeGeo"))
        root.addView(btn("باز کردن Developer options") {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            } catch (e: Exception) {
                toast("Developer options فعال نیست. Settings ▸ About phone ▸ 7 بار روی Build number بزن.")
            }
        })

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("— انتخاب شهر —") + presets.map { it.first }
        )
        root.addView(label("۲) شهر آماده یا مختصات دلخواه"))
        root.addView(spinner)

        etLat = field("Latitude", prefs.getString("lat", "25.2048")!!)
        etLon = field("Longitude", prefs.getString("lon", "55.2708")!!)
        etAcc = field("Accuracy (متر)", prefs.getString("acc", "5")!!)
        root.addView(label("Latitude (عرض جغرافیایی)")); root.addView(etLat)
        root.addView(label("Longitude (طول جغرافیایی)")); root.addView(etLon)
        root.addView(label("دقت (متر)")); root.addView(etAcc)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos > 0) {
                    val c = presets[pos - 1]
                    etLat.setText(c.second.toString())
                    etLon.setText(c.third.toString())
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        swJitter = Switch(this).apply {
            text = "لرزش کوچک (حدود ۱ متر) برای طبیعی‌تر شدن"
            isChecked = prefs.getBoolean("jitter", false)
        }
        root.addView(swJitter)

        root.addView(btn("▶ شروع") { startMock() })
        root.addView(btn("⏹ توقف") {
            stopService(Intent(this, MockLocationService::class.java))
            MockState.running = false
        })
        tvStatus = label("")
        root.addView(tvStatus)

        // ---------- SIM / LSPatch ----------
        root.addView(label("📶 ماژول SIM برای LSPatch", 20f, true))
        root.addView(label(
            "این اپ همزمان یک ماژول LSPatch هست. کشور SIM که اپ‌های پچ‌شده می‌بینن (تنظیم‌شده موقع بیلد):\n" +
                "• کشور: ${BuildConfig.SIM_COUNTRY.uppercase()}\n" +
                "• MCC+MNC: ${BuildConfig.SIM_MCCMNC}\n" +
                "• اپراتور: ${BuildConfig.SIM_OPERATOR_NAME}\n\n" +
                "برای عوض کردن این مقادیر، Workflow گیت‌هاب رو با مقدار جدید دوباره اجرا کن.\n" +
                "روش پچ کردن اپ هدف با LSPatch در فایل README توضیح داده شده."
        ))

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    private fun startMock() {
        val lat = etLat.text.toString().trim().replace(',', '.').toDoubleOrNull()
        val lon = etLon.text.toString().trim().replace(',', '.').toDoubleOrNull()
        val acc = etAcc.text.toString().trim().replace(',', '.').toFloatOrNull() ?: 5f
        if (lat == null || lon == null || lat !in -90.0..90.0 || lon !in -180.0..180.0) {
            toast("مختصات نامعتبره")
            return
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
            return
        }
        prefs.edit()
            .putString("lat", lat.toString()).putString("lon", lon.toString())
            .putString("acc", acc.toString()).putBoolean("jitter", swJitter.isChecked)
            .apply()
        MockState.error = null
        val i = Intent(this, MockLocationService::class.java)
            .setAction(MockLocationService.ACTION_START)
            .putExtra(MockLocationService.EXTRA_LAT, lat)
            .putExtra(MockLocationService.EXTRA_LON, lon)
            .putExtra(MockLocationService.EXTRA_ACC, acc)
            .putExtra(MockLocationService.EXTRA_JITTER, swJitter.isChecked)
        startForegroundService(i)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == 1) {
            if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startMock()
            else toast("برای فیک GPS دسترسی Location لازمه")
        }
    }

    private fun updateStatus() {
        val err = MockState.error
        tvStatus.text = when {
            err != null -> "❌ $err"
            MockState.running -> "✅ فعال: ${etLat.text} , ${etLon.text}"
            else -> "⏹ غیرفعال"
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onResume() { super.onResume(); ui.post(refresh) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(refresh) }
}
