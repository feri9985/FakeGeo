package dev.fakegeo.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.ITileSource
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var map: MapView
    private var marker: Marker? = null
    private var dotMarker: Marker? = null
    private var dotKey = ""
    private var pinLat: Double? = null
    private var pinLon: Double? = null

    private lateinit var tvCoords: TextView
    private lateinit var tvAttrib: TextView
    private lateinit var swRealism: Switch
    private lateinit var swWatch: Switch
    private lateinit var tvStatus: TextView
    private lateinit var tvEvents: TextView
    private lateinit var historyBox: LinearLayout
    private lateinit var tvIpInfo: TextView
    private lateinit var tvIpCompare: TextView

    private val tabs = mutableListOf<View>()
    private val tabButtons = mutableListOf<Button>()
    private var ipLoaded = false
    private val ui = Handler(Looper.getMainLooper())

    private val refresh = object : Runnable {
        override fun run() {
            updateStatus()
            ui.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(s: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(8), 0, dp(4))
    }

    private fun btn(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s
        setOnClickListener { onClick() }
    }

    private fun vbox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    // ======================= onCreate =======================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("fakegeo", MODE_PRIVATE)

        Configuration.getInstance().apply {
            load(applicationContext, getSharedPreferences("osmdroid", MODE_PRIVATE))
            userAgentValue = packageName
            osmdroidBasePath = File(cacheDir, "osmdroid")
            osmdroidTileCache = File(cacheDir, "osmdroid/tiles")
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(label("FakeGeo", 22f, true))

        // ---- نوار تب‌ها ----
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("📍 GPS", "🌐 IP", "📶 SIM")
        names.forEachIndexed { i, n ->
            val b = Button(this).apply {
                text = n
                isAllCaps = false
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { showTab(i) }
            }
            tabButtons.add(b)
            bar.addView(b)
        }
        root.addView(bar)

        val tabGps = vbox()
        val tabIp = vbox()
        val tabSim = vbox()
        tabs.addAll(listOf(tabGps, tabIp, tabSim))
        tabs.forEach { root.addView(it) }

        buildGpsTab(tabGps)
        buildIpTab(tabIp)
        buildSimTab(tabSim)

        // ---- امضا ----
        val year = Calendar.getInstance().get(Calendar.YEAR)
        root.addView(TextView(this).apply {
            text = "© $year Farhad rgb — All rights reserved\nساخته‌شده توسط Farhad rgb"
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        })

        showTab(prefs.getInt("tab", 0))

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    private fun showTab(i: Int) {
        tabs.forEachIndexed { idx, v -> v.visibility = if (idx == i) View.VISIBLE else View.GONE }
        tabButtons.forEachIndexed { idx, b ->
            if (idx == i) {
                b.setBackgroundColor(Color.parseColor("#1565C0"))
                b.setTextColor(Color.WHITE)
            } else {
                b.setBackgroundColor(Color.parseColor("#E0E0E0"))
                b.setTextColor(Color.BLACK)
            }
        }
        prefs.edit().putInt("tab", i).apply()
        if (i == 1 && !ipLoaded) fetchIp()
    }

    // ======================= تب GPS =======================

    private fun fab(iconRes: Int, onClick: (View) -> Unit) = ImageButton(this).apply {
        setImageResource(iconRes)
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.WHITE)
            setStroke(dp(1), Color.parseColor("#22000000"))
        }
        elevation = dp(4).toFloat()
        scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setOnClickListener { onClick(it) }
    }

    private fun layerSource(i: Int): ITileSource = when (i) {
        1 -> object : OnlineTileSourceBase(
            "EsriSatellite", 0, 19, 256, ".jpg",
            arrayOf("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"),
            "Tiles © Esri"
        ) {
            override fun getTileURLString(pMapTileIndex: Long): String =
                baseUrl + MapTileIndex.getZoom(pMapTileIndex) + "/" +
                    MapTileIndex.getY(pMapTileIndex) + "/" + MapTileIndex.getX(pMapTileIndex)
        }
        2 -> XYTileSource(
            "OpenTopoMap", 0, 17, 256, ".png",
            arrayOf(
                "https://a.tile.opentopomap.org/",
                "https://b.tile.opentopomap.org/",
                "https://c.tile.opentopomap.org/"
            ),
            "© OpenStreetMap, SRTM | © OpenTopoMap"
        )
        3 -> XYTileSource(
            "CartoDark", 0, 20, 256, ".png",
            arrayOf(
                "https://a.basemaps.cartocdn.com/dark_all/",
                "https://b.basemaps.cartocdn.com/dark_all/"
            ),
            "© OpenStreetMap © CARTO"
        )
        else -> XYTileSource( // نقشه‌ی استاندارد با نام‌های انگلیسی
            "CartoVoyager", 0, 20, 256, ".png",
            arrayOf(
                "https://a.basemaps.cartocdn.com/rastertiles/voyager/",
                "https://b.basemaps.cartocdn.com/rastertiles/voyager/"
            ),
            "© OpenStreetMap © CARTO"
        )
    }

    private fun applyLayer(i: Int) {
        val src = layerSource(i)
        map.setTileSource(src)
        tvAttrib.text = src.copyrightNotice
        prefs.edit().putInt("layer", i).apply()
    }

    private fun buildGpsTab(c: LinearLayout) {
        c.addView(label("روی نقشه بزن تا پین بذاری. بعد «شروع» رو بزن."))

        map = MapView(this).apply {
            setMultiTouchControls(true)
            controller.setZoom(15.0)
            setOnTouchListener { v, _ ->
                v.parent.requestDisallowInterceptTouchEvent(true)
                false
            }
        }
        tvCoords = label("هنوز پینی نذاشتی", 15f, true)

        val frame = FrameLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380))
        }
        frame.addView(map, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        tvAttrib = TextView(this).apply {
            textSize = 9f
            setTextColor(Color.parseColor("#444444"))
            setBackgroundColor(Color.parseColor("#B3FFFFFF"))
            setPadding(dp(4), dp(1), dp(4), dp(1))
        }
        frame.addView(tvAttrib, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.LEFT
        ))

        // دکمه‌ی تغییر نوع نقشه (بالا راست)
        val fabLayers = fab(R.drawable.ic_layers) { anchor ->
            PopupMenu(this, anchor).apply {
                menu.add(0, 0, 0, "Standard (English)")
                menu.add(0, 1, 1, "Satellite")
                menu.add(0, 2, 2, "Terrain")
                menu.add(0, 3, 3, "Dark")
                setOnMenuItemClickListener { applyLayer(it.itemId); true }
                show()
            }
        }
        frame.addView(fabLayers, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP or Gravity.RIGHT).apply {
            setMargins(0, dp(10), dp(10), 0)
        })

        // دکمه‌ی برگشت سریع به نقطه (پایین راست)
        val fabLocate = fab(R.drawable.ic_my_location) { recenter() }
        frame.addView(fabLocate, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.BOTTOM or Gravity.RIGHT).apply {
            setMargins(0, 0, dp(10), dp(26))
        })

        c.addView(frame)
        c.addView(tvCoords)

        applyLayer(prefs.getInt("layer", 0))

        map.overlays.add(MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                setPin(p.latitude, p.longitude, false)
                return true
            }
            override fun longPressHelper(p: GeoPoint): Boolean = false
        }))

        val sLat = prefs.getString("pin_lat", null)?.toDoubleOrNull()
        val sLon = prefs.getString("pin_lon", null)?.toDoubleOrNull()
        if (sLat != null && sLon != null) {
            setPin(sLat, sLon, false)
            map.controller.setCenter(GeoPoint(sLat, sLon))
        } else {
            map.controller.setCenter(GeoPoint(25.2048, 55.2708)) // Dubai
        }

        swRealism = Switch(this).apply {
            text = "حالت واقعی‌نما (نوسان طبیعی چند متری، دقت و ارتفاع متغیر)"
            isChecked = prefs.getBoolean("realism", true)
        }
        swWatch = Switch(this).apply {
            text = "نگهبان: هر ۱ دقیقه بررسی + آلارم و اتصال دوباره"
            isChecked = prefs.getBoolean("watchdog", true)
        }
        c.addView(swRealism)
        c.addView(swWatch)

        c.addView(btn("▶ شروع") { startMock() })
        c.addView(btn("⏹ توقف") {
            prefs.edit().putBoolean("active", false).apply()
            stopService(Intent(this, MockLocationService::class.java))
            MockState.running = false
        })
        tvStatus = label("")
        c.addView(tvStatus)
        tvEvents = label("", 12f)
        c.addView(tvEvents)

        c.addView(label("🔒 جلوگیری از قطع شدن", 18f, true))
        c.addView(label(
            "۱) FakeGeo باید Mock location app باشه.\n" +
                "۲) بهینه‌سازی باتری رو برای FakeGeo خاموش کن (دکمه‌ی پایین).\n" +
                "۳) اپ رو توی Recent قفل کن و از Task Killer یا Clean استثنا کن.\n" +
                "۴) برای کامل‌تر شدن: Settings ▸ Location ▸ Wi-Fi scanning و Bluetooth scanning رو خاموش کن."
        ))
        c.addView(btn("باز کردن Developer options") {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            } catch (e: Exception) {
                toast("Developer options فعال نیست. Settings ▸ About phone ▸ ۷ بار روی Build number بزن.")
            }
        })
        c.addView(btn("خاموش کردن بهینه‌سازی باتری") { batterySettings() })

        c.addView(label("🕘 تاریخچه‌ی پین‌ها", 18f, true))
        historyBox = vbox()
        c.addView(historyBox)
        c.addView(btn("حذف همه‌ی تاریخچه") {
            AlertDialog.Builder(this)
                .setMessage("همه‌ی تاریخچه حذف بشه؟")
                .setPositiveButton("حذف") { _, _ ->
                    PinStore.clear(this)
                    refreshHistory()
                }
                .setNegativeButton("لغو", null)
                .show()
        })
        refreshHistory()
    }

    private fun setPin(lat: Double, lon: Double, center: Boolean) {
        pinLat = lat
        pinLon = lon
        val gp = GeoPoint(lat, lon)
        var m = marker
        if (m == null) {
            m = Marker(map)
            m.icon = getDrawable(R.drawable.ic_pin)
            m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            m.setOnMarkerClickListener { _, _ -> true }
            map.overlays.add(m)
            marker = m
        }
        m.position = gp
        if (center) map.controller.animateTo(gp)
        map.invalidate()
        tvCoords.text = String.format(Locale.US, "📌 %.6f , %.6f", lat, lon)
    }

    /** نقطه‌ی آبی = جایی که فیک GPS الان فعاله */
    private fun updateDot() {
        val la = prefs.getString("pin_lat", null)?.toDoubleOrNull()
        val lo = prefs.getString("pin_lon", null)?.toDoubleOrNull()
        val key = if (MockState.running && la != null && lo != null) "$la,$lo" else ""
        if (key == dotKey) return
        dotKey = key
        var d = dotMarker
        if (key.isEmpty()) {
            if (d != null) map.overlays.remove(d)
            dotMarker = null
            map.invalidate()
            return
        }
        if (d == null) {
            d = Marker(map)
            d.icon = getDrawable(R.drawable.ic_dot)
            d.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            d.setOnMarkerClickListener { _, _ -> true }
            map.overlays.add(d)
            dotMarker = d
        }
        d.position = GeoPoint(la!!, lo!!)
        map.invalidate()
    }

    /** برگشت سریع نقشه به نقطه‌ی فعال (یا پین انتخابی) */
    private fun recenter() {
        val la = prefs.getString("pin_lat", null)?.toDoubleOrNull()
        val lo = prefs.getString("pin_lon", null)?.toDoubleOrNull()
        val target: GeoPoint? = when {
            MockState.running && la != null && lo != null -> GeoPoint(la, lo)
            pinLat != null && pinLon != null -> GeoPoint(pinLat!!, pinLon!!)
            else -> null
        }
        if (target == null) {
            toast("هنوز نقطه‌ای انتخاب نشده")
            return
        }
        map.controller.animateTo(target)
        if (map.zoomLevelDouble < 15.0) map.controller.setZoom(16.0)
    }

    private fun startMock() {
        val la = pinLat
        val lo = pinLon
        if (la == null || lo == null) {
            toast("اول روی نقشه پین بذار")
            return
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
            return
        }
        prefs.edit()
            .putString("pin_lat", la.toString())
            .putString("pin_lon", lo.toString())
            .putString("acc", "5")
            .putBoolean("realism", swRealism.isChecked)
            .putBoolean("watchdog", swWatch.isChecked)
            .putBoolean("active", true)
            .apply()
        PinStore.add(this, Pin(la, lo, System.currentTimeMillis()))
        refreshHistory()
        MockState.error = null
        startForegroundService(
            Intent(this, MockLocationService::class.java).setAction(MockLocationService.ACTION_START)
        )
    }

    private fun refreshHistory() {
        historyBox.removeAllViews()
        val list = PinStore.load(this)
        if (list.isEmpty()) {
            historyBox.addView(label("هنوز چیزی ذخیره نشده"))
            return
        }
        val fmt = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US)
        list.forEachIndexed { idx, pin ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tv = TextView(this).apply {
                text = String.format(Locale.US, "📍 %.5f , %.5f\n%s", pin.lat, pin.lon, fmt.format(Date(pin.time)))
                textSize = 13f
                setPadding(0, dp(6), 0, dp(6))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    setPin(pin.lat, pin.lon, true)
                    toast("پین روی نقشه گذاشته شد. «شروع» رو بزن.")
                }
            }
            val del = Button(this).apply {
                text = "🗑 حذف"
                setOnClickListener {
                    PinStore.remove(this@MainActivity, idx)
                    refreshHistory()
                }
            }
            row.addView(tv)
            row.addView(del)
            historyBox.addView(row)
        }
    }

    private fun batterySettings() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (pm.isIgnoringBatteryOptimizations(packageName)) {
                toast("بهینه‌سازی باتری از قبل خاموشه ✅")
                return
            }
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                toast("از تنظیمات باتری گوشی، FakeGeo رو روی Unrestricted بذار")
            }
        }
    }

    // ======================= تب IP =======================

    private data class IpInfo(
        val ip: String, val country: String, val code: String, val region: String,
        val city: String, val isp: String, val tz: String, val lat: Double?, val lon: Double?
    )

    private fun buildIpTab(c: LinearLayout) {
        c.addView(label("IP اینترنتی که الان بهش وصلی (همون چیزی که سایت‌ها و اپ‌ها می‌بینن)"))
        tvIpInfo = TextView(this).apply {
            textSize = 15f
            typeface = Typeface.MONOSPACE
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            textDirection = View.TEXT_DIRECTION_LTR
            gravity = Gravity.LEFT
            setPadding(dp(4), dp(8), dp(4), dp(8))
            text = "—"
        }
        c.addView(tvIpInfo)
        tvIpCompare = label("")
        c.addView(tvIpCompare)
        c.addView(btn("🔄 بروزرسانی IP") { fetchIp() })
        c.addView(label(
            "نکته: فیک GPS و فیک SIM روی IP اثری ندارن. اگه IP با کشور SIM فرق داشت، " +
                "برای هم‌خوانی از VPN با IP همون کشور استفاده کن."
        ))
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "FakeGeo/1.2")
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun dbl(o: JSONObject, k: String): Double? =
        o.optDouble(k, Double.NaN).takeIf { !it.isNaN() }

    private fun lookupIp(): IpInfo? {
        try {
            val o = JSONObject(httpGet("https://ipwho.is/"))
            if (o.optBoolean("success", false)) {
                return IpInfo(
                    o.optString("ip"), o.optString("country"), o.optString("country_code"),
                    o.optString("region"), o.optString("city"),
                    o.optJSONObject("connection")?.optString("isp") ?: "",
                    o.optJSONObject("timezone")?.optString("id") ?: "",
                    dbl(o, "latitude"), dbl(o, "longitude")
                )
            }
        } catch (_: Exception) {
        }
        try {
            val o = JSONObject(httpGet("https://ipapi.co/json/"))
            if (o.has("ip") && !o.has("error")) {
                return IpInfo(
                    o.optString("ip"), o.optString("country_name"), o.optString("country_code"),
                    o.optString("region"), o.optString("city"), o.optString("org"),
                    o.optString("timezone"), dbl(o, "latitude"), dbl(o, "longitude")
                )
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun flag(code: String): String {
        if (code.length != 2) return "🏳"
        val up = code.uppercase(Locale.US)
        if (up.any { it !in 'A'..'Z' }) return "🏳"
        return String(Character.toChars(0x1F1E6 + (up[0] - 'A'))) +
            String(Character.toChars(0x1F1E6 + (up[1] - 'A')))
    }

    private fun fetchIp() {
        tvIpInfo.text = "Loading…"
        tvIpCompare.text = ""
        Thread {
            val r = try { lookupIp() } catch (e: Exception) { null }
            runOnUiThread { showIp(r) }
        }.start()
    }

    private fun showIp(r: IpInfo?) {
        if (r == null) {
            tvIpInfo.text = "Could not get IP info.\nCheck your internet connection."
            tvIpCompare.text = ""
            return
        }
        ipLoaded = true
        val sb = StringBuilder()
        sb.append("IP        : ${r.ip}\n")
        sb.append("Country   : ${flag(r.code)} ${r.country} (${r.code})\n")
        sb.append("City      : ${r.city}\n")
        sb.append("Region    : ${r.region}\n")
        sb.append("ISP       : ${r.isp}\n")
        sb.append("Timezone  : ${r.tz}\n")
        if (r.lat != null && r.lon != null) {
            sb.append(String.format(Locale.US, "Lat/Lon   : %.4f , %.4f", r.lat, r.lon))
        }
        tvIpInfo.text = sb.toString()

        val sim = BuildConfig.SIM_COUNTRY.uppercase(Locale.US)
        tvIpCompare.text = if (r.code.equals(sim, ignoreCase = true)) {
            "✅ کشور IP ($sim) با کشور SIM جعلی هم‌خوانه"
        } else {
            "⚠️ کشور IP (${r.code}) با کشور SIM جعلی ($sim) فرق داره"
        }
    }

    // ======================= تب SIM =======================

    private fun buildSimTab(c: LinearLayout) {
        c.addView(label("📶 ماژول SIM برای LSPatch", 18f, true))
        val number = if (BuildConfig.SIM_NUMBER.isBlank()) "(تنظیم نشده — شماره‌ی واقعی دیده می‌شه)" else BuildConfig.SIM_NUMBER
        c.addView(label(
            "اطلاعاتی که اپ‌های پچ‌شده می‌بینن (تنظیم‌شده موقع بیلد):\n" +
                "• کشور: ${BuildConfig.SIM_COUNTRY.uppercase()}\n" +
                "• MCC+MNC: ${BuildConfig.SIM_MCCMNC}\n" +
                "• اپراتور: ${BuildConfig.SIM_OPERATOR_NAME}\n" +
                "• شماره: $number\n\n" +
                "این مقادیر فقط داخل اپ‌هایی اثر دارن که با LSPatch و همین ماژول پچ شدن. " +
                "بعد از هر بیلد جدید، اپ هدف رو دوباره پچ کن."
        ))
    }

    // ======================= عمومی =======================

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == 1) {
            if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startMock()
            else toast("برای فیک GPS دسترسی Location لازمه")
        }
    }

    private fun updateStatus() {
        val err = MockState.error
        tvStatus.text = when {
            err != null -> "❌ $err"
            MockState.running -> "✅ فعال روی ${tvCoords.text}"
            else -> "⏹ غیرفعال"
        }
        tvEvents.text = MockState.recent().joinToString("\n")
        updateDot()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onResume() {
        super.onResume()
        map.onResume()
        ui.post(refresh)
    }

    override fun onPause() {
        super.onPause()
        map.onPause()
        ui.removeCallbacks(refresh)
    }

    override fun onDestroy() {
        map.onDetach()
        super.onDestroy()
    }
}
