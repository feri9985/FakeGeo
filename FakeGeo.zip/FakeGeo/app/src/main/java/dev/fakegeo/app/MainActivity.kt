package dev.fakegeo.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var map: MapView
    private var marker: Marker? = null
    private var pinLat: Double? = null
    private var pinLon: Double? = null

    private lateinit var tvCoords: TextView
    private lateinit var swRealism: Switch
    private lateinit var swWatch: Switch
    private lateinit var tvStatus: TextView
    private lateinit var tvEvents: TextView
    private lateinit var historyBox: LinearLayout
    private val ui = Handler(Looper.getMainLooper())

    private val refresh = object : Runnable {
        override fun run() {
            updateStatus()
            ui.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(s: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(8), 0, dp(4))
    }

    private fun btn(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("fakegeo", MODE_PRIVATE)

        Configuration.getInstance().apply {
            load(applicationContext, getSharedPreferences("osmdroid", MODE_PRIVATE))
            userAgentValue = packageName
            osmdroidBasePath = File(cacheDir, "osmdroid")
            osmdroidTileCache = File(cacheDir, "osmdroid/tiles")
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        setContentView(ScrollView(this).apply { addView(root) })

        // ---------- نقشه ----------
        root.addView(label("📍 فیک جی‌پی‌اس", 20f, true))
        root.addView(label("روی نقشه بزن تا پین بذاری. بعد «شروع» رو بزن."))

        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(15.0)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(340))
            // وقتی روی نقشه حرکت می‌کنی، صفحه اسکرول نشه
            setOnTouchListener { v, _ ->
                v.parent.requestDisallowInterceptTouchEvent(true)
                false
            }
        }
        root.addView(map)

        tvCoords = label("هنوز پینی نذاشتی", 15f, true)
        root.addView(tvCoords)

        map.overlays.add(MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                setPin(p.latitude, p.longitude, false)
                return true
            }
            override fun longPressHelper(p: GeoPoint): Boolean = false
        }))

        val sLat = prefs.getString("pin_lat", null)?.toDoubleOrNull()
        val sLon = prefs.getString("pin_lon", null)?.toDoubleOrNull()
        if (sLat != null && sLon != null) {
            setPin(sLat, sLon, false)
            map.controller.setCenter(GeoPoint(sLat, sLon))
        } else {
            map.controller.setCenter(GeoPoint(25.2048, 55.2708)) // دبی
        }

        // ---------- گزینه‌ها ----------
        swRealism = Switch(this).apply {
            text = "حالت واقعی‌نما (نوسان طبیعی چند متری، دقت و ارتفاع متغیر)"
            isChecked = prefs.getBoolean("realism", true)
        }
        swWatch = Switch(this).apply {
            text = "نگهبان: هر ۱ دقیقه بررسی + آلارم و اتصال دوباره"
            isChecked = prefs.getBoolean("watchdog", true)
        }
        root.addView(swRealism)
        root.addView(swWatch)

        root.addView(btn("▶ شروع") { startMock() })
        root.addView(btn("⏹ توقف") {
            prefs.edit().putBoolean("active", false).apply()
            stopService(Intent(this, MockLocationService::class.java))
            MockState.running = false
        })
        tvStatus = label("")
        root.addView(tvStatus)
        tvEvents = label("", 12f)
        root.addView(tvEvents)

        // ---------- جلوگیری از قطع شدن ----------
        root.addView(label("🔒 جلوگیری از قطع شدن", 18f, true))
        root.addView(label(
            "۱) FakeGeo باید Mock location app باشه.\n" +
                "۲) بهینه‌سازی باتری رو برای FakeGeo خاموش کن (دکمه‌ی پایین).\n" +
                "۳) اپ رو توی Recent قفل کن و از Task Killer یا Clean استثنا کن.\n" +
                "۴) برای کامل‌تر شدن: Settings ▸ Location ▸ Wi-Fi scanning و Bluetooth scanning رو خاموش کن."
        ))
        root.addView(btn("باز کردن Developer options") {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            } catch (e: Exception) {
                toast("Developer options فعال نیست. Settings ▸ About phone ▸ ۷ بار روی Build number بزن.")
            }
        })
        root.addView(btn("خاموش کردن بهینه‌سازی باتری") { batterySettings() })

        // ---------- تاریخچه ----------
        root.addView(label("🕘 تاریخچه‌ی پین‌ها", 18f, true))
        historyBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(historyBox)
        root.addView(btn("حذف همه‌ی تاریخچه") {
            AlertDialog.Builder(this)
                .setMessage("همه‌ی تاریخچه حذف بشه؟")
                .setPositiveButton("حذف") { _, _ ->
                    PinStore.clear(this)
                    refreshHistory()
                }
                .setNegativeButton("لغو", null)
                .show()
        })
        refreshHistory()

        // ---------- SIM ----------
        root.addView(label("📶 ماژول SIM برای LSPatch", 18f, true))
        root.addView(label(
            "کشور SIM که اپ‌های پچ‌شده می‌بینن (تنظیم‌شده موقع بیلد):\n" +
                "• کشور: ${BuildConfig.SIM_COUNTRY.uppercase()}\n" +
                "• MCC+MNC: ${BuildConfig.SIM_MCCMNC}\n" +
                "• اپراتور: ${BuildConfig.SIM_OPERATOR_NAME}"
        ))

        // ---------- امضا ----------
        val year = Calendar.getInstance().get(Calendar.YEAR)
        root.addView(TextView(this).apply {
            text = "© $year Farhad rgb — All rights reserved\nساخته‌شده توسط Farhad rgb"
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        })

        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), 2)
    }

    private fun setPin(lat: Double, lon: Double, center: Boolean) {
        pinLat = lat
        pinLon = lon
        val gp = GeoPoint(lat, lon)
        var m = marker
        if (m == null) {
            m = Marker(map)
            m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            m.setOnMarkerClickListener { _, _ -> true }
            map.overlays.add(m)
            marker = m
        }
        m.position = gp
        if (center) map.controller.animateTo(gp)
        map.invalidate()
        tvCoords.text = String.format(Locale.US, "📌 %.6f , %.6f", lat, lon)
    }

    private fun startMock() {
        val la = pinLat
        val lo = pinLon
        if (la == null || lo == null) {
            toast("اول روی نقشه پین بذار")
            return
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
            return
        }
        prefs.edit()
            .putString("pin_lat", la.toString())
            .putString("pin_lon", lo.toString())
            .putString("acc", "5")
            .putBoolean("realism", swRealism.isChecked)
            .putBoolean("watchdog", swWatch.isChecked)
            .putBoolean("active", true)
            .apply()
        PinStore.add(this, Pin(la, lo, System.currentTimeMillis()))
        refreshHistory()
        MockState.error = null
        startForegroundService(
            Intent(this, MockLocationService::class.java).setAction(MockLocationService.ACTION_START)
        )
    }

    private fun refreshHistory() {
        historyBox.removeAllViews()
        val list = PinStore.load(this)
        if (list.isEmpty()) {
            historyBox.addView(label("هنوز چیزی ذخیره نشده"))
            return
        }
        val fmt = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US)
        list.forEachIndexed { idx, pin ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tv = TextView(this).apply {
                text = String.format(Locale.US, "📍 %.5f , %.5f\n%s", pin.lat, pin.lon, fmt.format(Date(pin.time)))
                textSize = 13f
                setPadding(0, dp(6), 0, dp(6))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    setPin(pin.lat, pin.lon, true)
                    toast("پین روی نقشه گذاشته شد. «شروع» رو بزن.")
                }
            }
            val del = Button(this).apply {
                text = "🗑 حذف"
                setOnClickListener {
                    PinStore.remove(this@MainActivity, idx)
                    refreshHistory()
                }
            }
            row.addView(tv)
            row.addView(del)
            historyBox.addView(row)
        }
    }

    private fun batterySettings() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (pm.isIgnoringBatteryOptimizations(packageName)) {
                toast("بهینه‌سازی باتری از قبل خاموشه ✅")
                return
            }
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                toast("از تنظیمات باتری گوشی، FakeGeo رو روی Unrestricted بذار")
            }
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == 1) {
            if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startMock()
            else toast("برای فیک GPS دسترسی Location لازمه")
        }
    }

    private fun updateStatus() {
        val err = MockState.error
        tvStatus.text = when {
            err != null -> "❌ $err"
            MockState.running -> "✅ فعال روی ${tvCoords.text}"
            else -> "⏹ غیرفعال"
        }
        tvEvents.text = MockState.recent().joinToString("\n")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onResume() {
        super.onResume()
        map.onResume()
        ui.post(refresh)
    }

    override fun onPause() {
        super.onPause()
        map.onPause()
        ui.removeCallbacks(refresh)
    }

    override fun onDestroy() {
        map.onDetach()
        super.onDestroy()
    }
}
