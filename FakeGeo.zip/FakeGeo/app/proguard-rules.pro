# Loaded by name from assets/xposed_init (LSPatch/LSPosed) -> must not be renamed or removed.
-keep class dev.fakegeo.app.SimSpoofHook { *; }

# Xposed API classes only exist at runtime inside LSPatch/LSPosed (the stub is compileOnly).
-dontwarn de.robv.android.xposed.**

# BouncyCastle is used for the iPhone pairing certificates; keep it intact (providers are loaded by name).
-keep class org.bouncycastle.** { *; }
-dontwarn org.bouncycastle.**
