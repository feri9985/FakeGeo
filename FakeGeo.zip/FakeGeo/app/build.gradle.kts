plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// مقادیر SIM جعلی از طریق -P در زمان بیلد گرفته می‌شن (GitHub Actions این‌ها رو پر می‌کنه)
fun cfg(name: String, default: String): String =
    ((project.findProperty(name) as String?)?.trim()?.takeIf { it.isNotEmpty() } ?: default)
        .replace("\"", "").replace("\\", "")

android {
    namespace = "dev.fakegeo.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "dev.fakegeo.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 9
        versionName = "1.8"

        ndk { abiFilters.addAll(listOf("arm64-v8a", "armeabi-v7a")) }

        buildConfigField("String", "SIM_COUNTRY", "\"${cfg("simCountry", "de").lowercase()}\"")
        buildConfigField("String", "SIM_MCCMNC", "\"${cfg("simMccMnc", "26201").filter { it.isDigit() }}\"")
        buildConfigField("String", "SIM_NUMBER", "\"${cfg("simNumber", "").filter { it.isDigit() || it == '+' }}\"")
        buildConfigField("String", "SIM_OPERATOR_NAME", "\"${cfg("simOperator", "Telekom.de")}\"")
    }

    buildFeatures {
        buildConfig = true
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildTypes {
        release { isMinifyEnabled = false }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    debugImplementation("androidx.compose.ui:ui-tooling")
    // کلاس‌های Xposed موقع اجرا از LSPatch/LSPosed میان؛ این‌جا فقط برای کامپایل لازمن
    compileOnly(project(":xposed-stub"))
    // نقشه‌ی برداری MapLibre + OpenFreeMap (بدون نیاز به API key)
    implementation("org.maplibre.gl:android-sdk:11.5.2")
}
