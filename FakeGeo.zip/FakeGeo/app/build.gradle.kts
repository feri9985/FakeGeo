plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// مقادیر SIM جعلی از طریق -P در زمان بیلد گرفته می‌شن (GitHub Actions این‌ها رو پر می‌کنه)
fun cfg(name: String, default: String): String =
    ((project.findProperty(name) as String?)?.trim()?.takeIf { it.isNotEmpty() } ?: default)
        .replace("\"", "").replace("\\", "")

android {
    namespace = "dev.fakegeo.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "dev.fakegeo.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 31
        versionName = "3.9.0"

        ndk { abiFilters.addAll(listOf("arm64-v8a", "armeabi-v7a")) }

        buildConfigField("String", "SIM_COUNTRY", "\"${cfg("simCountry", "de").lowercase()}\"")
        buildConfigField("String", "SIM_MCCMNC", "\"${cfg("simMccMnc", "26201").filter { it.isDigit() }}\"")
        buildConfigField("String", "SIM_NUMBER", "\"${cfg("simNumber", "").filter { it.isDigit() || it == '+' }}\"")
        buildConfigField("String", "SIM_OPERATOR_NAME", "\"${cfg("simOperator", "Telekom.de")}\"")
    }

    buildFeatures { buildConfig = true }

    packaging {
        resources {
            excludes += setOf("META-INF/versions/**", "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/DEPENDENCIES")
        }
    }

    // Signing key: NEVER commit it. It comes from -PksFile/-PksPass/-PksAlias/-PksKeyPass or from the
    // environment (KS_FILE / KS_PASS / KS_ALIAS / KS_KEY_PASS). GitHub Actions fills these from Secrets.
    // If no key is provided, the build falls back to Android's default debug key (still works, but each
    // machine has a different key, so updates over an old install need an uninstall first).
    fun sec(prop: String, env: String): String? =
        (project.findProperty(prop) as String?)?.takeIf { it.isNotBlank() }
            ?: System.getenv(env)?.takeIf { it.isNotBlank() }

    val ksPath = sec("ksFile", "KS_FILE")
    if (ksPath != null && file(ksPath).exists()) {
        signingConfigs {
            create("fixed") {
                storeFile = file(ksPath)
                storePassword = sec("ksPass", "KS_PASS")
                keyAlias = sec("ksAlias", "KS_ALIAS")
                keyPassword = sec("ksKeyPass", "KS_KEY_PASS")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildTypes {
        getByName("debug") {
            signingConfigs.findByName("fixed")?.let { signingConfig = it }
        }
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfigs.findByName("fixed")?.let { signingConfig = it }
        }
    }
}

dependencies {
    // کلاس‌های Xposed موقع اجرا از LSPatch/LSPosed میان؛ این‌جا فقط برای کامپایل لازمن
    compileOnly(project(":xposed-stub"))
    // نقشه‌ی برداری MapLibre + OpenFreeMap (بدون نیاز به API key)
    implementation("org.maplibre.gl:android-sdk:11.5.2")
    // X.509 certificates for iPhone pairing (the Android API cannot create certificates)
    implementation("org.bouncycastle:bcpkix-jdk18on:1.78.1")
    implementation("org.bouncycastle:bcprov-jdk18on:1.78.1")
}
