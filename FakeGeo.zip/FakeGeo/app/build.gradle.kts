plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// مقادیر SIM جعلی از طریق -P در زمان بیلد گرفته می‌شن (GitHub Actions این‌ها رو پر می‌کنه)
fun cfg(name: String, default: String): String =
    ((project.findProperty(name) as String?)?.trim()?.takeIf { it.isNotEmpty() } ?: default)
        .replace("\"", "").replace("\\", "")

android {
    namespace = "dev.fakegeo.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "dev.fakegeo.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 24
        versionName = "3.3"

        ndk { abiFilters.addAll(listOf("arm64-v8a", "armeabi-v7a")) }

        buildConfigField("String", "SIM_COUNTRY", "\"${cfg("simCountry", "de").lowercase()}\"")
        buildConfigField("String", "SIM_MCCMNC", "\"${cfg("simMccMnc", "26201").filter { it.isDigit() }}\"")
        buildConfigField("String", "SIM_NUMBER", "\"${cfg("simNumber", "").filter { it.isDigit() || it == '+' }}\"")
        buildConfigField("String", "SIM_OPERATOR_NAME", "\"${cfg("simOperator", "Telekom.de")}\"")
    }

    buildFeatures { buildConfig = true }

    packaging {
        resources {
            excludes += setOf("META-INF/versions/**", "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/DEPENDENCIES")
        }
    }

    // A FIXED signing key. Without it every GitHub build gets a new random debug key and Android
    // refuses to install the new APK over the old one (you would have to uninstall and lose settings).
    // To use your own secret key instead, pass -PksFile / -PksPass / -PksAlias / -PksKeyPass.
    signingConfigs {
        create("fixed") {
            storeFile = file((project.findProperty("ksFile") as String?) ?: "fakegeo.keystore")
            storePassword = (project.findProperty("ksPass") as String?) ?: "fakegeo123"
            keyAlias = (project.findProperty("ksAlias") as String?) ?: "fakegeo"
            keyPassword = (project.findProperty("ksKeyPass") as String?) ?: "fakegeo123"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }
}

dependencies {
    // کلاس‌های Xposed موقع اجرا از LSPatch/LSPosed میان؛ این‌جا فقط برای کامپایل لازمن
    compileOnly(project(":xposed-stub"))
    // نقشه‌ی برداری MapLibre + OpenFreeMap (بدون نیاز به API key)
    implementation("org.maplibre.gl:android-sdk:11.5.2")
    // X.509 certificates for iPhone pairing (the Android API cannot create certificates)
    implementation("org.bouncycastle:bcpkix-jdk18on:1.78.1")
    implementation("org.bouncycastle:bcprov-jdk18on:1.78.1")
}
