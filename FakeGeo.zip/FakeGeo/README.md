# FakeGeo — فیک جی‌پی‌اس + ماژول فیک SIM (LSPatch)

یک اپ اندروید که دو کار می‌کنه:

1. **فیک جی‌پی‌اس** — مستقیم داخل خود اپ (بدون روت، با Mock location app).
2. **ماژول LSPatch** — با LSPatch داخل APK یک اپ دیگه جاسازی می‌شه و اطلاعات SIM
   (کشور، MCC/MNC، نام اپراتور) رو که اون اپ از سیستم می‌خونه عوض می‌کنه. بدون روت.

> فقط روی گوشی خودت و برای حریم خصوصی خودت استفاده کن. بعضی اپ‌ها این کار رو خلاف قوانین خودشون
> می‌دونن و ممکنه حساب رو محدود کنن.

---

## بخش ۱ — آپلود روی GitHub

1. روی https://github.com با اکانتت وارد شو (اکانت ندارید: Sign up).
2. بالا سمت راست **+ ▸ New repository** → اسم مثلا `FakeGeo` → **Create repository**.
3. این ZIP رو روی کامپیوتر **Extract** کن. داخلش پوشه‌ی `FakeGeo` هست.
4. در صفحه‌ی ریپوی خالی روی **uploading an existing file** بزن.
5. **همه‌ی محتوای داخل پوشه** (`app`، `xposed-stub`، `.github`، `build.gradle.kts`، `settings.gradle.kts`،
   `gradle.properties`، `README.md`...) رو بکش داخل صفحه.
   - ⚠️ پوشه‌ی **`.github`** حتما باید آپلود بشه (پوشه‌ی مخفی‌ه: در ویندوز
     File Explorer ▸ View ▸ Hidden items، در مک `Cmd+Shift+.`).
6. پایین صفحه **Commit changes** بزن.

### اگه `.github` آپلود نشد (راه جایگزین)
- **Add file ▸ Create new file** → در کادر اسم بنویس: `.github/workflows/build.yml`
  (با تایپ `/` پوشه‌ها خودکار ساخته می‌شن) → محتوای فایل `build.yml` رو paste کن → Commit.

### روش خط فرمان (اگه git داری)
```bash
cd FakeGeo
git init -b main
git add .
git commit -m "FakeGeo"
git remote add origin https://github.com/USERNAME/FakeGeo.git
git push -u origin main
```

---

## بخش ۲ — گرفتن فایل APK از GitHub

1. در ریپو تب **Actions** رو باز کن. اگه پیام فعال‌سازی دید: **I understand my workflows, go ahead and enable them**.
2. از لیست چپ **Build APK** ▸ دکمه‌ی **Run workflow**.
3. سه مقدار SIM رو بنویس (یا همون پیش‌فرض آلمان رو بذار):

   | فیلد | مثال |
   |---|---|
   | کد کشور | `de` / `us` / `ae` / `tr` / `gb` |
   | MCC+MNC | `26201` (آلمان Telekom) · `31026` (آمریکا T-Mobile) · `42402` (امارات Etisalat) · `28601` (ترکیه Turkcell) · `23410` (انگلیس O2) |
   | نام اپراتور | `Telekom.de` |

   مقدار MCC+MNC باید با کشور هم‌خوان باشه (سه رقم اول = MCC کشور).
4. حدود ۳ تا ۶ دقیقه صبر کن تا کنار اجرا تیک سبز ✅ بیاد (اگه ❌ شد: بخش عیب‌یابی).
5. روی همون اجرا کلیک کن، پایین صفحه بخش **Artifacts** ▸ **FakeGeo-apk** رو دانلود کن.
6. ZIP دانلودی رو Extract کن → فایل **`app-debug.apk`** همونه.

---

## بخش ۳ — نصب و استفاده از فیک GPS

1. `app-debug.apk` رو روی گوشی بریز و نصب کن (اجازه‌ی «نصب از منابع ناشناس» رو بده).
2. اگه Developer options نداری: **Settings ▸ About phone ▸ ۷ بار روی Build number** بزن.
3. **Settings ▸ System ▸ Developer options ▸ Select mock location app ▸ FakeGeo**.
4. اپ FakeGeo رو باز کن، شهر یا مختصات رو بذار، **شروع** رو بزن (دسترسی Location و Notification رو Allow کن).
5. توی Google Maps چک کن؛ نقطه‌ی آبی باید روی مختصات جعلی باشه. برای توقف: **توقف**.

نکته‌ها:
- برای دقت بهتر، Location گوشی روی High accuracy باشه.
- بعضی گوشی‌ها (Xiaomi/Huawei/Samsung) برای اپ باید «Battery: Unrestricted / بدون محدودیت باتری» رو بزنی.
- اگه اپ مقصد هنوز مکان واقعی می‌بینه، یک‌بار اپ مقصد رو از Recent ببند و دوباره باز کن.

---

## بخش ۴ — فیک SIM با LSPatch (بدون روت)

آماده‌سازی:
- **FakeGeo رو نصب کرده باشی** (بخش ۳).
- **LSPatch Manager** رو از صفحه‌ی Releases ریپوی رسمی LSPatch نصب کن
  (`github.com/JingMatrix/LSPatch` ▸ Releases ▸ فایل APK مدیریت‌گر `manager-...apk`).
  اسم‌ها و جای دکمه‌ها بسته به نسخه ممکنه کمی فرق کنه.
- **از اپ هدف بکاپ بگیر**: پچ کردن یعنی نصب نسخه‌ی با امضای جدید و باید اپ اصلی حذف بشه
  (ممکنه داده‌ی لاگین پاک بشه).

مراحل:
1. LSPatch Manager رو باز کن ▸ تب **Manage** (یا Repo/Patch) ▸ دکمه‌ی **+** (New patch).
2. اپ هدف رو انتخاب کن: از **اپ‌های نصب‌شده** یا **Select an APK from storage**.
3. حالت پچ: **Integrated (embed modules)** رو انتخاب کن
   (ماژول داخل APK جاسازی می‌شه و دیگه به Manager نیاز نداره).
4. بخش **Embed modules** ▸ **FakeGeo** رو تیک بزن.
5. **Start Patch** رو بزن و صبر کن تا تموم بشه.
6. اپ اصلی رو حذف (Uninstall) کن، بعد روی **Install** نسخه‌ی پچ‌شده بزن.
7. نسخه‌ی پچ‌شده رو باز کن. اپ حالا SIM رو با کشور انتخابیت می‌بینه.

برای عوض کردن کشور: Workflow رو با مقدار جدید اجرا کن، APK جدید بگیر، FakeGeo رو آپدیت کن
و اپ هدف رو دوباره پچ کن.

برای دیدن لاگ: LSPatch Manager ▸ Logs (پیام‌هایی که با `FakeGeo:` شروع می‌شن).

### چه چیزی عوض می‌شه
`TelephonyManager`: کشور SIM و شبکه، MCC+MNC، نام اپراتور.
`SubscriptionInfo`: کشور، MCC/MNC، نام حامل.

### چه چیزی عوض **نمی‌شه**
- IP، زبان/منطقه‌ی گوشی، شماره‌ی تلفن واقعی و SMS.
- چیزی که سرور اپ از IP یا شماره تشخیص بده.
- اپ‌هایی که امضا/Play Integrity رو چک می‌کنن (بانک‌ها، بعضی بازی‌ها) بعد از پچ ممکنه باز نشن.

---

## عیب‌یابی

| مشکل | راه‌حل |
|---|---|
| Actions اجرا نشد / Run workflow نیست | فایل `.github/workflows/build.yml` آپلود نشده؛ بخش «اگه .github آپلود نشد» |
| بیلد ❌ شد | وارد اجرا شو ▸ مرحله‌ی قرمز ▸ متن خطا رو کپی کن و برام بفرست |
| «Mock location app انتخاب نشده» | بخش ۳ مرحله‌ی ۳ |
| GPS جعلی کار نمی‌کنه | Location رو خاموش/روشن کن، اپ مقصد رو ببند و باز کن |
| اپ پچ‌شده باز نمی‌شه یا کرش می‌کنه | اپ تشخیص تغییر امضا داره؛ با LSPatch جور نیست |
| نصب نسخه‌ی پچ‌شده خطای امضا داد | اپ اصلی رو Uninstall کن |

---

## ساختار پروژه
- `app/.../MainActivity.kt` — رابط کاربری
- `app/.../MockLocationService.kt` — فیک GPS (Test provider)
- `app/.../SimSpoofHook.kt` — ماژول فیک SIM
- `app/src/main/assets/xposed_init` — معرفی کلاس ماژول
- `xposed-stub/` — کلاس‌های API فقط برای کامپایل (موقع اجرا از LSPatch میان)
- `.github/workflows/build.yml` — بیلد خودکار APK
