# FakeGeo – Compose GPS screen integration

A Dark Premium Jetpack Compose GPS screen has been added in:

`app/src/main/java/dev/fakegeo/app/ComposeGpsScreen.kt`

Compose dependencies and compiler configuration have been added to `app/build.gradle.kts`.

## Important integration note

The supplied project currently builds its UI entirely with Android Views. The new screen is an isolated, compilable Compose UI component that deliberately accepts the existing `MapView` and callbacks, so it does not replace or duplicate the current GPS/service implementation.

To mount it from `MainActivity`, create a `ComposeView` and call `setContent` with `FakeGeoGpsScreen(...)`. Pass the already-created `mapView`, current `pinLat` / `pinLon` / `pinName`, and the current running/status state. Wire callbacks to the existing activity operations:

- `onSearch`: set `etSearch.text` and call `doSearch()`
- `onLocate`: call `recenter()`
- `onChooseMapLayer`: show the existing layer `PopupMenu` / call `applyLayer(...)`
- `onStartStop`: call `startMock()` or stop the existing `MockLocationService` according to the current state

The `MapView` must not be attached to two parents at once. Remove it from the old `FrameLayout` before passing it to Compose. Keep the existing `MapView` lifecycle calls in `MainActivity` (`onCreate`, `onStart`, `onResume`, `onPause`, `onStop`, `onDestroy`, and `onSaveInstanceState`).

The component is bilingual: it selects Persian RTL when the device locale is `fa`, otherwise English LTR. The map itself and all GPS actions remain provided by the existing app.

## Build

Open the project in Android Studio with JDK 17 and sync Gradle. The environment that prepared this patch did not have the Android SDK/Gradle wrapper available, so a device build could not be run here.
