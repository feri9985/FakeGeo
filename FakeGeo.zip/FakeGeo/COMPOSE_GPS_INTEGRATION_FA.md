# FakeGeo – Dark Premium Compose GPS UI

این بسته، پروژه اصلی FakeGeo را به‌همراه صفحه GPS جدید Jetpack Compose نگه می‌دارد.

## فایل‌های اضافه‌شده

- `app/src/main/java/dev/fakegeo/app/ComposeGpsScreen.kt` – رابط Dark Premium دو‌زبانه (فارسی RTL و انگلیسی LTR)
- `app/build.gradle.kts` – فعال‌سازی Compose و افزودن وابستگی‌های لازم

## وضعیت ادغام

صفحه Compose به‌صورت یک کامپوننت آماده در پروژه قرار دارد؛ اما به‌صورت خودکار جایگزین صفحه قدیمی در `MainActivity` نشده است. این تصمیم برای جلوگیری از شکستن اتصال‌های فعلی MapLibre، سرویس موقعیت، تاریخچه، تنظیمات و کنترل‌های محافظتی گرفته شده است.

برای استفاده از صفحه جدید، در Activity یک `ComposeView` بسازید و `setContent { FakeGeoGpsScreen(...) }` را فراخوانی کنید. پارامتر `mapView` باید همان MapView موجود پروژه باشد و callbackها باید به متدهای واقعی Activity متصل شوند:

- `onSearch`: متن را در `etSearch` قرار دهید و `doSearch()` را اجرا کنید.
- `onLocate`: متد `recenter()` را فراخوانی کنید.
- `onChooseMapLayer`: منوی لایه‌های فعلی را نمایش دهید.
- `onStartStop`: با توجه به `MockState.running`، سرویس واقعی را شروع یا متوقف کنید.

**مهم:** `MapView` نباید هم‌زمان در دو والد View قرار بگیرد. قبل از قرار دادن آن در `AndroidView`، آن را از والد قبلی جدا کنید. چرخه عمر MapView همچنان باید در Activity مدیریت شود (`onCreate`, `onStart`, `onResume`, `onPause`, `onStop`, `onDestroy`, `onSaveInstanceState`).

## باز کردن پروژه

1. از ZIP خارج کنید.
2. پوشه `FakeGeo` را با Android Studio باز کنید.
3. از JDK 17 استفاده کنید.
4. Gradle Sync را اجرا کنید.
5. پس از اتصال Compose screen به Activity، روی دستگاه تست کنید.

## محدودیت تأیید

این محیط Android SDK و Gradle Wrapper پروژه را در اختیار نداشت؛ بنابراین APK در اینجا ساخته یا روی دستگاه اجرا نشده است. قبل از استفاده روزمره، حتماً Build و تست روی گوشی انجام دهید.
