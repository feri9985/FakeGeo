#!/usr/bin/env bash
set -euo pipefail

if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is not installed. Open this project in Android Studio or install Gradle 8.7." >&2
  exit 1
fi

gradle --version
gradle :app:assembleDebug --no-daemon
printf '\nAPK output: %s\n' "app/build/outputs/apk/debug/app-debug.apk"
