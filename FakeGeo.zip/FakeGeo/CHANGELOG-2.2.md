# FakeGeo 2.2

## UI spacing
- Added consistent vertical spacing to action buttons.
- Separated primary, secondary, and destructive actions with distinct colors.
- Updated labels for Start Location Test and Stop Test.

## WakeLock lifecycle
- Replaced an unbounded partial WakeLock with a 10-minute timed lease.
- Renew the lease every 8 minutes only while the mock-location service is expected to remain active.
- Release the WakeLock on startup failure and service destruction.
- Stop the alarm ringtone and clear pending service callbacks during teardown.

## Kill Switch safety
- The local VPN now protects only explicitly selected applications.
- An empty protected-app list no longer creates a device-wide blackhole VPN.
- UI and README clarify that network blocking does not prevent local location reads and cannot guarantee that no location data is disclosed.

## Validation
- Source-level edits reviewed.
- Gradle/APK build not run in this environment; compile and test on Android Studio before installing.
